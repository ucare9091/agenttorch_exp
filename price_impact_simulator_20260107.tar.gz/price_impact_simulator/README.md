# Price Impact Simulator

Analyzes how introducing a new product price affects household purchase behavior.

**Question**: "What would household purchase behavior be if we introduce a new product price to this population?"

## Quick Start

### 1. Prepare Your Data

Place your household CSV file in a `data/` directory:
```
data/
  └── households.csv  (3000 rows × 581 columns)
```

### 2. Run Analysis

```python
from price_impact_simulator import PriceImpactSimulator

# Load data (relative path)
simulator = PriceImpactSimulator(household_data="data/households.csv")

# Define price scenario for new product
scenario = {
    'product_category': 'new_soft_drink_flavor',  # New CPG product
    'new_price': 2.99,
    'baseline_price': 2.49  # Competitive/previous price
}

# Run analysis
results = simulator.analyze_price_impact(scenario, n_trials=10)

# Generate report
simulator.generate_report(results, output_dir="output")
```

### 3. Command Line

```bash
python run_analysis.py \
  --data data/households.csv \
  --category new_ice_cream_flavor \
  --new-price 4.99 \
  --baseline-price 3.99
```

## New Product Examples

The simulator supports new CPG products:

- `new_soft_drink_flavor` - New soft drink flavor
- `new_ice_cream_flavor` - New ice cream flavor  
- `new_snack_product` - New snack product
- Any category starting with `new_` or containing `new`

New products have lower initial adoption probability (40% vs 70% for existing products).

## Input Data

- **Format**: CSV file (recommended) or Parquet
- **Location**: Use relative paths like `data/households.csv`
- **Structure**: 3000 rows (households) × 581 columns (attributes)
- **Required**: `household_id` column (or similar)

## Output

- **Text Report**: Detailed analysis
- **JSON Results**: Machine-readable results
- **Metrics**: Purchase behavior, revenue impact, segmentation

## Requirements

```bash
pip install numpy pandas pyarrow
```

## Databricks Usage

Works with relative paths in Databricks:

```python
simulator = PriceImpactSimulator(household_data="data/households.csv")
```

Or absolute paths:
```python
simulator = PriceImpactSimulator(household_data="/dbfs/mnt/data/households.csv")
```
