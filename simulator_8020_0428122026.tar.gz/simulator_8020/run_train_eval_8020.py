#!/usr/bin/env python3
"""
Train purchase_logit_bias on a random fraction of households, evaluate metrics on the rest.

Uses the same unified Parquet as the rest of the bundle. Split is by labeled household_id
with a fixed RNG seed for reproducibility. Rows are restricted to train vs eval households
before building agent states so the held-out set never enters the training forward pass.

Training minimizes BCE between purchase_probability and labels on the train subset only
(calibration on, LLM off; only learnable policy parameters are optimized, which is the scalar
purchase_logit_bias). Evaluation runs in a separate process on eval-only rows with the
trained bias fixed; sklearn precision, recall, F1, and accuracy use threshold 0.5 on
probabilities (no optimization on the eval set).

Run from bundle root after pip install -r requirements.txt and fix scripts.

Example:
  python run_train_eval_8020.py --csv data/unified_panel_5k_sample.parquet --split-seed 42 --epochs 40 --lr 0.2
"""

from __future__ import annotations

import argparse
import importlib
import os
import subprocess
import sys
import tempfile
import types
from pathlib import Path

import torch
import torch.nn.functional as F

_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from bundle_runtime_check import ensure_pyarrow_for_agent_stack

ensure_pyarrow_for_agent_stack()

from agent_torch.core.dataloader import LoadPopulation
from agent_torch.core.executor import Executor

from runner_dbx import (
    apply_simulation_seed,
    build_agent_states,
    build_model_config,
    household_table_and_ground_truth_from_unified_panel,
    load_transaction_history_table,
    write_population_pickles,
)
from train_eval_split import train_eval_household_ids


def _load_executor(base_dir: Path, device: str) -> Executor:
    population_dir = base_dir / "agenttorch_population"
    sys.path.insert(0, str(base_dir.resolve()))
    model_module = importlib.import_module("agenttorch_model")
    try:
        population_module = importlib.import_module("agenttorch_population")
    except (ModuleNotFoundError, ImportError):
        population_module = types.ModuleType("agenttorch_population")
        population_module.__path__ = [str(population_dir)]
        sys.modules["agenttorch_population"] = population_module

    string_pickle_files = ["location.pickle", "emotional_state.pickle"]
    temp_files: dict = {}
    temp_dir = base_dir / "_temp_population_strings"
    temp_dir.mkdir(exist_ok=True)
    for filename in string_pickle_files:
        src = population_dir / filename
        if src.exists():
            temp_path = temp_dir / filename
            src.rename(temp_path)
            temp_files[filename] = temp_path
    try:
        population = LoadPopulation(population_module)
    finally:
        for filename, temp_path in temp_files.items():
            temp_path.rename(population_dir / filename)
        try:
            temp_dir.rmdir()
        except OSError:
            pass

    executor = Executor(model_module, pop_loader=population)
    executor.init()
    return executor


def main() -> int:
    p = argparse.ArgumentParser(
        description="80/20 household split: train purchase_logit_bias on 80%, report metrics on 20%"
    )
    p.add_argument("--csv", type=str, required=True, help="Unified Parquet/CSV (same as --unified-input)")
    p.add_argument("--train-fraction", type=float, default=0.8, help="Fraction of labeled households for training")
    p.add_argument("--split-seed", type=int, default=42, help="RNG seed for household train/eval split only")
    p.add_argument("--seed", type=int, default=None, help="Optional torch/random seed for reproducible draws")
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--lr", type=float, default=0.1)
    args = p.parse_args()

    base_dir = Path(__file__).resolve().parent
    apply_simulation_seed(args.seed)

    raw = load_transaction_history_table(args.csv)
    hdf_full, gt_map = household_table_and_ground_truth_from_unified_panel(raw)
    if not gt_map:
        print("Error: unified table must include a ground-truth label column.", file=sys.stderr)
        return 1

    labeled_ids = sorted(set(int(x) for x in hdf_full["household_id"]) & set(gt_map.keys()))
    train_ids, eval_ids = train_eval_household_ids(labeled_ids, args.train_fraction, args.split_seed)

    train_set, eval_set = set(train_ids), set(eval_ids)
    if train_set & eval_set:
        raise RuntimeError("Train/eval household id sets overlap; this should never happen.")
    if train_set | eval_set != set(labeled_ids):
        raise RuntimeError("Train/eval ids do not partition all labeled households.")

    hdf_train = hdf_full[hdf_full["household_id"].isin(train_ids)].copy()
    hdf_eval = hdf_full[hdf_full["household_id"].isin(eval_ids)].copy()

    # Labels for optimization: train households only (no held-out labels in the loss).
    gt_train = {int(hid): int(gt_map[int(hid)]) for hid in train_ids}

    print(
        f"Split (seed={args.split_seed}): train households={len(train_ids)} eval households={len(eval_ids)} "
        f"(train_fraction={args.train_fraction})",
        flush=True,
    )

    agent_train = build_agent_states(hdf_train)
    write_population_pickles(base_dir, agent_train)
    build_model_config(
        base_dir,
        agent_train,
        device=args.device,
        product_category="new_ice_cream_flavor",
        new_price=4.99,
        baseline_price=3.99,
        llm_config=None,
        calibration=True,
    )

    executor = _load_executor(base_dir, args.device)
    runner = executor.runner
    dev = torch.device(args.device)
    hh_train = agent_train["households"]
    y_train = torch.tensor(
        [float(gt_train[int(h.get("household_id", 0))]) for h in hh_train],
        device=dev,
        dtype=torch.float32,
    ).view(-1, 1)

    pol = runner.initializer.policy_function["0"]["households"]["purchase_decision"]
    pol.train()
    bias_params = [p for p in pol.parameters() if p.requires_grad]
    if not bias_params:
        print("Error: no trainable parameters on purchase policy (expected purchase_logit_bias).", file=sys.stderr)
        return 1
    opt = torch.optim.Adam(bias_params, lr=args.lr)

    def _train_bce_accuracy_no_grad() -> tuple[float, float]:
        with torch.no_grad():
            state = runner.state
            obs = runner.controller.observe(state, runner.initializer.observation_function, "households")
            out = pol(state, obs)
            probs = out["purchase_probability"].to(device=dev, dtype=torch.float32)
            bce = F.binary_cross_entropy(probs, y_train).item()
            pred = (probs >= 0.5).float()
            acc = (pred == y_train).float().mean().item()
        return bce, acc

    bce0, acc0 = _train_bce_accuracy_no_grad()
    print(f"Train subset before optimization: BCE={bce0:.6f}  accuracy_at_0.5={acc0:.6f}", flush=True)

    for epoch in range(args.epochs):
        opt.zero_grad(set_to_none=True)
        state = runner.state
        obs = runner.controller.observe(state, runner.initializer.observation_function, "households")
        out = pol(state, obs)
        probs = out["purchase_probability"].to(device=dev, dtype=torch.float32)
        loss = F.binary_cross_entropy(probs, y_train)
        loss.backward()
        opt.step()
        if epoch % 10 == 0 or epoch == args.epochs - 1:
            bce_log, acc_log = _train_bce_accuracy_no_grad()
            print(f"train epoch {epoch:4d}  BCE={bce_log:.6f}  accuracy_at_0.5={acc_log:.6f}", flush=True)

    bias_val: float | None = None
    for name, v in pol.named_parameters():
        if "purchase_logit_bias" in name:
            bias_val = float(v.detach().cpu().numpy().ravel()[0])
            break
    if bias_val is None:
        print("Error: could not read purchase_logit_bias after training.", file=sys.stderr)
        return 1
    print(f"Trained purchase_logit_bias (train only): {bias_val:.6f}", flush=True)

    fd, tmp_path = tempfile.mkstemp(suffix="_eval8020.parquet")
    os.close(fd)
    try:
        hdf_eval.to_parquet(tmp_path, index=False)
        child = str(base_dir / "eval_8020_forward.py")
        cmd = [
            sys.executable,
            child,
            "--parquet",
            tmp_path,
            "--bias",
            str(bias_val),
            "--device",
            args.device,
        ]
        subprocess.check_call(cmd, cwd=str(base_dir))
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
