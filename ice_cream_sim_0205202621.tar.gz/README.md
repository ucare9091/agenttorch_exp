# Ice Cream Price Simulation

Simulates purchase behavior for new ice cream flavor launch. Supports any number of households and LLM-enhanced decision-making.

## Usage

### Basic Simulation

```bash
python run_simulation.py --csv data/households.csv --output output/results.json
```

### With LLM

```bash
python run_simulation.py \
    --csv data/households.csv \
    --output output/results.json \
    --llm-enabled \
    --llm-provider openai \
    --llm-model gpt-3.5-turbo
```

### Free LLM (Ollama)

```bash
python run_simulation.py \
    --csv data/households.csv \
    --output output/results.json \
    --llm-enabled \
    --llm-provider openai \
    --llm-model llama3.2 \
    --llm-api-base-url "http://localhost:11434/v1"
```

### Proxy Models

```bash
export MODEL_PROXY_API_KEY="your_key"
export MODEL_PROXY_API_BASE="https://proxy-url.com/v1"

python run_simulation.py \
    --csv data/households.csv \
    --output output/results.json \
    --llm-enabled \
    --llm-provider openai \
    --llm-model gpt-5.1
```

### Evaluation

```bash
python run_full_evaluation.py \
    --csv data/households.csv \
    --output-dir output \
    --llm-enabled
```

## LLM Configuration

Priority order:
1. Command-line arguments (`--llm-api-key`, `--llm-api-base-url`)
2. Environment variables (`MODEL_PROXY_API_KEY`, `MODEL_PROXY_API_BASE`)
3. Standard env vars (`OPENAI_API_KEY`, `OPENAI_API_BASE`)
4. Provider defaults

## Installation

```bash
pip install -r requirements.txt
python apply_dataloader_fix.py
```

## Input Format

**Households CSV:**
- `household_id`, `income`, `household_size`, `price_sensitivity`, `location`, `emotional_state`

**Transaction CSV (optional):**
- `household_id`, `purchased`

## Output

- `results.json` - Simulation results
- `results_evaluation.json` - Evaluation metrics (if transaction data provided)
