"""
Price Impact Simulator
Focused simulator to analyze purchase behavior changes from product price changes
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Union
from pathlib import Path
import json
from datetime import datetime

from .household import Household, PurchaseDecision
from .data_loader import HouseholdDataLoader


class PriceImpactSimulator:
    """
    Simulator to answer: "What would household purchase behavior be
    if we introduce a new product price to this population?"
    """

    def __init__(self, household_data: Optional[Union[str, pd.DataFrame]] = None):
        """
        Initialize simulator

        Args:
            household_data: Path to Parquet file, DataFrame, or None for testing
        """
        self.data_loader = HouseholdDataLoader(household_data)
        self.households: List[Household] = []
        self._initialize_households()

    def _initialize_households(self):
        """Load and initialize household objects from data"""
        data = self.data_loader.load()

        # Get household IDs
        household_ids = self.data_loader.get_household_ids()

        # Create household objects
        self.households = []
        for hh_id in household_ids:
            attributes = self.data_loader.get_household_attributes(hh_id)
            household = Household(hh_id, attributes)
            self.households.append(household)

        if len(self.households) > 0:
            print(f"Initialized {len(self.households)} households")

    def analyze_price_impact(self, scenario: Dict, n_trials: int = 1) -> Dict:
        """
        Analyze purchase behavior impact of a price change

        Args:
            scenario: Dictionary with:
                - product_category: str (e.g., 'produce')
                - new_price: float (new price per unit)
                - baseline_price: float (original price, optional)
            n_trials: Number of simulation trials (for stochastic analysis)

        Returns:
            Dictionary with analysis results
        """
        product_category = scenario['product_category']
        new_price = scenario['new_price']
        baseline_price = scenario.get('baseline_price', new_price)

        print(f"\nAnalyzing price impact for {product_category}")
        print(f"  Baseline price: ${baseline_price:.2f}")
        print(f"  New price: ${new_price:.2f}")
        print(f"  Price change: {((new_price - baseline_price) / baseline_price * 100):+.1f}%")

        # Run multiple trials for statistical robustness
        all_results = []
        for trial in range(n_trials):
            trial_results = self._run_single_trial(product_category, new_price, baseline_price)
            all_results.append(trial_results)

        # Aggregate results
        results = self._aggregate_results(all_results, scenario)

        return results

    def _run_single_trial(self, product_category: str, new_price: float,
                         baseline_price: float) -> List[PurchaseDecision]:
        """Run a single simulation trial"""
        decisions = []
        for household in self.households:
            decision = household.decide_purchase(product_category, new_price, baseline_price)
            decisions.append(decision)
        return decisions

    def _aggregate_results(self, all_trials: List[List[PurchaseDecision]],
                          scenario: Dict) -> Dict:
        """Aggregate results from multiple trials"""
        # Calculate metrics for each trial
        trial_metrics = []
        for trial_decisions in all_trials:
            purchasing_households = [d for d in trial_decisions if d.will_purchase]

            metrics = {
                'purchasing_count': len(purchasing_households),
                'purchase_rate': len(purchasing_households) / len(trial_decisions),
                'total_revenue': sum(d.total_spend for d in purchasing_households),
                'avg_quantity': np.mean([d.quantity for d in purchasing_households]) if purchasing_households else 0,
                'total_units': sum(d.quantity for d in purchasing_households)
            }
            trial_metrics.append(metrics)

        # Average across trials
        avg_metrics = {
            'purchasing_count': np.mean([m['purchasing_count'] for m in trial_metrics]),
            'purchase_rate': np.mean([m['purchase_rate'] for m in trial_metrics]),
            'total_revenue': np.mean([m['total_revenue'] for m in trial_metrics]),
            'avg_quantity': np.mean([m['avg_quantity'] for m in trial_metrics]),
            'total_units': np.mean([m['total_units'] for m in trial_metrics])
        }

        # Calculate baseline for comparison
        baseline_results = self._calculate_baseline(scenario)

        # Calculate impact
        impact = {
            'revenue_change': avg_metrics['total_revenue'] - baseline_results['total_revenue'],
            'revenue_change_pct': ((avg_metrics['total_revenue'] - baseline_results['total_revenue'])
                                  / max(baseline_results['total_revenue'], 1) * 100),
            'purchase_rate_change': avg_metrics['purchase_rate'] - baseline_results['purchase_rate'],
            'purchase_rate_change_pct': ((avg_metrics['purchase_rate'] - baseline_results['purchase_rate'])
                                        / max(baseline_results['purchase_rate'], 0.01) * 100),
            'units_change': avg_metrics['total_units'] - baseline_results['total_units'],
            'units_change_pct': ((avg_metrics['total_units'] - baseline_results['total_units'])
                                / max(baseline_results['total_units'], 1) * 100)
        }

        # Household segmentation analysis
        segmentation = self._analyze_segmentation(all_trials[0], scenario)

        return {
            'scenario': scenario,
            'baseline': baseline_results,
            'new_price_results': avg_metrics,
            'impact': impact,
            'segmentation': segmentation,
            'timestamp': datetime.now().isoformat(),
            'n_households': len(self.households),
            'n_trials': len(all_trials)
        }

    def _calculate_baseline(self, scenario: Dict) -> Dict:
        """Calculate baseline purchase behavior"""
        baseline_price = scenario.get('baseline_price', scenario['new_price'])
        product_category = scenario['product_category']

        # Run baseline simulation
        decisions = self._run_single_trial(product_category, baseline_price, baseline_price)
        purchasing = [d for d in decisions if d.will_purchase]

        return {
            'purchasing_count': len(purchasing),
            'purchase_rate': len(purchasing) / len(decisions),
            'total_revenue': sum(d.total_spend for d in purchasing),
            'avg_quantity': np.mean([d.quantity for d in purchasing]) if purchasing else 0,
            'total_units': sum(d.quantity for d in purchasing)
        }

    def _analyze_segmentation(self, decisions: List[PurchaseDecision],
                              scenario: Dict) -> Dict:
        """Analyze which household segments are most affected"""
        # Group by price sensitivity
        high_sensitivity = [d for d in decisions if d.price_sensitivity_factor > 0.7]
        medium_sensitivity = [d for d in decisions if 0.3 <= d.price_sensitivity_factor <= 0.7]
        low_sensitivity = [d for d in decisions if d.price_sensitivity_factor < 0.3]

        segmentation = {
            'high_sensitivity': {
                'count': len(high_sensitivity),
                'purchase_rate': sum(1 for d in high_sensitivity if d.will_purchase) / max(len(high_sensitivity), 1)
            },
            'medium_sensitivity': {
                'count': len(medium_sensitivity),
                'purchase_rate': sum(1 for d in medium_sensitivity if d.will_purchase) / max(len(medium_sensitivity), 1)
            },
            'low_sensitivity': {
                'count': len(low_sensitivity),
                'purchase_rate': sum(1 for d in low_sensitivity if d.will_purchase) / max(len(low_sensitivity), 1)
            }
        }

        return segmentation

    def generate_report(self, results: Dict, output_dir: str = "output") -> str:
        """
        Generate articulate report on price impact

        Args:
            results: Results from analyze_price_impact()
            output_dir: Directory to save report

        Returns:
            Path to generated report
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Generate text report
        report_path = output_path / f"price_impact_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

        with open(report_path, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("PRICE IMPACT ANALYSIS REPORT\n")
            f.write("=" * 80 + "\n\n")

            f.write("QUESTION:\n")
            f.write("What would household purchase behavior be if we introduce a new product price to this population?\n\n")

            f.write("SCENARIO:\n")
            f.write(f"  Product Category: {results['scenario']['product_category']}\n")
            f.write(f"  Baseline Price: ${results['scenario'].get('baseline_price', 'N/A'):.2f}\n")
            f.write(f"  New Price: ${results['scenario']['new_price']:.2f}\n")
            f.write(f"  Population Size: {results['n_households']:,} households\n\n")

            f.write("BASELINE BEHAVIOR:\n")
            baseline = results['baseline']
            f.write(f"  Purchasing Households: {baseline['purchasing_count']:.0f} ({baseline['purchase_rate']*100:.1f}%)\n")
            f.write(f"  Total Revenue: ${baseline['total_revenue']:,.2f}\n")
            f.write(f"  Total Units Sold: {baseline['total_units']:.0f}\n")
            f.write(f"  Average Quantity per Purchase: {baseline['avg_quantity']:.2f}\n\n")

            f.write("NEW PRICE BEHAVIOR:\n")
            new = results['new_price_results']
            f.write(f"  Purchasing Households: {new['purchasing_count']:.0f} ({new['purchase_rate']*100:.1f}%)\n")
            f.write(f"  Total Revenue: ${new['total_revenue']:,.2f}\n")
            f.write(f"  Total Units Sold: {new['total_units']:.0f}\n")
            f.write(f"  Average Quantity per Purchase: {new['avg_quantity']:.2f}\n\n")

            f.write("IMPACT ANALYSIS:\n")
            impact = results['impact']
            f.write(f"  Revenue Change: ${impact['revenue_change']:+,.2f} ({impact['revenue_change_pct']:+.1f}%)\n")
            f.write(f"  Purchase Rate Change: {impact['purchase_rate_change']*100:+.1f} percentage points\n")
            f.write(f"  Units Sold Change: {impact['units_change']:+.0f} ({impact['units_change_pct']:+.1f}%)\n\n")

            f.write("HOUSEHOLD SEGMENTATION:\n")
            seg = results['segmentation']
            f.write(f"  High Price Sensitivity ({seg['high_sensitivity']['count']} households):\n")
            f.write(f"    Purchase Rate: {seg['high_sensitivity']['purchase_rate']*100:.1f}%\n")
            f.write(f"  Medium Price Sensitivity ({seg['medium_sensitivity']['count']} households):\n")
            f.write(f"    Purchase Rate: {seg['medium_sensitivity']['purchase_rate']*100:.1f}%\n")
            f.write(f"  Low Price Sensitivity ({seg['low_sensitivity']['count']} households):\n")
            f.write(f"    Purchase Rate: {seg['low_sensitivity']['purchase_rate']*100:.1f}%\n\n")

            f.write("CONCLUSION:\n")
            if impact['revenue_change'] > 0:
                f.write(f"The price increase results in a revenue increase of ${impact['revenue_change']:,.2f} ")
                f.write(f"({impact['revenue_change_pct']:+.1f}%), despite a decrease in purchasing households.\n")
            else:
                f.write(f"The price change results in a revenue decrease of ${abs(impact['revenue_change']):,.2f} ")
                f.write(f"({impact['revenue_change_pct']:+.1f}%), primarily due to reduced purchasing households.\n")
            f.write(f"\nThe most price-sensitive households show the greatest change in purchase behavior.\n")

        # Save JSON results
        json_path = output_path / f"price_impact_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(json_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)

        print(f"\nReport saved to: {report_path}")
        print(f"Results saved to: {json_path}")

        return str(report_path)

