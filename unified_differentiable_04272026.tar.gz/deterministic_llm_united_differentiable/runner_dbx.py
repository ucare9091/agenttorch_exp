from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
import torch

import yaml
from agent_torch.core.dataloader import LoadPopulation
from agent_torch.core.executor import Executor


def apply_simulation_seed(seed: Optional[int]) -> None:
    """Seed Python ``random``, NumPy (if installed), and PyTorch for reproducible runs."""
    if seed is None:
        return
    random.seed(seed)
    try:
        import numpy as np

        np.random.seed(seed)
    except ImportError:
        pass
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _normalize_dbfs_path(path: str) -> str:
    """Map ``dbfs:/...`` to ``/dbfs/...`` on the Databricks driver."""
    if path.startswith("dbfs:/"):
        rest = path[len("dbfs:/") :].lstrip("/")
        return "/dbfs/" + rest
    return path


def _dedupe_column_labels(labels: list[str]) -> list[str]:
    """Make column names unique (Parquet/Spark may emit duplicate labels)."""
    seen: dict[str, int] = {}
    out: list[str] = []
    for base in labels:
        if base not in seen:
            seen[base] = 0
            out.append(base)
        else:
            seen[base] += 1
            out.append(f"{base}__dup{seen[base]}")
    return out


def _normalize_household_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Coerce labels to str and dedupe so extra Parquet columns load safely on Databricks/Spark."""
    if df is None or len(df.columns) == 0:
        return df
    out = df.copy()
    out.columns = _dedupe_column_labels([str(c) for c in out.columns])
    return out


def load_households_from_spark(spark: Any, table_or_path: str) -> pd.DataFrame:
    """Databricks notebook: load a Unity Catalog table or parquet path; save to parquet for CLI runs."""
    t = table_or_path.strip()
    is_likely_table = (
        "." in t
        and "/" not in t
        and not t.startswith("dbfs:")
        and not t.startswith("s3")
        and not t.startswith("abfss")
    )
    if is_likely_table:
        df = spark.table(t)
    else:
        df = spark.read.parquet(t)
    return _normalize_household_dataframe(df.toPandas())


def load_households(path: str) -> pd.DataFrame:
    """Load CSV or Parquet (file, ``.pq``, or partitioned directory).

    ``dbfs:/...`` paths work on Databricks drivers. Extra columns are preserved; only
    columns matched in ``build_agent_states`` are used for the simulation.

    Cloud-only URIs (``s3://``, ``abfss://``, ``wasb://``) are not readable with
    ``pandas`` on the driver; use ``load_households_from_spark`` and write a driver-local
    or bundle ``data/...`` Parquet/CSV path, or ``dbfs:/...`` if you use that layout.
    """
    s = str(path).strip()
    if s.startswith(("s3://", "abfss://", "wasb://")):
        raise FileNotFoundError(
            f"Path is not on the Databricks driver filesystem: {path!r}. "
            "Use load_households_from_spark(spark, table_or_path) then write Parquet/CSV under "
            "your bundle data directory (or /dbfs/...) and pass that path to run_simulation."
        )
    p = Path(path)
    if s.startswith("dbfs:"):
        p = Path(_normalize_dbfs_path(s))
    if not p.exists():
        raise FileNotFoundError(f"Household data path not found: {path}")
    suffix = p.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(p)
    elif suffix in (".parquet", ".pq") or p.is_dir():
        df = pd.read_parquet(p)
    else:
        df = pd.read_csv(p)
    return _normalize_household_dataframe(df)


def load_transaction_history_table(path: str) -> pd.DataFrame:
    """Load long-format transaction history (Parquet preferred, CSV allowed). Driver-local or dbfs paths only."""
    s = str(path).strip()
    if s.startswith(("s3://", "abfss://", "wasb://")):
        raise FileNotFoundError(
            f"Transaction history path must be on the driver: {path!r}. "
            "Materialize with Spark to Parquet under data/ or /dbfs/ first."
        )
    p = Path(_normalize_dbfs_path(s)) if s.startswith("dbfs:") else Path(s)
    if not p.exists():
        raise FileNotFoundError(f"Transaction history path not found: {path}")
    suffix = p.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(p)
    elif suffix in (".parquet", ".pq") or p.is_dir():
        df = pd.read_parquet(p)
    else:
        try:
            df = pd.read_parquet(p)
        except Exception:
            df = pd.read_csv(p)
    return _normalize_household_dataframe(df)


def build_transaction_history_prompts_for_agents(
    df: pd.DataFrame,
    households: list,
    max_rows_per_household: int = 80,
) -> list[str]:
    """
    Build one text block per agent row (same order as ``households`` in ``agent_states``).

    Required column (flexible name via ``find_column``): household id.
    Optional: product name, quantity, timestamp / purchase time.
    Extra columns are ignored; row count and names can change in your Parquet over time.
    """
    hid_col = find_column(
        df,
        [
            "household_id",
            "hh_id",
            "householdid",
            "householdId",
            "HH_ID",
            "hid",
            "customer_id",
            "cust_id",
        ],
    )
    if not hid_col:
        raise ValueError(
            "Transaction history table needs a household key column "
            "(e.g. household_id, hh_id, customer_id)."
        )
    prod_col = find_column(
        df,
        [
            "product_name",
            "product",
            "sku",
            "item_name",
            "item",
            "purchased_product",
            "goods",
            "product_desc",
        ],
    )
    qty_col = find_column(
        df,
        ["quantity", "qty", "units", "amount", "purchase_quantity", "n_units"],
    )
    time_col = find_column(
        df,
        [
            "purchase_timestamp",
            "purchase_time",
            "transaction_time",
            "event_time",
            "timestamp",
            "ts",
            "purchase_ts",
            "purchase_date",
            "datetime",
            "time",
            "txn_time",
        ],
    )
    price_col, store_col = _price_and_store_columns(df)

    def _hid_key(v: Any) -> Optional[int]:
        try:
            if pd.isna(v):
                return None
            return int(float(v))
        except (TypeError, ValueError):
            return None

    work = df.copy()
    work["_agent_hid"] = work[hid_col].map(_hid_key)
    work = work[work["_agent_hid"].notna()]

    if time_col:
        work["_sort_t"] = pd.to_datetime(work[time_col], errors="coerce")
    else:
        work["_sort_t"] = pd.NaT

    prompts: list[str] = []
    for h in households:
        hid = int(h["household_id"])
        sub = work[work["_agent_hid"] == hid]
        if sub.empty:
            prompts.append(
                "No rows in the provided transaction history file for this household_id."
            )
            continue
        if time_col and sub["_sort_t"].notna().any():
            sub = sub.sort_values("_sort_t", ascending=False).head(max_rows_per_household)
        else:
            sub = sub.tail(max_rows_per_household)

        lines: list[str] = []
        for _, row in sub.iterrows():
            if time_col:
                tval = row.get("_sort_t")
                if pd.notna(tval):
                    ts_str = pd.Timestamp(tval).strftime("%Y-%m-%d %H:%M")
                else:
                    raw = row.get(time_col)
                    ts_str = str(raw) if raw is not None and str(raw) != "nan" else "unknown_time"
            else:
                ts_str = "unknown_time"
            prod = str(row[prod_col]) if prod_col else "unknown_product"
            if qty_col and pd.notna(row.get(qty_col)):
                try:
                    qty_s = f"{float(row[qty_col]):g}"
                except (TypeError, ValueError):
                    qty_s = str(row[qty_col])
            else:
                qty_s = "1"
            extras = []
            if price_col and pd.notna(row.get(price_col)):
                try:
                    extras.append(f"price={float(row[price_col]):.2f}")
                except (TypeError, ValueError):
                    extras.append(f"price={row.get(price_col)}")
            if store_col and pd.notna(row.get(store_col)):
                extras.append(f"store={row[store_col]}")
            tail = (" | " + " | ".join(extras)) if extras else ""
            lines.append(f"{ts_str} | {prod} | qty={qty_s}{tail}")

        prompts.append(
            "Past purchase history (most recent first; capped per household):\n" + "\n".join(lines)
        )
    return prompts


def _price_and_store_columns(df: pd.DataFrame) -> tuple[Optional[str], Optional[str]]:
    price_col = find_column(
        df,
        [
            "unit_price",
            "price",
            "item_price",
            "transaction_price",
            "paid_price",
            "sale_price",
        ],
    )
    store_col = find_column(
        df,
        [
            "store_location",
            "store",
            "store_id",
            "retail_location",
            "location_store",
            "outlet",
        ],
    )
    return price_col, store_col


def household_table_and_ground_truth_from_unified_panel(df: pd.DataFrame) -> tuple[pd.DataFrame, Optional[Dict[int, int]]]:
    """
    One long-format table: repeated household demographics on each event row.
    Returns one row per household for ``build_agent_states`` and optional ground-truth map hid -> 0/1.
    """
    df = _normalize_household_dataframe(df)
    hid_col = find_column(
        df,
        [
            "household_id",
            "hh_id",
            "householdid",
            "householdId",
            "HH_ID",
            "customer_id",
            "cust_id",
        ],
    )
    if not hid_col:
        raise ValueError("Unified panel requires a household id column (e.g. household_id).")

    gt_col = find_column(
        df,
        [
            "ground_truth_purchased",
            "purchased_eval_product",
            "eval_purchased",
            "target_purchased",
            "label_purchased",
            "purchased_target",
            "y_purchase",
        ],
    )

    def _hid_key(v: Any) -> Optional[int]:
        try:
            if pd.isna(v):
                return None
            return int(float(v))
        except (TypeError, ValueError):
            return None

    work = df.copy()
    work["_hid_int"] = work[hid_col].map(_hid_key)
    work = work[work["_hid_int"].notna()]

    household_df = work.groupby("_hid_int", as_index=False).first()
    household_df["household_id"] = household_df["_hid_int"].astype(int)
    household_df = household_df.drop(columns=["_hid_int"], errors="ignore")
    if hid_col != "household_id" and hid_col in household_df.columns:
        household_df = household_df.drop(columns=[hid_col], errors="ignore")
    # Drop label column from household snapshot so it is not mistaken for a feature
    if gt_col and gt_col in household_df.columns:
        household_df = household_df.drop(columns=[gt_col], errors="ignore")

    gt_map: Optional[Dict[int, int]] = None
    if gt_col:
        gm: Dict[int, int] = {}
        for hid, sub in work.groupby("_hid_int"):
            raw = sub[gt_col].iloc[0]
            if isinstance(raw, bool):
                gm[int(hid)] = 1 if raw else 0
            elif isinstance(raw, (int, float, np.integer, np.floating)):
                gm[int(hid)] = 1 if float(raw) > 0 else 0
            else:
                gm[int(hid)] = 1 if str(raw).strip().lower() in ("1", "true", "yes", "y") else 0
        gt_map = gm

    return household_df, gt_map


def find_column(df: pd.DataFrame, possible_names: list, default_value=None):
    """
    Find column by multiple possible names (case-insensitive, partial match).

    Handles any column names by trying:
    1. Exact match (case-insensitive)
    2. Partial match (substring in either direction)
    3. Word-based match (matches key words like 'income', 'size', etc.)

    Returns the matching column name or None if not found.
    """
    if df is None or len(df.columns) == 0:
        return None

    cols_ordered = [(str(c).lower(), c) for c in df.columns]
    lower_to_first: dict[str, Any] = {}
    for low, orig in cols_ordered:
        if low not in lower_to_first:
            lower_to_first[low] = orig

    # Try exact match first (case-insensitive)
    for name in possible_names:
        name_lower = name.lower()
        if name_lower in lower_to_first:
            return lower_to_first[name_lower]

    # Try partial match (substring in either direction)
    for name in possible_names:
        name_lower = name.lower()
        for col_lower, col_orig in cols_ordered:
            if name_lower in col_lower or col_lower in name_lower:
                return col_orig

    # Try word-based matching (extract key words from possible names)
    for name in possible_names:
        name_lower = name.lower()
        key_words = [w for w in name_lower.split("_") if len(w) > 2]
        for col_lower, col_orig in cols_ordered:
            col_words = [w for w in col_lower.split("_") if len(w) > 2]
            if any(kw in cw or cw in kw for kw in key_words for cw in col_words):
                return col_orig

    return None


def build_agent_states(df: pd.DataFrame) -> Dict:
    """Build agent states from DataFrame with flexible column matching.

    Handles any column names and any number of rows efficiently.
    Missing columns use sensible defaults.

    Uses only columns that match (case-insensitive) the simulated attributes below; **any
    additional columns** (e.g. Databricks feature store fields) are left in ``df`` but not
    read into agent state.

    Simulated attributes (flexible naming via ``find_column``):
    - household_id, income, household_size, num_children (optional), price_sensitivity,
      location, emotional_state

    This function is designed to work with ANY tabular structure:
    - Any number of rows (1 to millions)
    - Any number of extra columns (e.g. Databricks feature store); ignored unless matched
    - Missing mapped columns are filled with sensible defaults
    """
    if df is None or len(df) == 0:
        raise ValueError("DataFrame is empty or None")

    df = _normalize_household_dataframe(df)
    n_rows = len(df)

    # Flexible column matching - tries many common variations
    id_col = find_column(df, ["id", "household_id", "householdid", "hh_id", "hhid", "household", "hh"])
    income_col = find_column(df, ["income", "household_income", "hh_income", "annual_income", "salary", "earnings", "revenue"])
    size_col = find_column(df, ["household_size", "hh_size", "householdsize", "people_in_hh", "num_people", "size", "people", "members", "persons"])
    children_col = find_column(df, ["num_children", "children", "num_children_in_hh", "kids", "child", "dependents"])
    sensitivity_col = find_column(df, ["price_sensitivity", "price_sens", "sensitivity", "price_elasticity", "elasticity", "sens"])
    location_col = find_column(df, ["location", "region", "geo", "geography", "area", "zip", "zipcode", "state", "city"])
    emotional_state_col = find_column(df, ["emotional_state", "emotion", "mood", "feeling", "stress_level", "happiness", "anxiety", "sentiment", "emotional", "mood_state"])

    # Extract or default values for each required field
    # Handle any data type issues gracefully
    try:
        if id_col:
            household_ids = pd.to_numeric(df[id_col], errors='coerce').fillna(0).astype(int).tolist()
        else:
            household_ids = list(range(1, n_rows + 1))
    except Exception:
        household_ids = list(range(1, n_rows + 1))

    try:
        if income_col:
            incomes = pd.to_numeric(df[income_col], errors='coerce').fillna(50000.0).astype(float).tolist()
        else:
            incomes = [50000.0] * n_rows
    except Exception:
        incomes = [50000.0] * n_rows

    try:
        if size_col:
            household_sizes = pd.to_numeric(df[size_col], errors='coerce').fillna(2.0).astype(float).tolist()
        else:
            household_sizes = [2.0] * n_rows
    except Exception:
        household_sizes = [2.0] * n_rows

    try:
        if children_col:
            num_children = pd.to_numeric(df[children_col], errors='coerce').fillna(0.0).astype(float).tolist()
        else:
            num_children = [0.0] * n_rows
    except Exception:
        num_children = [0.0] * n_rows

    try:
        if sensitivity_col:
            price_sensitivities = pd.to_numeric(df[sensitivity_col], errors='coerce').fillna(0.5).astype(float).tolist()
        else:
            price_sensitivities = [0.5] * n_rows
    except Exception:
        price_sensitivities = [0.5] * n_rows

    try:
        if location_col:
            locations = df[location_col].fillna("unknown").astype(str).tolist()
        else:
            locations = ["unknown"] * n_rows
    except Exception:
        locations = ["unknown"] * n_rows

    try:
        if emotional_state_col:
            # Handle both numeric (0-1 scale) and string (descriptive) emotional states
            emotional_states_raw = df[emotional_state_col].fillna("neutral").astype(str).tolist()
            # Normalize to common emotional states if numeric
            emotional_states = []
            for emo in emotional_states_raw:
                try:
                    emo_val = float(emo)
                    # Map numeric to emotional states: 0.0-0.2=very_stressed, 0.2-0.4=stressed, 0.4-0.6=neutral, 0.6-0.8=happy, 0.8-1.0=very_happy
                    if emo_val < 0.2:
                        emotional_states.append("very_stressed")
                    elif emo_val < 0.4:
                        emotional_states.append("stressed")
                    elif emo_val < 0.6:
                        emotional_states.append("neutral")
                    elif emo_val < 0.8:
                        emotional_states.append("happy")
                    else:
                        emotional_states.append("very_happy")
                except (ValueError, TypeError):
                    # Already a string, normalize common variations
                    emo_lower = str(emo).lower().strip()
                    if emo_lower in ["very_stressed", "very stressed", "anxious", "worried", "distressed"]:
                        emotional_states.append("very_stressed")
                    elif emo_lower in ["stressed", "stress", "concerned", "tense"]:
                        emotional_states.append("stressed")
                    elif emo_lower in ["neutral", "normal", "calm", "balanced", ""]:
                        emotional_states.append("neutral")
                    elif emo_lower in ["happy", "content", "satisfied", "pleased"]:
                        emotional_states.append("happy")
                    elif emo_lower in ["very_happy", "very happy", "elated", "joyful", "excited", "euphoric"]:
                        emotional_states.append("very_happy")
                    else:
                        emotional_states.append("neutral")  # Default fallback
        else:
            emotional_states = ["neutral"] * n_rows
    except Exception:
        emotional_states = ["neutral"] * n_rows

    households = [
        {
            "household_id": int(hid),
            "income": float(inc),
            "household_size": float(size),
            "num_children": float(children),
            "price_sensitivity": float(sens),
            "location": str(loc),
            "emotional_state": str(emo),
        }
        for hid, inc, size, children, sens, loc, emo in zip(
            household_ids, incomes, household_sizes, num_children, price_sensitivities, locations, emotional_states
        )
    ]

    return {"households": households, "n_agents": len(households)}


def write_population_pickles(base_dir: Path, agent_states: Dict) -> Path:
    """Create agenttorch_population directory with pickle files and __init__.py."""
    population_dir = base_dir / "agenttorch_population"
    population_dir.mkdir(parents=True, exist_ok=True)
    init_path = population_dir / "__init__.py"
    if not init_path.exists():
        init_path.write_text('"""AgentTorch population package."""\n')

    households = agent_states["households"]

    # Numeric data for LoadPopulation (will be converted to torch tensors)
    numeric_data = {
        "household_id": [h.get("household_id", 0) for h in households],
        "income": [h.get("income", 0.0) for h in households],
        "household_size": [h.get("household_size", 0.0) for h in households],
        "price_sensitivity": [h.get("price_sensitivity", 0.0) for h in households],
    }

    # String data for load_population_attribute (saved separately, not loaded by LoadPopulation)
    string_data = {
        "location": [h.get("location", "unknown") for h in households],
        "emotional_state": [h.get("emotional_state", "neutral") for h in households],
    }

    # Save numeric data as pickle (will be loaded by LoadPopulation)
    for key, values in numeric_data.items():
        series = pd.Series(values)
        series.to_pickle(population_dir / f"{key}.pickle")

    # Save string data as pickle (loaded by load_population_attribute, not LoadPopulation)
    # LoadPopulation will try to load these but fail, so we need to handle this
    # We'll save them but LoadPopulation should skip non-numeric types
    for key, values in string_data.items():
        series = pd.Series(values)
        series.to_pickle(population_dir / f"{key}.pickle")

    return population_dir


def build_model_config(
    base_dir: Path,
    agent_states: Dict,
    device: str = "cpu",
    product_category: str = "new_ice_cream_flavor",
    new_price: float = 4.99,
    baseline_price: float = 3.99,
    llm_config: Optional[Dict] = None,
    calibration: bool = False,
) -> Path:
    """Build AgentTorch config YAML directly without using config builders.

    When ``calibration`` is True, sets ``simulation_metadata.calibration`` (AgentTorch pattern) and adds a
    small learnable scalar ``purchase_logit_bias`` on the purchase policy for gradient-based calibration
    (see ``run_calibration.py``). LLM should be disabled for a differentiable graph.
    """
    model_dir = base_dir / "agenttorch_model"
    yamls_dir = model_dir / "yamls"
    yamls_dir.mkdir(parents=True, exist_ok=True)

    num_agents = len(agent_states["households"])
    population_dir = base_dir / "agenttorch_population"

    def _pop_prop_dict(name: str, dtype: str):
        """Create property dict for population-loaded attributes."""
        return {
            "dtype": dtype,
            "initialization_function": {
                "generator": "load_population_attribute",
                "arguments": {
                    "file_path": {
                        "value": str(population_dir / f"{name}.pickle"),
                        "shape": None,
                        "learnable": False,
                        "initialization_function": None,
                    }
                },
            },
            "learnable": False,
            "name": name,
            "shape": [num_agents, 1],
            "value": None,
        }

    policy_arguments: Dict[str, Any] = {"llm": llm_config if llm_config else {}}
    if calibration:
        policy_arguments["purchase_logit_bias"] = {
            "initialization_function": None,
            "learnable": True,
            "shape": [1],
            "value": 0.0,
        }

    config_dict = {
        "simulation_metadata": {
            "calibration": bool(calibration),
            "device": device,
            "num_agents": num_agents,
            "num_episodes": 1,
            "num_steps_per_episode": 1,
            "num_substeps_per_step": 1,
            "population_dir": str(population_dir),
        },
        "state": {
            "agents": {
                "households": {
                    "number": num_agents,
                    "properties": {
                        "household_id": _pop_prop_dict("household_id", "int"),
                        "income": _pop_prop_dict("income", "float"),
                        "household_size": _pop_prop_dict("household_size", "float"),
                        "price_sensitivity": _pop_prop_dict("price_sensitivity", "float"),
                        "location": {
                            "dtype": "str",
                            "initialization_function": {
                                "generator": "load_population_attribute",
                                "arguments": {
                                    "file_path": {
                                        "value": str(population_dir / "location.pickle"),
                                        "shape": None,
                                        "learnable": False,
                                        "initialization_function": None,
                                    }
                                },
                            },
                            "learnable": False,
                            "name": "location",
                            "shape": [num_agents, 1],
                            "value": None,
                        },
                        "emotional_state": {
                            "dtype": "str",
                            "initialization_function": {
                                "generator": "load_population_attribute",
                                "arguments": {
                                    "file_path": {
                                        "value": str(population_dir / "emotional_state.pickle"),
                                        "shape": None,
                                        "learnable": False,
                                        "initialization_function": None,
                                    }
                                },
                            },
                            "learnable": False,
                            "name": "emotional_state",
                            "shape": [num_agents, 1],
                            "value": None,
                        },
                        "will_purchase": {
                            "dtype": "float",
                            "initialization_function": None,
                            "learnable": False,
                            "name": "will_purchase",
                            "shape": [num_agents, 1],
                            "value": 0.0,
                        },
                        "will_purchase_deterministic": {
                            "dtype": "float",
                            "initialization_function": None,
                            "learnable": False,
                            "name": "will_purchase_deterministic",
                            "shape": [num_agents, 1],
                            "value": 0.0,
                        },
                        "quantity": {
                            "dtype": "float",
                            "initialization_function": None,
                            "learnable": False,
                            "name": "quantity",
                            "shape": [num_agents, 1],
                            "value": 0.0,
                        },
                        "total_spend": {
                            "dtype": "float",
                            "initialization_function": None,
                            "learnable": False,
                            "name": "total_spend",
                            "shape": [num_agents, 1],
                            "value": 0.0,
                        },
                    },
                },
            },
            "environment": {
                "new_price": {
                    "dtype": "float",
                    "initialization_function": None,
                    "learnable": False,
                    "name": "new_price",
                    "shape": [1],
                    "value": new_price,
                },
                "baseline_price": {
                    "dtype": "float",
                    "initialization_function": None,
                    "learnable": False,
                    "name": "baseline_price",
                    "shape": [1],
                    "value": baseline_price,
                },
                "product_category": {
                    "dtype": "str",
                    "initialization_function": None,
                    "learnable": False,
                    "name": "product_category",
                    "shape": None,  # String types handled specially by AgentTorch (returns early)
                    "value": product_category,
                },
                "llm_config": {
                    "dtype": "dict",
                    "initialization_function": None,
                    "learnable": False,
                    "name": "llm_config",
                    "shape": None,  # Dict types - AgentTorch will handle None shape
                    "value": llm_config if llm_config else {},
                },
            },
            "network": {},
            "objects": None,
        },
        "substeps": {
            "0": {
                "active_agents": ["households"],
                "description": "Simulate household purchase decisions based on price",
                "name": "purchase_decision",
                "observation": {"households": None},
                "policy": {
                    "households": {
                        "purchase_decision": {
                            "generator": "purchase_decision",
                            "input_variables": {
                                "income": "agents/households/income",
                                "household_size": "agents/households/household_size",
                                "price_sensitivity": "agents/households/price_sensitivity",
                                "location": "agents/households/location",
                                "emotional_state": "agents/households/emotional_state",
                                "new_price": "environment/new_price",
                                "baseline_price": "environment/baseline_price",
                            },
                            "output_variables": [
                                "will_purchase",
                                "will_purchase_deterministic",
                                "quantity",
                                "total_spend",
                                "purchase_probability",
                            ],
                            "arguments": policy_arguments,
                        },
                    },
                },
                "reward": None,
                "transition": {
                    "apply_purchase_decision": {
                        "generator": "apply_purchase_decision",
                        # AgentTorch stores policy outputs in action, but we need input_variables
                        # to tell AgentTorch where to read from. Since policy outputs go to action,
                        # we'll read from action in the transition step code itself.
                        "input_variables": {
                            # These are dummy - we'll read from action in code
                            "will_purchase": "agents/households/will_purchase",
                            "will_purchase_deterministic": "agents/households/will_purchase_deterministic",
                            "quantity": "agents/households/quantity",
                            "total_spend": "agents/households/total_spend",
                        },
                        "output_variables": [
                            "will_purchase",
                            "will_purchase_deterministic",
                            "quantity",
                            "total_spend",
                            "purchase_probability",
                        ],
                        "arguments": {},
                    },
                },
            },
        },
    }

    config_path = yamls_dir / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)

    return config_path


def run_simulation(
    csv_path: str,
    scenario: Optional[Dict] = None,
    device: str = "cpu",
    llm_config: Optional[Dict] = None,
    seed: Optional[int] = None,
    transaction_history_parquet: Optional[str] = None,
    transaction_history_max_rows: int = 80,
    unified_input: bool = False,
    auto_evaluate_unified: bool = True,
    quiet: bool = False,
    calibration: bool = False,
) -> Dict:
    """
    Run AgentTorch simulation using the original framework structure.

    This follows the AgentTorch large population model framework:
    - Uses Executor(model_module, pop_loader=population) pattern
    - Model module follows AgentTorch GitHub structure
    - Population loader uses LoadPopulation from agent_torch.core.dataloader

    Args:
        csv_path: Path to household CSV or Parquet (extra columns allowed; see ``build_agent_states``)
        scenario: Simulation scenario dict (product_category, new_price, baseline_price)
        device: Device to use ("cpu" or "cuda")
        llm_config: Optional LLM configuration dict with keys:
            - enabled: bool (whether to use LLM)
            - provider: str ("openai", "anthropic", "ollama", ...; see llm_helper)
            - model: str (model name)
            - api_key: str (optional; if omitted/blank, ``MODEL_PROXY_API_KEY`` / ``OPENAI_API_KEY`` / etc.)
            - api_base_url: str (optional; if omitted/blank, ``MODEL_PROXY_API_BASE`` / ``OPENAI_API_BASE`` / Ollama default)
            - temperature: float (0.0-2.0)
            - max_tokens: int
            - sample_size: int (number of households to use LLM for, 0 = all)
            - use_for_all: bool (use LLM for all households)
            - llm_weight: float (0.0-1.0, how much to weight LLM vs deterministic)
        seed: If set, seeds ``random``, NumPy, and PyTorch before the simulation runs (reproducible tests).
        transaction_history_parquet: Optional path to long-format Parquet/CSV of past purchases (feeds LLM prompt only).
        transaction_history_max_rows: Max lines per household in the prompt (most recent first if timestamps exist).
        unified_input: If True, ``csv_path`` is one long-format table (demographics + events + optional ground truth column).
        auto_evaluate_unified: If True and ground-truth labels exist in the unified table, attach metric dicts to results.
        quiet: If True, suppress verbose DEBUG lines (sets ``PRICE_SIM_QUIET`` for the run; restored afterward).
        calibration: If True, write ``simulation_metadata.calibration: true`` and add learnable ``purchase_logit_bias``
            (use ``run_calibration.py`` for autograd; keep ``llm_config`` disabled for a differentiable graph).
    """
    scenario = scenario or {
        "product_category": "new_ice_cream_flavor",
        "new_price": 4.99,
        "baseline_price": 3.99,
    }

    # Use relative path - works in scripts, notebooks, and any environment
    # Try __file__ first (when run as script), fallback to current directory (notebooks)
    try:
        base_dir = Path(__file__).resolve().parent
    except NameError:
        # __file__ not available (e.g., in notebooks or interactive Python)
        # Use current working directory
        base_dir = Path.cwd()

    from agenttorch_model.substeps.llm_helper import set_transaction_history_prompts
    from agenttorch_model.sim_debug import dbg_print

    ground_truth_map: Optional[Dict[int, int]] = None

    _quiet_prev = os.environ.get("PRICE_SIM_QUIET")
    if quiet:
        os.environ["PRICE_SIM_QUIET"] = "1"

    try:
        if unified_input:
            if transaction_history_parquet:
                raise ValueError("Do not set transaction_history_parquet when unified_input is True.")
            raw_panel = load_transaction_history_table(csv_path)
            hdf, ground_truth_map = household_table_and_ground_truth_from_unified_panel(raw_panel)
            agent_states = build_agent_states(hdf)
            set_transaction_history_prompts(
                build_transaction_history_prompts_for_agents(
                    raw_panel,
                    agent_states["households"],
                    max_rows_per_household=transaction_history_max_rows,
                )
            )
            print(
                f"Unified input: {csv_path} -> {agent_states['n_agents']} households; "
                "LLM history from the same table."
            )
        else:
            df = load_households(csv_path)
            agent_states = build_agent_states(df)
            if transaction_history_parquet:
                txdf = load_transaction_history_table(transaction_history_parquet)
                set_transaction_history_prompts(
                    build_transaction_history_prompts_for_agents(
                        txdf,
                        agent_states["households"],
                        max_rows_per_household=transaction_history_max_rows,
                    )
                )
            else:
                set_transaction_history_prompts(None)

        # Create AgentTorch population package (pickle files)
        write_population_pickles(base_dir, agent_states)

        # Build AgentTorch model config (YAML)
        build_model_config(
            base_dir,
            agent_states,
            device=device,
            product_category=scenario["product_category"],
            new_price=scenario["new_price"],
            baseline_price=scenario.get("baseline_price", scenario["new_price"]),
            llm_config=llm_config,
            calibration=calibration,
        )
    
        # Import model and population modules following AgentTorch structure
        # Import importlib and sys here (same as price_sim/market_sim pattern)
        import importlib
        import sys
    
        # Verify population directory exists before importing (for debugging)
        population_dir = base_dir / "agenttorch_population"
        if not population_dir.exists():
            raise RuntimeError(
                f"Population directory does not exist: {population_dir}\n"
                f"Base dir: {base_dir}\n"
                f"Base dir exists: {base_dir.exists()}\n"
                f"Current working directory: {Path.cwd()}"
            )
    
        init_file = population_dir / "__init__.py"
        if not init_file.exists():
            raise RuntimeError(f"Population __init__.py not found: {init_file}")
    
        # Use absolute path to avoid issues with relative paths
        base_dir_abs = base_dir.resolve()
        if str(base_dir_abs) not in sys.path:
            sys.path.insert(0, str(base_dir_abs))
    
        # Load model module (agenttorch_model package)
        model_module = importlib.import_module("agenttorch_model")
    
        # Load population module (agenttorch_population package)
        # LoadPopulation only needs module.__path__[0], so we can create a simple mock module
        # This avoids import issues on Databricks
        try:
            # Try standard import first (works in most environments)
            population_module = importlib.import_module("agenttorch_population")
        except (ModuleNotFoundError, ImportError):
            # Fallback: Create a mock module object with just __path__ attribute
            # LoadPopulation only accesses region.__path__[0], so this is sufficient
            import types
            population_module = types.ModuleType("agenttorch_population")
            population_module.__path__ = [str(population_dir)]
            # Register in sys.modules so it can be found if needed elsewhere
            sys.modules["agenttorch_population"] = population_module
    
        # Create population loader using AgentTorch framework
        # LoadPopulation will try to convert all pickle files to torch tensors
        # We need to temporarily move string pickles (location, emotional_state) out of the way
        # since they can't be converted to tensors
        string_pickle_files = ["location.pickle", "emotional_state.pickle"]
        temp_files = {}
    
        # Temporarily move string pickles OUTSIDE the population directory
        # (just renaming with _ prefix still matches *.pickle glob pattern)
        temp_dir = base_dir / "_temp_population_strings"
        temp_dir.mkdir(exist_ok=True)
    
        for filename in string_pickle_files:
            src = population_dir / filename
            if src.exists():
                # Move to temp directory outside population_dir
                temp_path = temp_dir / filename
                src.rename(temp_path)
                temp_files[filename] = temp_path
    
        try:
            # LoadPopulation will only load numeric pickles now
            # (string pickles are in temp_dir, not in population_dir)
            population = LoadPopulation(population_module)
        finally:
            # Restore string pickles (needed for load_population_attribute)
            for filename, temp_path in temp_files.items():
                temp_path.rename(population_dir / filename)
            # Clean up temp directory
            try:
                temp_dir.rmdir()
            except OSError:
                pass  # Directory not empty or doesn't exist
    
        apply_simulation_seed(seed)
        if seed is not None:
            print(f"Random seed: {seed} (random, numpy if present, torch)")
    
        # Initialize Executor using AgentTorch framework pattern
        # Executor(model_module, pop_loader=population) is the standard AgentTorch pattern
        executor = Executor(model_module, pop_loader=population)
    
        # Initialize executor
        executor.init()
        state = executor.runner.state
    
        # Set scenario parameters in environment after initialization
        if "environment" in state:
            # Set string value (not in config to avoid tensor conversion issue)
            state["environment"]["product_category"] = scenario["product_category"]
    
            # Set numeric values as tensors
            if "new_price" in state["environment"]:
                if torch.is_tensor(state["environment"]["new_price"]):
                    state["environment"]["new_price"] = torch.tensor([scenario["new_price"]], device=state["environment"]["new_price"].device)
                else:
                    state["environment"]["new_price"] = torch.tensor([scenario["new_price"]])
    
            if "baseline_price" in state["environment"]:
                baseline_val = scenario.get("baseline_price", scenario["new_price"])
                if torch.is_tensor(state["environment"]["baseline_price"]):
                    state["environment"]["baseline_price"] = torch.tensor([baseline_val], device=state["environment"]["baseline_price"].device)
                else:
                    state["environment"]["baseline_price"] = torch.tensor([baseline_val])
    
        # Execute simulation using AgentTorch framework
        executor.execute()
    
        # Extract results from AgentTorch state
        state = executor.runner.state
        households = state.get("agents", {}).get("households", {})
    
        # Get results with proper defaults
        will_purchase = households.get("will_purchase")
        dbg_print(f"DEBUG runner_dbx: will_purchase from state: type={type(will_purchase)}, value={will_purchase}")
        if will_purchase is None:
            dbg_print(f"DEBUG runner_dbx: will_purchase is None, creating zeros")
            will_purchase = torch.zeros((agent_states["n_agents"], 1))
        elif torch.is_tensor(will_purchase):
            dbg_print(f"DEBUG runner_dbx: will_purchase tensor shape={will_purchase.shape}, sum={will_purchase.sum().item()}, values={will_purchase[:10].tolist()}")
    
        quantity = households.get("quantity")
        if quantity is None:
            quantity = torch.zeros_like(will_purchase)
        else:
            quantity = torch.zeros_like(will_purchase) if quantity is None else quantity
    
        total_spend = households.get("total_spend")
        if total_spend is None:
            total_spend = torch.zeros_like(quantity)
    
        purchasing = (will_purchase > 0).float()
        purchasing_count = float(purchasing.sum().item())
        n_households = float(purchasing.numel())
    
        # Store per-household predictions for evaluation
        purchasing_list = purchasing.cpu().numpy().flatten().tolist() if torch.is_tensor(purchasing) else purchasing
    
        wp_det = households.get("will_purchase_deterministic")
        if wp_det is not None and torch.is_tensor(wp_det):
            purchasing_list_deterministic = (wp_det > 0).float().cpu().numpy().flatten().tolist()
        else:
            purchasing_list_deterministic = list(purchasing_list)
    
        # Try to get purchase probabilities from state if available
        # The purchase_probability should be stored in the policy output or state
        purchase_probabilities = None
        if "purchase_probability" in households:
            purchase_probabilities = households["purchase_probability"]
            if torch.is_tensor(purchase_probabilities):
                purchase_probabilities = purchase_probabilities.cpu().numpy().flatten().tolist()
        # If not available, we'll store None and note that we only have binary decisions

        # Get household IDs from agent states
        household_ids = agent_states.get("households", [])
        hh_ids = [h.get("household_id", i + 1) for i, h in enumerate(household_ids)] if household_ids else list(
            range(1, int(n_households) + 1)
        )

        result: Dict[str, Any] = {
            "scenario": scenario,
            "purchasing_count": purchasing_count,
            "purchase_rate": purchasing_count / max(n_households, 1.0),
            "total_revenue": float(total_spend.sum().item()),
            "total_units": float(quantity.sum().item()),
            "n_households": int(n_households),
            "household_predictions": {
                "household_ids": hh_ids,
                "purchased": purchasing_list,
                "purchased_deterministic": purchasing_list_deterministic,
                "purchase_probabilities": purchase_probabilities
                if purchase_probabilities is not None
                else purchasing_list,
            },
        }

        if ground_truth_map and auto_evaluate_unified:
            from evaluation_metrics import evaluate_aligned_binary_labels

            y_true = [ground_truth_map.get(int(hid), 0) for hid in hh_ids]
            result["evaluation_vs_ground_truth"] = {
                "final_will_purchase": evaluate_aligned_binary_labels(
                    hh_ids,
                    y_true,
                    purchasing_list,
                    label="final_will_purchase",
                ),
                "deterministic_will_purchase": evaluate_aligned_binary_labels(
                    hh_ids,
                    y_true,
                    purchasing_list_deterministic,
                    label="deterministic_will_purchase",
                ),
            }

        return result
    finally:
        set_transaction_history_prompts(None)
        if quiet:
            if _quiet_prev is None:
                os.environ.pop("PRICE_SIM_QUIET", None)
            else:
                os.environ["PRICE_SIM_QUIET"] = _quiet_prev
