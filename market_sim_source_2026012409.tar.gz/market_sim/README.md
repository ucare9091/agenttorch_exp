# Market Simulator with Extreme Winter Storm Weather Effects

A portable Docker container for running AgentTorch-based market simulations with household data and extreme winter storm weather effects.

This implementation uses the original AgentTorch large population model framework and follows the AgentTorch GitHub repository structure:
- Uses `Executor(model_module, pop_loader=population)` pattern
- Follows AgentTorch model package structure (`agenttorch_model/` with `yamls/config.yaml`)
- Uses AgentTorch population package structure (`agenttorch_population/` with pickle files)
- Uses `LoadPopulation` from `agent_torch.core.dataloader`
- **Integrates extreme winter storm weather data** to model weather effects on purchasing behavior

## Features

- **Weather Effects**: Models how extreme winter storms affect household purchasing decisions
  - Stockpiling behavior during storms
  - Reduced mobility due to severe weather
  - Income-dependent weather impact (higher income = better mobility)
- **Flexible Data Input**: Works with any CSV structure for household data
- **AgentTorch Framework**: Consistent with original AgentTorch framework and paper
- **Docker Ready**: Fully containerized for easy deployment

## Quick Start

### Prerequisites
- Docker installed and running
- Docker Compose (optional, but recommended)

### Using Docker Compose (Recommended)

1. **Build and run the simulation:**
   ```bash
   docker-compose up --build
   ```

2. **Run with weather data:**
   ```bash
   docker-compose run market-sim python run_simulation.py \
     --csv /app/data/households.csv \
     --weather-csv /app/data/weather_data.csv \
     --weather-day 0 \
     --output /app/output/results.json
   ```

3. **View logs:**
   ```bash
   docker-compose logs -f
   ```

4. **Stop the container:**
   ```bash
   docker-compose down
   ```

### Using Docker Directly

1. **Build the image:**
   ```bash
   docker build -t market-sim:latest .
   ```

2. **Run the simulation:**
   ```bash
   docker run --rm \
     -v $(pwd)/data:/app/data \
     -v $(pwd)/output:/app/output \
     market-sim:latest
   ```

3. **Run with weather data:**
   ```bash
   docker run --rm \
     -v $(pwd)/data:/app/data \
     -v $(pwd)/output:/app/output \
     market-sim:latest \
     python run_simulation.py \
       --csv /app/data/households.csv \
       --weather-csv /app/data/weather_data.csv \
       --weather-day 5 \
       --output /app/output/results.json \
       --new-price 3.49 \
       --baseline-price 2.49
   ```

## Directory Structure

```
market_sim/
├── Dockerfile              # Docker image definition
├── docker-compose.yml      # Docker Compose configuration
├── requirements.txt        # Python dependencies
├── .dockerignore          # Files to exclude from Docker build
├── run_simulation.py      # Main entry point script
├── runner_dbx.py         # Simulation runner logic
├── generate_weather_data.py  # Weather data generator
├── agenttorch_model/      # AgentTorch model definitions
│   └── substeps/         # Model substeps (purchase decisions with weather)
├── data/                  # Input data (mounted as volume)
│   ├── households.csv    # Household data CSV
│   └── weather_data.csv  # Weather data CSV (generated)
└── output/                # Output directory (mounted as volume)
    └── results.json      # Simulation results
```

## Weather Data

### Generating Weather Data

The simulation includes a weather data generator for extreme winter storms:

```bash
python generate_weather_data.py \
  --days 30 \
  --severity extreme \
  --start-date 2024-01-01 \
  --output data/weather_data.csv
```

**Severity Levels:**
- `moderate`: Light winter conditions
- `severe`: Heavy winter storms
- `extreme`: Extreme winter storm conditions (default)

**Weather Data Format:**

The weather CSV includes:
- `date`: Date in YYYY-MM-DD format
- `temperature_f`: Temperature in Fahrenheit
- `snowfall_inches`: Daily snowfall in inches
- `wind_speed_mph`: Wind speed in miles per hour
- `visibility_miles`: Visibility in miles
- `storm_intensity`: Storm intensity score (0-1)
- `weather_impact`: Combined weather impact score (0-1)
- `is_storm_day`: Binary indicator (1 = storm day, 0 = normal day)

### Weather Effects on Purchasing

The simulation models several weather effects:

1. **Stockpiling Effect**: During storms, households increase purchase probability and quantity (up to 40% increase in probability, 60% increase in quantity)

2. **Mobility Reduction**: Severe weather prevents shopping trips, especially for lower-income households
   - Higher income households have better mobility (delivery, better transportation)
   - Lower income households are more affected by weather

3. **Combined Effect**: The net effect combines stockpiling and mobility reduction, bounded between 30% reduction and 50% increase

## Input Data

### Household Data

The simulator works with **any CSV structure** - it automatically handles:
- **Any number of rows** (from 1 to millions)
- **Any column names** - uses intelligent matching to find required fields
- **Missing columns** - fills with sensible defaults
- **Extra columns** - ignored automatically

#### Required Fields (with flexible matching)

| Field | Possible Column Names |
|-------|----------------------|
| ID | `id`, `household_id`, `householdid`, `hh_id`, `hhid`, `household`, `hh` |
| Income | `income`, `household_income`, `hh_income`, `annual_income`, `salary`, `earnings`, `revenue` |
| Household Size | `household_size`, `hh_size`, `householdsize`, `people_in_hh`, `num_people`, `size`, `people`, `members`, `persons` |
| Children | `num_children`, `children`, `num_children_in_hh`, `kids`, `child`, `dependents` |
| Price Sensitivity | `price_sensitivity`, `price_sens`, `sensitivity`, `price_elasticity`, `elasticity`, `sens` |
| Location | `location`, `region`, `geo`, `geography`, `area`, `zip`, `zipcode`, `state`, `city` |

**Default Values** (used if column not found):
- ID: Auto-generated (1, 2, 3, ...)
- Income: $50,000
- Household Size: 2.0
- Children: 0.0
- Price Sensitivity: 0.5
- Location: "unknown"

## Configuration

### Simulation Parameters

You can customize the simulation using command-line arguments:

- `--csv`: Path to household CSV file (default: `/app/data/households.csv`)
- `--weather-csv`: Path to weather CSV file (optional, default: `None`)
- `--weather-day`: Index of weather day to use (default: `0`)
- `--output`: Path to output JSON file (default: `/app/output/results.json`)
- `--product-category`: Product category name (default: `"new_soft_drink_flavor"`)
- `--new-price`: New product price (default: `2.99`)
- `--baseline-price`: Baseline product price (default: `2.49`)
- `--device`: Device to use - `cpu` or `cuda` (default: `cpu`)

### Example: Storm Day Simulation

```bash
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py \
    --csv /app/data/households.csv \
    --weather-csv /app/data/weather_data.csv \
    --weather-day 5 \
    --output /app/output/results_storm.json \
    --new-price 3.99 \
    --baseline-price 2.99
```

### Example: Normal Day Simulation (No Weather)

```bash
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py \
    --csv /app/data/households.csv \
    --output /app/output/results_normal.json
```

## Output

The simulation generates a JSON file with the following metrics:

```json
{
  "scenario": {
    "product_category": "new_soft_drink_flavor",
    "new_price": 2.99,
    "baseline_price": 2.49
  },
  "weather": {
    "weather_impact": 0.756,
    "is_storm_day": 1.0
  },
  "n_households": 3000,
  "purchasing_count": 1023.0,
  "purchase_rate": 0.341,
  "total_revenue": 3051.45,
  "total_units": 1018.5
}
```

**Weather Impact Interpretation:**
- `weather_impact`: 0.0 = no impact, 1.0 = maximum impact
- `is_storm_day`: 1.0 = storm day, 0.0 = normal day

## AgentTorch Framework Consistency

This implementation follows the original AgentTorch framework:

1. **Model Structure**: Uses `agenttorch_model/` package with substeps registered via Registry
2. **Population Loading**: Uses `LoadPopulation` from `agent_torch.core.dataloader`
3. **Executor Pattern**: Uses `Executor(model_module, pop_loader=population)`
4. **Config YAML**: Dynamically generates `yamls/config.yaml` following AgentTorch schema
5. **Substeps**: Implements `SubstepAction` and `SubstepTransition` classes
6. **State Management**: Follows AgentTorch state structure with agents/environment/network

## Development

### Building for Development

```bash
docker build -t market-sim:dev .
```

### Running Interactive Shell

```bash
docker run -it --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  /bin/bash
```

### Testing Changes

1. Make changes to Python files
2. Rebuild: `docker-compose build`
3. Run: `docker-compose up`

## Dependencies

All dependencies are included in the Docker image:
- Python 3.11
- AgentTorch >= 0.6.0
- PyTorch >= 2.0.0
- Pandas >= 2.0.0
- NumPy >= 1.24.0
- Dask >= 2024.1.0
- PyArrow >= 10.0.0
- PyYAML >= 6.0

**Note**: The container is fully standalone - no external dependencies required beyond Docker itself.

## License

See your project license file.

## Support

For issues or questions, please refer to the AgentTorch documentation or your project maintainer.
