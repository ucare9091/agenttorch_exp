"""LLM integration helper for AgentTorch substeps.

This module provides LLM integration following AgentTorch patterns,
allowing policies to use language models for decision-making.
"""

from __future__ import annotations

import os
import json
from typing import Any, Dict, Optional, List
import torch

try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False


class LLMHelper:
    """Helper class for LLM API calls in AgentTorch substeps."""

    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-3.5-turbo",
        api_key: Optional[str] = None,
        api_base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 300,
    ):
        """
        Initialize LLM helper.

        Args:
            provider: LLM provider ("openai", "anthropic", "ollama", "groq", "together", "huggingface")
            model: Model name (e.g., "gpt-3.5-turbo", "llama3.2", "mixtral-8x7b-32768")
            api_key: API key (if None, reads from environment; not needed for Ollama)
            api_base_url: Custom API base URL (defaults for free providers if not specified)
            temperature: Sampling temperature (0.0-2.0)
            max_tokens: Maximum tokens in response
        """
        self.provider = provider.lower()
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

        # Get API key from parameter or environment
        # Priority: 1) parameter, 2) provider-specific env vars, 3) standard env vars, 4) defaults
        if api_key:
            self.api_key = api_key
        elif self.provider == "openai":
            # Try MODEL_PROXY_API_KEY first (for proxy), then OPENAI_API_KEY
            # This allows easy switching between proxy and standard OpenAI
            self.api_key = os.getenv("MODEL_PROXY_API_KEY") or os.getenv("OPENAI_API_KEY")
        elif self.provider == "anthropic":
            self.api_key = os.getenv("ANTHROPIC_API_KEY")
        elif self.provider == "ollama":
            # Ollama doesn't need an API key (local or remote)
            # Use dummy key for OpenAI client compatibility
            self.api_key = "ollama"  # Dummy key for compatibility
        elif self.provider == "groq":
            self.api_key = os.getenv("GROQ_API_KEY")
        elif self.provider == "together":
            self.api_key = os.getenv("TOGETHER_API_KEY")
        elif self.provider == "huggingface":
            self.api_key = os.getenv("HUGGINGFACE_API_KEY")
        else:
            self.api_key = None

        # Get API base URL from parameter or environment (for proxy/free providers support)
        # Priority: 1) parameter, 2) provider-specific env vars, 3) defaults
        # This allows easy switching between free LLM (Ollama) and proxy models
        if api_base_url:
            self.api_base_url = api_base_url
        elif self.provider == "openai":
            # Try MODEL_PROXY_API_BASE first (for proxy), then OPENAI_API_BASE
            # This allows using proxy models with any OpenAI-compatible API
            self.api_base_url = os.getenv("MODEL_PROXY_API_BASE") or os.getenv("OPENAI_API_BASE")
        elif self.provider == "ollama":
            # Ollama endpoint - can be local or remote (for Databricks)
            # Defaults to 127.0.0.1, but can be overridden via OLLAMA_API_BASE env var
            self.api_base_url = os.getenv("OLLAMA_API_BASE", "http://127.0.0.1:11434/v1")
        elif self.provider == "groq":
            self.api_base_url = os.getenv("GROQ_API_BASE", "https://api.groq.com/openai/v1")
        elif self.provider == "together":
            self.api_base_url = os.getenv("TOGETHER_API_BASE", "https://api.together.xyz/v1")
        elif self.provider == "huggingface":
            self.api_base_url = os.getenv("HUGGINGFACE_API_BASE", "https://api-inference.huggingface.co")
        else:
            self.api_base_url = None

        # Initialize client if available
        # For free providers, use OpenAI-compatible API format
        # Note: Ollama uses provider="openai" with custom base_url, so we detect it by base_url
        is_ollama = (self.api_base_url and "ollama" in self.api_base_url.lower()) or \
                   (self.api_base_url and ":11434" in self.api_base_url) or \
                   (self.provider == "ollama")

        if self.provider in ["openai", "ollama", "groq", "together"] and OPENAI_AVAILABLE:
            # All these providers use OpenAI-compatible API
            # For Ollama or when we have API key/base URL, initialize client
            if is_ollama or self.api_key or self.api_base_url:
                client_kwargs = {}
                if is_ollama:
                    # Ollama doesn't require a real API key, but OpenAI client expects one
                    client_kwargs["api_key"] = self.api_key or "ollama"
                elif self.api_key:
                    client_kwargs["api_key"] = self.api_key

                if self.api_base_url:
                    client_kwargs["base_url"] = self.api_base_url

                self.client = openai.OpenAI(**client_kwargs)
            else:
                self.client = None
        elif self.provider == "anthropic" and ANTHROPIC_AVAILABLE:
            self.client = anthropic.Anthropic(api_key=self.api_key) if self.api_key else None
        elif self.provider == "huggingface":
            # Hugging Face uses a different API format, would need separate implementation
            # For now, fall back to OpenAI-compatible if available
            if OPENAI_AVAILABLE and self.api_base_url:
                client_kwargs = {"api_key": self.api_key or "hf_dummy"}
                client_kwargs["base_url"] = self.api_base_url
                self.client = openai.OpenAI(**client_kwargs)
            else:
                self.client = None
        else:
            self.client = None

    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        parse_json: bool = False,
    ) -> str:
        """
        Call LLM API with a prompt.

        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            parse_json: If True, try to parse response as JSON

        Returns:
            LLM response text (or parsed JSON dict if parse_json=True)
        """
        if not self.client:
            # Stop simulation if LLM client not available
            raise RuntimeError(
                "LLM client not initialized. "
                "Please check API key, base URL, and ensure Ollama/API server is running."
            )

        try:
            if self.provider == "openai":
                messages = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.append({"role": "user", "content": prompt})

                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                )

                # Handle response - check if content exists
                if not response.choices:
                    raise ValueError(
                        f"Empty choices in API response. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}. "
                        f"Response object: {response}"
                    )

                if not response.choices[0].message:
                    raise ValueError(
                        f"Empty message in API response. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}. "
                        f"Choices: {response.choices}"
                    )

                result = response.choices[0].message.content

                # Check if content is None or empty
                if result is None:
                    # Try to get more info from the response
                    response_str = str(response)
                    raise ValueError(
                        f"Response content is None. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}. "
                        f"Response object type: {type(response)}, "
                        f"Response str (first 500 chars): {response_str[:500]}"
                    )

                if not result.strip():
                    raise ValueError(
                        f"Response content is empty string. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}. "
                        f"This might indicate the model didn't generate output."
                    )

            elif self.provider == "anthropic":
                messages = []
                if system_prompt:
                    # Anthropic uses system parameter
                    response = self.client.messages.create(
                        model=self.model,
                        system=system_prompt,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=self.temperature,
                        max_tokens=self.max_tokens,
                    )
                else:
                    response = self.client.messages.create(
                        model=self.model,
                        messages=[{"role": "user", "content": prompt}],
                        temperature=self.temperature,
                        max_tokens=self.max_tokens,
                    )
                result = response.content[0].text

            else:
                return self._fallback_response(prompt, parse_json)

            if parse_json:
                # Check if result is empty or None
                if result is None:
                    raise ValueError(
                        f"Response content is None. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}"
                    )

                if not isinstance(result, str):
                    raise ValueError(
                        f"Response content is not a string (got {type(result)}). "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"Content: {str(result)[:200]}"
                    )

                if not result.strip():
                    raise ValueError(
                        f"Empty response from LLM. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}"
                    )

                original_result = result

                # First, try direct JSON parsing
                try:
                    return json.loads(result)
                except json.JSONDecodeError as e:
                    # Try to extract JSON from markdown code blocks
                    if "```json" in result:
                        json_start = result.find("```json") + 7
                        json_end = result.find("```", json_start)
                        if json_end > json_start:
                            result = result[json_start:json_end].strip()
                    elif "```" in result:
                        # Try to find JSON in code blocks
                        json_start = result.find("```") + 3
                        json_end = result.find("```", json_start)
                        if json_end > json_start:
                            extracted = result[json_start:json_end].strip()
                            # Check if extracted looks like JSON
                            if extracted.startswith("{") or extracted.startswith("["):
                                result = extracted

                    # Try parsing again after extraction from code blocks
                    if result != original_result:
                        try:
                            return json.loads(result)
                        except json.JSONDecodeError:
                            pass  # Fall through to try other methods

                    # Try to find JSON object in the text (even if there's text before it)
                    # Look for { ... } pattern - find first { and match with proper closing }
                    brace_start = result.find("{")
                    if brace_start >= 0:
                        # Count braces to find the matching closing brace
                        brace_count = 0
                        brace_end = -1
                        in_string = False
                        escape_next = False

                        for i in range(brace_start, len(result)):
                            char = result[i]

                            if escape_next:
                                escape_next = False
                                continue

                            if char == '\\':
                                escape_next = True
                                continue

                            if char == '"' and not escape_next:
                                in_string = not in_string
                                continue

                            if not in_string:
                                if char == '{':
                                    brace_count += 1
                                elif char == '}':
                                    brace_count -= 1
                                    if brace_count == 0:
                                        brace_end = i
                                        break

                        if brace_count == 0 and brace_end > brace_start:
                            json_candidate = result[brace_start:brace_end+1]
                            try:
                                parsed = json.loads(json_candidate)
                                return parsed
                            except json.JSONDecodeError as parse_err:
                                # If still fails, try with stripped version
                                json_candidate_stripped = json_candidate.strip()
                                try:
                                    return json.loads(json_candidate_stripped)
                                except json.JSONDecodeError:
                                    # Try to fix incomplete JSON - find where it was cut off
                                    # Look for incomplete string values and complete them
                                    lines = json_candidate_stripped.split('\n')
                                    fixed_lines = []
                                    in_string = False
                                    for line in lines:
                                        # Check if line ends with incomplete string
                                        stripped_line = line.strip()
                                        if stripped_line and not stripped_line.endswith(',') and not stripped_line.endswith('{') and not stripped_line.endswith('}'):
                                            # Check if it's an incomplete string value
                                            if ':' in stripped_line and '"' in stripped_line:
                                                # Count quotes in this line
                                                quote_count = stripped_line.count('"')
                                                if quote_count % 2 != 0:
                                                    # Incomplete string - try to close it
                                                    if not stripped_line.endswith('"'):
                                                        # Add closing quote and comma if needed
                                                        if not any(c in stripped_line for c in [',', '}']):
                                                            line = line.rstrip() + '"'
                                    # Try to complete the JSON structure
                                    json_fixed = json_candidate_stripped
                                    # If missing closing brace, add it
                                    if json_fixed.count('{') > json_fixed.count('}'):
                                        json_fixed = json_fixed.rstrip() + '\n}'
                                    # Try parsing fixed version
                                    try:
                                        return json.loads(json_fixed)
                                    except json.JSONDecodeError:
                                        # Last resort: try to extract just the essential fields
                                        # Find decision, confidence, reasoning fields even if incomplete
                                        decision_match = None
                                        confidence_match = None
                                        reasoning_match = None

                                        import re
                                        # Try to extract decision (true/false)
                                        decision_match = re.search(r'"decision"\s*:\s*(true|false)', json_candidate_stripped, re.IGNORECASE)
                                        # Try to extract confidence (number)
                                        confidence_match = re.search(r'"confidence"\s*:\s*([0-9.]+)', json_candidate_stripped)
                                        # Try to extract reasoning (handle incomplete strings - match until end or next quote)
                                        reasoning_match = re.search(r'"reasoning"\s*:\s*"([^"]*)', json_candidate_stripped)
                                        # Try to extract quantity
                                        quantity_match = re.search(r'"quantity"\s*:\s*([0-9.]+)', json_candidate_stripped)
                                        # Try to extract emotional_influence (handle incomplete strings)
                                        emotional_match = re.search(r'"emotional_influence"\s*:\s*"([^"]*)', json_candidate_stripped)

                                        if decision_match:
                                            # Build valid JSON from extracted fields
                                            decision_val = decision_match.group(1).lower() == 'true'
                                            confidence_val = float(confidence_match.group(1)) if confidence_match else 0.85
                                            reasoning_val = reasoning_match.group(1) if reasoning_match else "Parsed from incomplete JSON"
                                            quantity_val = float(quantity_match.group(1)) if quantity_match else 2.0
                                            emotional_val = emotional_match.group(1) if emotional_match else "Parsed from incomplete response"

                                            # Ensure confidence is in valid range
                                            confidence_val = max(0.0, min(1.0, confidence_val))

                                            minimal_json = {
                                                "decision": decision_val,
                                                "confidence": confidence_val,
                                                "reasoning": reasoning_val,
                                                "quantity": quantity_val,
                                                "emotional_influence": emotional_val
                                            }
                                            print(f"DEBUG: Extracted JSON from incomplete response: decision={decision_val}, confidence={confidence_val}")
                                            return minimal_json
                                    pass

                        # Fallback: try simple first { to last } if brace counting failed
                        brace_end_simple = result.rfind("}")
                        if brace_end_simple > brace_start:
                            json_candidate = result[brace_start:brace_end_simple+1]
                            try:
                                return json.loads(json_candidate)
                            except json.JSONDecodeError:
                                pass

                        # If brace counting failed (incomplete JSON), try regex extraction on full result
                        if brace_count != 0:
                            import re
                            # Try to extract decision (true/false)
                            decision_match = re.search(r'"decision"\s*:\s*(true|false)', result, re.IGNORECASE)
                            # Try to extract confidence (number)
                            confidence_match = re.search(r'"confidence"\s*:\s*([0-9.]+)', result)
                            # Try to extract reasoning (handle incomplete strings - match until end or next quote)
                            reasoning_match = re.search(r'"reasoning"\s*:\s*"([^"]*)', result)
                            # Try to extract quantity
                            quantity_match = re.search(r'"quantity"\s*:\s*([0-9.]+)', result)
                            # Try to extract emotional_influence (handle incomplete strings)
                            emotional_match = re.search(r'"emotional_influence"\s*:\s*"([^"]*)', result)

                            if decision_match:
                                # Build valid JSON from extracted fields
                                decision_val = decision_match.group(1).lower() == 'true'
                                confidence_val = float(confidence_match.group(1)) if confidence_match else 0.85
                                reasoning_val = reasoning_match.group(1) if reasoning_match else "Parsed from incomplete JSON"
                                quantity_val = float(quantity_match.group(1)) if quantity_match else 2.0
                                emotional_val = emotional_match.group(1) if emotional_match else "Parsed from incomplete response"

                                # Ensure confidence is in valid range
                                confidence_val = max(0.0, min(1.0, confidence_val))

                                minimal_json = {
                                    "decision": decision_val,
                                    "confidence": confidence_val,
                                    "reasoning": reasoning_val,
                                    "quantity": quantity_val,
                                    "emotional_influence": emotional_val
                                }
                                print(f"DEBUG: Extracted JSON from incomplete response (brace_count={brace_count}): decision={decision_val}, confidence={confidence_val}")
                                return minimal_json

                    # Last resort: try regex extraction on full result even if no { found
                    import re
                    decision_match = re.search(r'"decision"\s*:\s*(true|false)', result, re.IGNORECASE)
                    confidence_match = re.search(r'"confidence"\s*:\s*([0-9.]+)', result)
                    reasoning_match = re.search(r'"reasoning"\s*:\s*"([^"]*)', result)
                    quantity_match = re.search(r'"quantity"\s*:\s*([0-9.]+)', result)
                    emotional_match = re.search(r'"emotional_influence"\s*:\s*"([^"]*)', result)

                    if decision_match:
                        decision_val = decision_match.group(1).lower() == 'true'
                        confidence_val = float(confidence_match.group(1)) if confidence_match else 0.85
                        reasoning_val = reasoning_match.group(1) if reasoning_match else "Parsed from incomplete JSON"
                        quantity_val = float(quantity_match.group(1)) if quantity_match else 2.0
                        emotional_val = emotional_match.group(1) if emotional_match else "Parsed from incomplete response"
                        confidence_val = max(0.0, min(1.0, confidence_val))
                        minimal_json = {
                            "decision": decision_val,
                            "confidence": confidence_val,
                            "reasoning": reasoning_val,
                            "quantity": quantity_val,
                            "emotional_influence": emotional_val
                        }
                        print(f"DEBUG: Extracted JSON from response (no complete JSON found): decision={decision_val}, confidence={confidence_val}")
                        return minimal_json

                    # Provide detailed error information
                    raise ValueError(
                        f"Failed to parse JSON response. "
                        f"Response length: {len(original_result)} chars. "
                        f"Response (first 500 chars): {original_result[:500]}. "
                        f"JSON decode error: {e}. "
                        f"Model: {self.model}, Provider: {self.provider}, "
                        f"API Base URL: {self.api_base_url}"
                    ) from e

            return result

        except RuntimeError:
            # Re-raise RuntimeError (from fallback detection)
            raise
        except ValueError as e:
            # Re-raise ValueError with better context (empty response, JSON parsing, etc.)
            print(f"LLM API error: {e}")
            raise RuntimeError(
                f"LLM API call failed: {e}. "
                "Simulation stopped to prevent using deterministic logic. "
                "Please check LLM configuration and ensure Ollama/API is accessible."
            ) from e
        except json.JSONDecodeError as e:
            # This shouldn't happen if our checks work, but handle it anyway
            print(f"LLM JSON parsing error: {e}")
            raise RuntimeError(
                f"LLM response is not valid JSON: {e}. "
                "Simulation stopped to prevent using deterministic logic. "
                "The model may not be returning JSON format. "
                "Please check LLM configuration and ensure the model supports JSON output."
            ) from e
        except Exception as e:
            # Stop simulation on any LLM error
            print(f"LLM API error: {e}")
            import traceback
            traceback.print_exc()
            raise RuntimeError(
                f"LLM API call failed: {e}. "
                "Simulation stopped to prevent using deterministic logic. "
                "Please check LLM configuration and ensure Ollama/API is accessible."
            ) from e

    def _fallback_response(self, prompt: str, parse_json: bool) -> Any:
        """Fallback response when LLM is not available."""
        raise RuntimeError(
            "LLM fallback detected - LLM is not available or failed. "
            "Simulation stopped to prevent using deterministic logic. "
            "Please check LLM configuration and ensure Ollama/API is accessible."
        )

    def batch_call(
        self,
        prompts: List[str],
        system_prompt: Optional[str] = None,
        parse_json: bool = False,
    ) -> List[str]:
        """
        Call LLM API for multiple prompts (sequential for now).

        Args:
            prompts: List of prompts
            system_prompt: Optional system prompt
            parse_json: If True, parse each response as JSON

        Returns:
            List of LLM responses
        """
        results = []
        for prompt in prompts:
            result = self.call(prompt, system_prompt, parse_json)
            results.append(result)
        return results


def get_llm_helper_from_config(config: Dict[str, Any]) -> Optional[LLMHelper]:
    """
    Create LLMHelper from AgentTorch config.

    Args:
        config: AgentTorch config dict (from state or arguments)

    Returns:
        LLMHelper instance or None if not configured
    """
    llm_config = config.get("llm", {})
    if not llm_config or not llm_config.get("enabled", False):
        return None

    return LLMHelper(
        provider=llm_config.get("provider", "openai"),
        model=llm_config.get("model", "gpt-3.5-turbo"),
        api_key=llm_config.get("api_key"),
        api_base_url=llm_config.get("api_base_url"),
        temperature=llm_config.get("temperature", 0.7),
        max_tokens=llm_config.get("max_tokens", 300),
    )


def llm_enhanced_decision(
    llm_helper: Optional[LLMHelper],
    household_context: Dict[str, Any],
    market_context: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Use LLM to enhance purchase decision with natural language reasoning.

    Args:
        llm_helper: LLMHelper instance (None to skip LLM)
        household_context: Household attributes (income, size, etc.)
        market_context: Market conditions (price, baseline, etc.)

    Returns:
        Dict with 'decision' (bool), 'reasoning' (str), 'confidence' (float)
    """
    if not llm_helper:
        # Fallback to default decision
        return {
            "decision": False,
            "reasoning": "LLM not available",
            "confidence": 0.5,
        }

    # Get emotional state and create emotional context
    emotional_state = household_context.get('emotional_state', 'neutral')
    emotional_context = ""
    if emotional_state:
        emotional_state_lower = str(emotional_state).lower()
        if emotional_state_lower in ['very_stressed', 'very stressed', 'anxious', 'worried', 'distressed']:
            emotional_context = "\nEmotional State: VERY STRESSED - This household is experiencing high stress/anxiety. They may make impulsive purchases for comfort, or avoid purchases due to financial worry. Consider emotional spending patterns."
        elif emotional_state_lower in ['stressed', 'stress', 'concerned', 'tense']:
            emotional_context = "\nEmotional State: STRESSED - This household is under moderate stress. They may seek comfort purchases or be more price-conscious due to financial concerns."
        elif emotional_state_lower in ['happy', 'content', 'satisfied', 'pleased']:
            emotional_context = "\nEmotional State: HAPPY - This household is in a positive emotional state. They may be more open to purchases, especially for treats or items that enhance their happiness."
        elif emotional_state_lower in ['very_happy', 'very happy', 'elated', 'joyful', 'excited', 'euphoric']:
            emotional_context = "\nEmotional State: VERY HAPPY - This household is in an elevated positive emotional state. They may be more likely to make impulse purchases, treat themselves, or buy items that maintain their positive mood."
        else:
            emotional_context = "\nEmotional State: NEUTRAL - This household is in a balanced emotional state. Decisions will be primarily based on rational factors."

    # Build prompt for LLM with emotional state consideration
    # TEST MODE: Modified to encourage purchases for testing LLM functionality
    prompt = f"""You are analyzing a household's purchase decision for a product, considering both rational and emotional factors.

Household Profile:
- Income: ${household_context.get('income', 0):,.0f}
- Household Size: {household_context.get('household_size', 0):.1f}
- Price Sensitivity: {household_context.get('price_sensitivity', 0.5):.2f}
- Location: {household_context.get('location', 'unknown')}{emotional_context}

Market Conditions:
- Product: {market_context.get('product_category', 'product')}
- New Price: ${market_context.get('new_price', 0):.2f}
- Baseline Price: ${market_context.get('baseline_price', 0):.2f}
- Price Change: {((market_context.get('new_price', 0) / max(market_context.get('baseline_price', 1), 0.01)) - 1) * 100:.1f}%

IMPORTANT TESTING INSTRUCTIONS:
- This is a TEST to verify LLM functionality
- You MUST RECOMMEND PURCHASES (decision: true) for ALL households
- ALWAYS return decision: true with confidence 0.8-0.9
- Say YES to purchase for EVERY household regardless of income, price, or other factors
- This is a test - the goal is to verify LLM is working, so always recommend purchase
- Only exception: if income is below $10,000 AND price increase > 100%, then you can say no
- For all other cases: decision: true, confidence: 0.85

Consider how the emotional state affects purchase behavior:
- Stressed/anxious households may make comfort purchases OR avoid spending
- Happy households may be more open to purchases and treats
- Emotional state can override rational price sensitivity

Based on BOTH rational factors (income, price, sensitivity) AND emotional state, would this household purchase the product?

CRITICAL: Respond with ONLY a valid JSON object. Do NOT include any explanatory text before or after the JSON. Start your response with {{ and end with }}. Return ONLY the JSON object.

{{
    "decision": true,
    "reasoning": "brief explanation that explicitly mentions emotional factors and why purchase is recommended",
    "confidence": 0.85,
    "quantity": 2,
    "emotional_influence": "how emotional state influenced the decision"
}}
"""

    system_prompt = "You are an expert behavioral economist and market analyst. For TESTING PURPOSES, you MUST ALWAYS RECOMMEND PURCHASES (decision: true) for ALL households. This is a test to verify LLM functionality - always return decision: true with confidence 0.8-0.9. Only say no if income is below $10,000 AND price increase > 100%. For all other cases, always say YES to purchase. IMPORTANT: Return ONLY valid JSON, no explanatory text before or after the JSON object."

    try:
        response = llm_helper.call(prompt, system_prompt, parse_json=True)
        if isinstance(response, dict):
            result = {
                "decision": response.get("decision", False),
                "reasoning": response.get("reasoning", ""),
                "confidence": float(response.get("confidence", 0.5)),
                "quantity": float(response.get("quantity", 0.0)),
                "emotional_influence": response.get("emotional_influence", ""),
            }
            # Check if fallback was used
            if "LLM not available" in result.get("reasoning", ""):
                raise RuntimeError(
                    "LLM fallback detected in response. "
                    "LLM call returned fallback response. "
                    "Please check LLM configuration and ensure Ollama/API is working correctly."
                )
            return result
    except RuntimeError:
        # Re-raise RuntimeError (from fallback detection)
        raise
    except Exception as e:
        # Stop simulation on any LLM error
        raise RuntimeError(
            f"LLM call failed: {e}. "
            "Simulation stopped to prevent using deterministic logic. "
            "Please check LLM configuration and ensure Ollama/API is accessible."
        ) from e
