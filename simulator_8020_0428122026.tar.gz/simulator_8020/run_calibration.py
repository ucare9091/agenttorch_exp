#!/usr/bin/env python3
"""
Gradient-based calibration: sets simulation_metadata.calibration and learnable
purchase_logit_bias via build_model_config(..., calibration=True). Expects a
unified table with a ground-truth label column. Trains with BCE on purchase
probability vs labels (LLM off). Run from bundle root after pip install -r
requirements.txt and the dataloader/initializer fix scripts.

Example:
  python run_calibration.py --csv data/unified_panel_5k_sample.parquet --epochs 30 --lr 0.15
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from bundle_runtime_check import ensure_pyarrow_for_agent_stack

ensure_pyarrow_for_agent_stack()

from agent_torch.core.dataloader import LoadPopulation
from agent_torch.core.executor import Executor

from runner_dbx import (
    apply_simulation_seed,
    build_agent_states,
    build_model_config,
    household_table_and_ground_truth_from_unified_panel,
    load_transaction_history_table,
    write_population_pickles,
)


def main() -> int:
    p = argparse.ArgumentParser(description="Calibrate purchase_logit_bias against unified ground truth (BCE)")
    p.add_argument("--csv", type=str, required=True, help="Unified Parquet/CSV path (driver-local or dbfs:...)")
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--lr", type=float, default=0.1)
    args = p.parse_args()

    try:
        base_dir = Path(__file__).resolve().parent
    except NameError:
        base_dir = Path.cwd()

    apply_simulation_seed(args.seed)

    raw = load_transaction_history_table(args.csv)
    hdf, gt_map = household_table_and_ground_truth_from_unified_panel(raw)
    if not gt_map:
        print("Error: unified table must include a ground-truth label column.", file=sys.stderr)
        return 1

    agent_states = build_agent_states(hdf)
    write_population_pickles(base_dir, agent_states)
    build_model_config(
        base_dir,
        agent_states,
        device=args.device,
        product_category="new_ice_cream_flavor",
        new_price=4.99,
        baseline_price=3.99,
        llm_config=None,
        calibration=True,
    )

    import importlib
    import types

    population_dir = base_dir / "agenttorch_population"
    sys.path.insert(0, str(base_dir.resolve()))
    model_module = importlib.import_module("agenttorch_model")
    try:
        population_module = importlib.import_module("agenttorch_population")
    except (ModuleNotFoundError, ImportError):
        population_module = types.ModuleType("agenttorch_population")
        population_module.__path__ = [str(population_dir)]
        sys.modules["agenttorch_population"] = population_module

    string_pickle_files = ["location.pickle", "emotional_state.pickle"]
    temp_files: dict = {}
    temp_dir = base_dir / "_temp_population_strings"
    temp_dir.mkdir(exist_ok=True)
    for filename in string_pickle_files:
        src = population_dir / filename
        if src.exists():
            temp_path = temp_dir / filename
            src.rename(temp_path)
            temp_files[filename] = temp_path
    try:
        population = LoadPopulation(population_module)
    finally:
        for filename, temp_path in temp_files.items():
            temp_path.rename(population_dir / filename)
        try:
            temp_dir.rmdir()
        except OSError:
            pass

    executor = Executor(model_module, pop_loader=population)
    executor.init()
    runner = executor.runner

    dev = torch.device(args.device)
    hh_list = agent_states["households"]
    y_list = [float(gt_map.get(int(h.get("household_id", 0)), 0)) for h in hh_list]
    y = torch.tensor(y_list, device=dev, dtype=torch.float32).view(-1, 1)

    pol = runner.initializer.policy_function["0"]["households"]["purchase_decision"]
    opt = torch.optim.Adam(pol.parameters(), lr=args.lr)

    def _metrics_no_grad() -> tuple[float, float]:
        with torch.no_grad():
            state = runner.state
            obs = runner.controller.observe(state, runner.initializer.observation_function, "households")
            out = pol(state, obs)
            probs = out["purchase_probability"].to(device=dev, dtype=torch.float32)
            bce = F.binary_cross_entropy(probs, y).item()
            pred = (probs >= 0.5).float()
            acc = (pred == y).float().mean().item()
        return bce, acc

    bce0, acc0 = _metrics_no_grad()
    print(f"Before calibration: BCE={bce0:.6f}  accuracy@0.5={acc0:.6f}")

    for epoch in range(args.epochs):
        opt.zero_grad(set_to_none=True)
        state = runner.state
        obs = runner.controller.observe(state, runner.initializer.observation_function, "households")
        out = pol(state, obs)
        probs = out["purchase_probability"].to(device=dev, dtype=torch.float32)
        loss = F.binary_cross_entropy(probs, y)
        loss.backward()
        opt.step()
        if epoch % 5 == 0 or epoch == args.epochs - 1:
            with torch.no_grad():
                print(f"epoch {epoch:4d}  loss={loss.item():.6f}")

    bce1, acc1 = _metrics_no_grad()
    print(f"After calibration:  BCE={bce1:.6f}  accuracy@0.5={acc1:.6f}")

    print("Calibration finished. Learnable policy parameters:")
    for n, v in pol.named_parameters():
        print(f"  {n}: {v.detach().cpu().numpy().ravel()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
