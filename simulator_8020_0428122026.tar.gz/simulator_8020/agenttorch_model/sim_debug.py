"""Verbose DEBUG prints for simulation (disable with PRICE_SIM_QUIET=1 or run_simulation(..., quiet=True))."""

from __future__ import annotations

import os


def is_sim_quiet() -> bool:
    v = os.environ.get("PRICE_SIM_QUIET", "").strip().lower()
    return v in ("1", "true", "yes")


def dbg_print(*args, **kwargs) -> None:
    if is_sim_quiet():
        return
    print(*args, **kwargs)
