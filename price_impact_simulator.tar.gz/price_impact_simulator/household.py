"""
Household model for price impact simulation
Handles purchase decisions based on household attributes and product prices
"""

import numpy as np
from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class PurchaseDecision:
    """Result of a household purchase decision"""
    will_purchase: bool
    quantity: float
    total_spend: float
    price_sensitivity_factor: float
    household_id: int


class Household:
    """
    Represents a household with attributes that influence purchase behavior
    Works with real-world data containing 581 attributes
    """

    def __init__(self, household_id: int, attributes: Dict):
        """
        Initialize household from real-world data

        Args:
            household_id: Unique household identifier
            attributes: Dictionary of household attributes (581 attributes from real data)
        """
        self.household_id = household_id
        self.attributes = attributes

        # Extract key attributes for purchase decisions
        # These will be mapped from your 581 attributes
        # Convert to proper types to avoid TypeError
        income = self._get_attribute('income', default=50000)
        self.income = float(income) if income is not None else 50000
        
        household_size = self._get_attribute('household_size', default=2)
        self.household_size = int(float(household_size)) if household_size is not None else 2
        
        price_sensitivity = self._get_attribute('price_sensitivity', default=0.5)
        self.price_sensitivity = float(price_sensitivity) if price_sensitivity is not None else 0.5
        
        shopping_frequency = self._get_attribute('shopping_frequency', default=7.0)
        self.shopping_frequency = float(shopping_frequency) if shopping_frequency is not None else 7.0
        
        # Preferred categories (can be derived from attributes)
        preferred_categories = self._get_attribute('preferred_categories', default=['produce', 'dairy'])
        if isinstance(preferred_categories, str):
            self.preferred_categories = [cat.strip() for cat in preferred_categories.split(',')]
        elif isinstance(preferred_categories, list):
            self.preferred_categories = preferred_categories
        else:
            self.preferred_categories = ['produce', 'dairy']

    def _get_attribute(self, key: str, default=None):
        """Get attribute value, trying common variations of the key name"""
        # Try exact match
        if key in self.attributes:
            return self.attributes[key]

        # Try case variations
        for attr_key in self.attributes.keys():
            if attr_key.lower() == key.lower():
                return self.attributes[attr_key]

        # Try partial matches (for attributes like "household_income", "annual_income", etc.)
        key_lower = key.lower()
        for attr_key in self.attributes.keys():
            if key_lower in attr_key.lower() or attr_key.lower() in key_lower:
                return self.attributes[attr_key]

        return default

    def decide_purchase(self, product_category: str, price: float,
                       baseline_price: Optional[float] = None) -> PurchaseDecision:
        """
        Decide whether to purchase a product at given price

        Args:
            product_category: Category of product (e.g., 'produce', 'dairy')
            price: Current price per unit
            baseline_price: Original/baseline price for comparison

        Returns:
            PurchaseDecision with purchase details
        """
        # Calculate price change impact (ensure prices are numeric)
        price = float(price) if price is not None else 0.0
        baseline_price = float(baseline_price) if baseline_price is not None and baseline_price > 0 else price
        
        if baseline_price and baseline_price > 0:
            price_change_pct = (price - baseline_price) / baseline_price
        else:
            price_change_pct = 0.0

        # Base purchase probability
        # For new products (not in existing categories), use lower base probability
        # For existing preferred categories, use higher probability
        # Ensure preferred_categories is a list
        preferred_list = self.preferred_categories if isinstance(self.preferred_categories, list) else []
        product_cat_str = str(product_category) if product_category else ""
        
        if product_cat_str.startswith('new_') or 'new' in product_cat_str.lower():
            # New product (e.g., "new_soft_drink_flavor", "new_ice_cream_flavor")
            base_probability = 0.4  # Lower initial adoption for new products
        elif product_category in preferred_list:
            # Existing preferred category
            base_probability = 0.9
        else:
            # Existing category but not preferred
            base_probability = 0.7

        # Adjust for price sensitivity
        # Ensure price_sensitivity is numeric
        price_sens = float(self.price_sensitivity) if self.price_sensitivity is not None else 0.5
        price_sens = max(0.0, min(1.0, price_sens))  # Bound to [0, 1]
        
        # Price-sensitive households are more affected by price increases
        if price_change_pct > 0:  # Price increase
            sensitivity_impact = price_sens * price_change_pct * 2.0
            purchase_probability = base_probability * (1.0 - min(sensitivity_impact, 0.8))
        else:  # Price decrease
            sensitivity_impact = price_sens * abs(price_change_pct) * 0.5
            purchase_probability = base_probability * (1.0 + min(sensitivity_impact, 0.5))

        # Income constraint: higher income = less price sensitive
        # Ensure income is numeric
        income_num = float(self.income) if self.income is not None else 50000.0
        income_factor = min(1.0, income_num / 100000.0)
        purchase_probability = float(purchase_probability) * (0.7 + 0.3 * income_factor)
        
        # Ensure probability is bounded [0, 1]
        purchase_probability = max(0.0, min(1.0, float(purchase_probability)))

        # Stochastic decision
        will_purchase = np.random.random() < purchase_probability

        # Calculate quantity if purchasing
        if will_purchase:
            # Base quantity from household size (ensure household_size is numeric)
            household_size_num = float(self.household_size) if self.household_size is not None else 2.0
            base_quantity = max(1.0, household_size_num * 0.5)

            # Adjust for price (buy more if price decreased, less if increased)
            price_change_pct = float(price_change_pct)
            if price_change_pct < 0:
                quantity = base_quantity * (1.0 - price_change_pct * 0.3)
            else:
                quantity = base_quantity * (1.0 - price_change_pct * 0.5)

            quantity = max(0.5, float(quantity))  # Minimum quantity
            total_spend = float(price) * quantity
        else:
            quantity = 0.0
            total_spend = 0.0

        return PurchaseDecision(
            will_purchase=will_purchase,
            quantity=float(quantity),
            total_spend=float(total_spend),
            price_sensitivity_factor=float(self.price_sensitivity),
            household_id=int(self.household_id)
        )

    def get_key_attributes(self) -> Dict:
        """Get key attributes for analysis"""
        return {
            'household_id': self.household_id,
            'income': self.income,
            'household_size': self.household_size,
            'price_sensitivity': self.price_sensitivity,
            'shopping_frequency': self.shopping_frequency,
            'preferred_categories': self.preferred_categories
        }

