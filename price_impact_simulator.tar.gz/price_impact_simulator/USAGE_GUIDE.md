# Step-by-Step Usage Guide for Databricks

## Step 1: Extract the Archive

In a Databricks notebook cell:

```python
import tarfile

# Extract the archive
with tarfile.open('price_impact_simulator_20260107.tar.gz', 'r:gz') as tar:
    tar.extractall('.')

# Add to Python path
import sys
sys.path.append('./price_impact_simulator')
```

## Step 2: Install Dependencies

```python
%pip install numpy pandas pyarrow
```

## Step 3: Upload Your Real-World CSV File

**Option A: Upload via UI**
1. Go to Workspace → Create → File Upload
2. Upload your `households.csv` file (3000 rows × 581 columns)
3. Note the path (e.g., `/Workspace/Users/your_email@domain.com/households.csv`)

**Option B: Upload to DBFS**
```python
# Upload your CSV file to DBFS
dbutils.fs.put("/mnt/your_data/households.csv", "local_file_path", True)
```

**Option C: Place in data/ directory**
```python
# Create data directory and place your CSV there
# Path will be: ./data/households.csv or /Workspace/.../data/households.csv
```

## Step 4: Run the Simulator

### Method 1: Using Python Code (Recommended)

```python
from price_impact_simulator import PriceImpactSimulator

# Initialize with your CSV file path
# Use relative path if in same directory, or full path
simulator = PriceImpactSimulator(
    household_data="data/households.csv"  # or full path like "/Workspace/Users/.../households.csv"
)

# Define your price scenario for new product
scenario = {
    'product_category': 'new_soft_drink_flavor',  # or 'new_ice_cream_flavor', etc.
    'new_price': 2.99,  # Your new product price
    'baseline_price': 2.49  # Competitive/previous price
}

# Run analysis (10 trials for statistical robustness)
results = simulator.analyze_price_impact(scenario, n_trials=10)

# Generate report
simulator.generate_report(results, output_dir="output")
```

### Method 2: Using Command Line

```python
%sh
cd /Workspace/Users/your_email@domain.com/
python price_impact_simulator/run_analysis.py \
  --data data/households.csv \
  --category new_soft_drink_flavor \
  --new-price 2.99 \
  --baseline-price 2.49 \
  --trials 10 \
  --output-dir output
```

## Step 5: Check Simulation Results

After running, check these files in the `output/` directory:

### 1. **Text Report** (Human-readable)
```
output/price_impact_report_YYYYMMDD_HHMMSS.txt
```
**Contains:**
- Question and scenario
- Baseline behavior
- New price behavior
- Impact analysis (revenue change, purchase rate change)
- Household segmentation
- Conclusion

### 2. **JSON Results** (Machine-readable)
```
output/price_impact_results_YYYYMMDD_HHMMSS.json
```
**Contains:**
- All metrics in structured format
- Baseline results
- New price results
- Impact calculations
- Segmentation data

### 3. **View Results in Notebook**

```python
import json
from pathlib import Path

# Find the latest results file
output_dir = Path("output")
json_files = list(output_dir.glob("price_impact_results_*.json"))
latest_file = max(json_files, key=lambda p: p.stat().st_mtime)

# Load and display
with open(latest_file) as f:
    results = json.load(f)

# View key metrics
print("Purchase Rate:", f"{results['new_price_results']['purchase_rate']*100:.1f}%")
print("Revenue Impact:", f"${results['impact']['revenue_change']:+,.2f}")
print("Revenue Change %:", f"{results['impact']['revenue_change_pct']:+.1f}%")
```

## Quick Example: Complete Workflow

```python
# 1. Extract (if not done)
import tarfile
import sys
with tarfile.open('price_impact_simulator_20260107.tar.gz', 'r:gz') as tar:
    tar.extractall('.')
sys.path.append('./price_impact_simulator')

# 2. Install dependencies
%pip install numpy pandas pyarrow

# 3. Run simulation
from price_impact_simulator import PriceImpactSimulator

simulator = PriceImpactSimulator(household_data="data/households.csv")

scenario = {
    'product_category': 'new_soft_drink_flavor',
    'new_price': 2.99,
    'baseline_price': 2.49
}

results = simulator.analyze_price_impact(scenario, n_trials=10)
simulator.generate_report(results, output_dir="output")

# 4. View results
import json
from pathlib import Path

latest_json = max(Path("output").glob("price_impact_results_*.json"),
                  key=lambda p: p.stat().st_mtime)
with open(latest_json) as f:
    results = json.load(f)

print("Results Summary:")
print(f"  Purchasing households: {results['new_price_results']['purchasing_count']:.0f}")
print(f"  Revenue impact: ${results['impact']['revenue_change']:+,.2f}")
print(f"  Revenue change: {results['impact']['revenue_change_pct']:+.1f}%")
```

## File Locations Summary

| File Type | Location | Purpose |
|-----------|---------|---------|
| **Input Data** | `data/households.csv` | Your 3000×581 household data |
| **Text Report** | `output/price_impact_report_*.txt` | Human-readable analysis |
| **JSON Results** | `output/price_impact_results_*.json` | Machine-readable results |
| **Simulator Code** | `price_impact_simulator/` | Extracted simulator files |

## Troubleshooting

**If CSV not found:**
- Check the path is correct (use absolute path if needed)
- Verify file exists: `Path("data/households.csv").exists()`

**If import errors:**
- Make sure you added to path: `sys.path.append('./price_impact_simulator')`
- Check dependencies installed: `%pip list | grep pandas`

**To see all output files:**
```python
from pathlib import Path
list(Path("output").glob("*"))
```

