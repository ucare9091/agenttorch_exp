# Price Simulator - Docker Image Contents

This repository contains the extracted contents from the Docker image `ucare9091/price-sim:latest`.

## Contents

- `run_simulation.py` - Main entry point
- `runner_dbx.py` - Simulation runner for Databricks
- `agenttorch_model/` - AgentTorch model package
- `requirements.txt` - Python dependencies

## Clone in Databricks

```python
# In Databricks notebook
%sh
cd /Workspace/Repos
git clone https://github.com/YOUR_USERNAME/price_sim.git
# Or use the local path if you push this to a git server
```

## Usage

```python
import sys
sys.path.insert(0, '/Workspace/Repos/price_sim')

from runner_dbx import run_simulation

results = run_simulation(
    csv_path="/dbfs/FileStore/data/households.csv",
    scenario={
        "product_category": "new_soft_drink_flavor",
        "new_price": 2.99,
        "baseline_price": 2.49
    },
    device="cpu"
)

print(results)
```

## Installation

```python
%pip install -r /Workspace/Repos/price_sim/requirements.txt
```
