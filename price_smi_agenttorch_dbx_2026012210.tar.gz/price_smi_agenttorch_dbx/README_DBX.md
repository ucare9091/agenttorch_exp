# Price Impact Simulator (Databricks Notebook)

This folder contains a Databricks-ready notebook and Python helpers to run the
AgentTorch price impact simulator using household demographic CSVs.

## Files
- `price_smi_agenttorch_dbx.ipynb`: Notebook entrypoint.
- `runner_dbx.py`: AgentTorch runner and CSV loader.
- `agenttorch_model/`: Minimal AgentTorch model package with policies/transitions.

## Packaging for Databricks

### Create tar.gz file:
```bash
cd /path/to/price_smi_agenttorch_dbx
tar -czf price_smi_agenttorch_dbx.tar.gz \
    price_smi_agenttorch_dbx.ipynb \
    runner_dbx.py \
    agenttorch_model/ \
    README_DBX.md
```

### Upload to Databricks:
1. Upload the `tar.gz` file to Databricks FileStore or workspace
2. Extract it in your Databricks workspace:
   ```python
   import shutil
   shutil.unpack_archive('/dbfs/FileStore/path/to/price_smi_agenttorch_dbx.tar.gz', 
                        '/Workspace/Users/your_email/price_smi_agenttorch_dbx')
   ```
3. Or extract via Databricks UI: Upload → Extract archive

### Usage on Databricks:
1. Open the extracted `price_smi_agenttorch_dbx.ipynb` notebook
2. Run cells top-to-bottom
3. The notebook will:
   - Install `agent-torch` and dependencies via `%pip install`
   - Generate a synthetic CSV if `households.csv` doesn't exist
   - Run the simulation on CPU (default, works reliably)
   - Return results

## CSV File Format

The code automatically handles CSV files with:
- Any number of rows (tested with 1M+ households)
- Flexible column names (automatically matches common variations)
- Missing columns (uses sensible defaults)
- Extra columns (ignored automatically)

### Preferred Column Names (automatically matched):
- ID: `id`, `household_id`, `householdid`, `hh_id`, `hhid`
- Income: `income`, `household_income`, `hh_income`, `annual_income`
- Size: `household_size`, `hh_size`, `householdsize`, `people_in_hh`, `num_people`
- Children: `num_children`, `children`, `num_children_in_hh`, `kids`
- Sensitivity: `price_sensitivity`, `price_sens`, `sensitivity`, `price_elasticity`
- Location: `location`, `region`, `geo`, `geography`, `area`

### Default Values (if columns missing):
- ID: Auto-generated sequential numbers
- Income: 50000
- Household Size: 2.0
- Number of Children: 0.0
- Price Sensitivity: 0.5
- Location: "unknown"

Any additional columns in your CSV are automatically ignored.

## CSV File Location
- The notebook looks for `households.csv` in the current working directory
- If not found, it generates a synthetic dataset automatically
- You can also place your CSV file in the same directory as the notebook

## Device Configuration
- Default: CPU (works reliably on all Databricks clusters)
- GPU: Change `device = "cpu"` to `device = "cuda"` in the notebook if GPU is available

## Requirements
- Python 3.8+ (Databricks runtime 10.4+ recommended)
- Packages installed via notebook: `agent-torch`, `pandas`, `numpy`, `torch`
