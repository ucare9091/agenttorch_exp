from __future__ import annotations

from typing import Any, Dict, Optional
import torch
import re

from agent_torch.core.helpers.general import get_by_path
from agent_torch.core.registry import Registry
from agent_torch.core.substep import SubstepAction, SubstepTransition

from .llm_helper import get_llm_helper_from_config, llm_enhanced_decision


def get_var(state: Dict[str, Any], var: str):
    """
    Retrieves a value from the current state of the model.
    Follows AgentTorch framework pattern.
    """
    return get_by_path(state, re.split("/", var))


@Registry.register_substep("purchase_decision", "policy")
class PurchaseDecisionPolicyAT(SubstepAction):
    def forward(self, state: Dict[str, Any], observation: Dict[str, Any]):
        print(f"DEBUG PurchaseDecisionPolicy: forward() called")
        try:
            # Extract input variables using AgentTorch framework pattern
            income = get_var(state, self.input_variables["income"])
            household_size = get_var(state, self.input_variables["household_size"])
            price_sensitivity = get_var(state, self.input_variables["price_sensitivity"])
            new_price = get_var(state, self.input_variables["new_price"])
            baseline_price = get_var(state, self.input_variables["baseline_price"])

            # Extract location if available (for LLM context)
            location = None
            if "location" in self.input_variables:
                try:
                    location = get_var(state, self.input_variables["location"])
                    # Handle location as list (string attribute) or tensor
                    if isinstance(location, list):
                        pass  # Already a list
                    elif torch.is_tensor(location):
                        # Convert tensor to list of strings (if it contains string indices)
                        # For now, treat as list of indices that map to location names
                        location = location.tolist()
                    else:
                        location = None
                except (KeyError, TypeError, AttributeError):
                    location = None

            # Extract emotional state if available (for LLM context)
            emotional_state = None
            if "emotional_state" in self.input_variables:
                try:
                    emotional_state = get_var(state, self.input_variables["emotional_state"])
                    # Handle emotional_state as list (string attribute) or tensor
                    if isinstance(emotional_state, list):
                        pass  # Already a list
                    elif torch.is_tensor(emotional_state):
                        emotional_state = emotional_state.tolist()
                    else:
                        emotional_state = None
                except (KeyError, TypeError, AttributeError):
                    emotional_state = None

            # Normalize to tensors for computation
            if not torch.is_tensor(new_price):
                new_price = torch.tensor(new_price)
            if not torch.is_tensor(baseline_price):
                baseline_price = torch.tensor(baseline_price)

            # Ensure compatible shapes and dtypes for broadcasting
            if torch.is_tensor(income):
                if new_price.dim() == 0:
                    new_price = new_price.unsqueeze(0)
                if baseline_price.dim() == 0:
                    baseline_price = baseline_price.unsqueeze(0)
                new_price = new_price.to(dtype=income.dtype, device=income.device)
                baseline_price = baseline_price.to(dtype=income.dtype, device=income.device)

            # Get LLM helper if configured (following AgentTorch pattern)
            llm_helper = None
            llm_config = self.arguments.get("llm", {}) if hasattr(self, "arguments") else {}
            if not llm_config:
                # Try to get from state environment
                try:
                    env_llm = state.get("environment", {}).get("llm_config", {})
                    if env_llm:
                        llm_config = env_llm
                except (KeyError, TypeError):
                    pass

            # DEBUG: Print LLM config retrieval
            print(f"DEBUG: LLM config from arguments: {self.arguments.get('llm', {}) if hasattr(self, 'arguments') else 'no arguments'}")
            print(f"DEBUG: LLM config from environment: {state.get('environment', {}).get('llm_config', {})}")
            print(f"DEBUG: Final llm_config: {llm_config}")

            if llm_config and llm_config.get("enabled", False):
                from .llm_helper import LLMHelper
                print(f"DEBUG: Creating LLMHelper with api_base_url={llm_config.get('api_base_url')}")
                llm_helper = LLMHelper(
                    provider=llm_config.get("provider", "openai"),
                    model=llm_config.get("model", "gpt-3.5-turbo"),
                    api_key=llm_config.get("api_key"),
                    api_base_url=llm_config.get("api_base_url"),  # CRITICAL: Must pass API base URL for Ollama/proxy
                    temperature=llm_config.get("temperature", 0.7),
                    max_tokens=llm_config.get("max_tokens", 300),  # Increased from 150 to 300 to avoid truncation
                )
                print(f"DEBUG: LLMHelper created: {llm_helper is not None}, api_base_url={llm_helper.api_base_url if llm_helper else 'N/A'}")
            else:
                print(f"DEBUG: LLM not enabled or config missing. enabled={llm_config.get('enabled') if llm_config else False}")

            # Get product category from environment
            product_category = state.get("environment", {}).get("product_category", "product")

            # Compute deterministic purchase probability (base logic)
            price_change_pct = torch.where(
                baseline_price > 0,
                (new_price - baseline_price) / baseline_price,
                torch.zeros_like(new_price),
            )

            income_normalized = torch.clamp(income / 150000.0, max=1.0)
            price_sensitivity_factor = 1.0 - (income_normalized * 0.5)

            base_probability = torch.full_like(price_sensitivity_factor, 0.7)

            sensitivity_impact = torch.where(
                price_change_pct > 0,
                price_sensitivity * price_change_pct * 2.0,
                price_sensitivity * torch.abs(price_change_pct) * 0.5,
            )
            purchase_probability = torch.where(
                price_change_pct > 0,
                base_probability * (1.0 - torch.clamp(sensitivity_impact, max=0.8)),
                base_probability * (1.0 + torch.clamp(sensitivity_impact, max=0.5)),
            )

            income_factor = torch.clamp(income / 100000.0, max=1.0)
            purchase_probability = purchase_probability * (0.7 + 0.3 * income_factor)
            purchase_probability = torch.clamp(purchase_probability, min=0.0, max=1.0)

            # LLM-enhanced decision (if enabled and for sample households)
            # For efficiency, use LLM only for a sample or when explicitly enabled for all
            use_llm_sample = llm_helper and llm_config.get("sample_size", 0) > 0
            use_llm_all = llm_helper and llm_config.get("use_for_all", False)

            # DEBUG: Print LLM status
            if llm_config and llm_config.get("enabled", False):
                print(f"DEBUG: LLM enabled, helper={llm_helper is not None}, sample_size={llm_config.get('sample_size', 0)}, use_for_all={llm_config.get('use_for_all', False)}")
                print(f"DEBUG: use_llm_sample={use_llm_sample}, use_llm_all={use_llm_all}")

            if use_llm_all or use_llm_sample:
                # Convert tensors to Python values for LLM
                n_agents = income.shape[0] if torch.is_tensor(income) else len(income) if isinstance(income, list) else 1

                # Determine which households to use LLM for
                if use_llm_all:
                    llm_indices = list(range(n_agents))
                else:
                    sample_size = min(llm_config.get("sample_size", 10), n_agents)
                    import random
                    llm_indices = random.sample(range(n_agents), sample_size)

                print(f"DEBUG: Using LLM for {len(llm_indices)} households: {llm_indices[:10]}...")

                # Create LLM-enhanced probabilities
                # Initialize with 1.0 (no change) for all households
                llm_adjustments = torch.ones_like(purchase_probability)
                print(f"DEBUG: Initialized llm_adjustments with shape {llm_adjustments.shape}, all values = 1.0")
                print(f"DEBUG: Starting LLM loop for {len(llm_indices)} households: {llm_indices}")

                for idx in llm_indices:
                    print(f"DEBUG: Processing household {idx} (iteration {llm_indices.index(idx) + 1}/{len(llm_indices)})")
                    # Extract household context
                    hh_income = float(income[idx].item() if torch.is_tensor(income) else income[idx])
                    hh_size = float(household_size[idx].item() if torch.is_tensor(household_size) else household_size[idx])
                    hh_sens = float(price_sensitivity[idx].item() if torch.is_tensor(price_sensitivity) else price_sensitivity[idx])
                    if location is not None:
                        if isinstance(location, list) and idx < len(location):
                            hh_loc = str(location[idx])
                        elif torch.is_tensor(location) and idx < location.shape[0]:
                            hh_loc = str(location[idx].item())
                        else:
                            hh_loc = "unknown"
                    else:
                        hh_loc = "unknown"

                    if emotional_state is not None:
                        if isinstance(emotional_state, list) and idx < len(emotional_state):
                            hh_emo = str(emotional_state[idx])
                        elif torch.is_tensor(emotional_state) and idx < emotional_state.shape[0]:
                            hh_emo = str(emotional_state[idx].item())
                        else:
                            hh_emo = "neutral"
                    else:
                        hh_emo = "neutral"

                    household_context = {
                        "income": hh_income,
                        "household_size": hh_size,
                        "price_sensitivity": hh_sens,
                        "location": hh_loc,
                        "emotional_state": hh_emo,
                    }

                    market_context = {
                        "product_category": product_category,
                        "new_price": float(new_price[0].item() if torch.is_tensor(new_price) else new_price),
                        "baseline_price": float(baseline_price[0].item() if torch.is_tensor(baseline_price) else baseline_price),
                    }

                    # Get LLM decision - CRITICAL: Don't crash on LLM errors, skip that household instead
                    llm_result = None
                    confidence_val = None
                    llm_success = False
                    try:
                        # Print ALL LLM calls (not just every 10th) to verify LLM is working
                        print(f"DEBUG: Calling LLM for household {idx}...")
                        llm_result = llm_enhanced_decision(llm_helper, household_context, market_context)
                        print(f"DEBUG: LLM result for household {idx}: decision={llm_result.get('decision')}, confidence={llm_result.get('confidence')}, reasoning={llm_result.get('reasoning', '')[:100]}")

                        # Validate LLM result has required fields
                        if llm_result is None:
                            raise ValueError(f"LLM result is None for household {idx}")
                        if "decision" not in llm_result:
                            raise ValueError(f"LLM result missing 'decision' for household {idx}: {llm_result}")
                        if "confidence" not in llm_result or llm_result["confidence"] is None:
                            raise ValueError(f"LLM result missing or None 'confidence' for household {idx}: {llm_result}")

                        # Ensure confidence is a valid float
                        try:
                            confidence_val = float(llm_result["confidence"])
                            confidence_val = max(0.0, min(1.0, confidence_val))  # Clamp to [0, 1]
                        except (TypeError, ValueError) as e:
                            raise ValueError(f"LLM result 'confidence' is not a valid number for household {idx}: {llm_result.get('confidence')}, error: {e}")

                        # Check if fallback was used
                        if "LLM not available" in llm_result.get("reasoning", ""):
                            raise RuntimeError(f"LLM fallback detected for household {idx}")

                        # If we get here, LLM call was successful
                        llm_success = True

                    except Exception as e:
                        # CRITICAL: Don't crash the entire policy step - skip this household and use deterministic probability
                        print(f"WARNING: LLM call failed for household {idx}: {e}")
                        import traceback
                        traceback.print_exc()
                        print(f"  Skipping LLM adjustment for this household, using deterministic probability")
                        # Keep llm_adjustments[idx] = 1.0 (no change)
                        continue  # Skip to next household

                    # Adjust probability based on LLM decision (only if LLM call succeeded)
                    if not llm_success or llm_result is None or confidence_val is None:
                        print(f"WARNING: Skipping probability adjustment for household {idx} - LLM call did not succeed")
                        continue

                    llm_weight = llm_config.get("llm_weight", 0.3)  # How much to weight LLM vs deterministic
                    base_prob = float(purchase_probability[idx].item() if torch.is_tensor(purchase_probability) else purchase_probability[idx])

                    if llm_result["decision"]:
                        # LLM says yes - increase probability
                        llm_prob = confidence_val
                        adjusted_prob = base_prob * (1 - llm_weight) + llm_prob * llm_weight
                        print(f"DEBUG: Household {idx} - LLM YES: base_prob={base_prob:.3f}, llm_prob={llm_prob:.3f}, adjusted={adjusted_prob:.3f}, llm_weight={llm_weight}")
                    else:
                        # LLM says no - decrease probability
                        llm_prob = 1.0 - confidence_val
                        adjusted_prob = base_prob * (1 - llm_weight) + llm_prob * llm_weight
                        print(f"DEBUG: Household {idx} - LLM NO: base_prob={base_prob:.3f}, llm_prob={llm_prob:.3f}, adjusted={adjusted_prob:.3f}, llm_weight={llm_weight}")

                    llm_adjustments[idx] = adjusted_prob / max(base_prob, 0.01)  # Avoid division by zero
                    print(f"DEBUG: Household {idx} - adjustment factor={llm_adjustments[idx].item():.3f}, final_prob={adjusted_prob:.3f}")
                    print(f"DEBUG: Completed processing household {idx}, continuing to next...")

                # Apply LLM adjustments
                print(f"DEBUG: LLM loop completed for all {len(llm_indices)} households")
                print(f"DEBUG: Before LLM adjustment - purchase_probability range: [{purchase_probability.min().item():.3f}, {purchase_probability.max().item():.3f}], mean={purchase_probability.mean().item():.3f}")
                print(f"DEBUG: LLM adjustments - applied to {len(llm_indices)} households: {llm_indices}")
                print(f"DEBUG: LLM adjustments range: [{llm_adjustments.min().item():.3f}, {llm_adjustments.max().item():.3f}], mean={llm_adjustments.mean().item():.3f}")
                print(f"DEBUG: LLM adjustments for LLM households: {[llm_adjustments[i].item() for i in llm_indices]}")
                purchase_probability = purchase_probability * llm_adjustments
                purchase_probability = torch.clamp(purchase_probability, min=0.0, max=1.0)
                print(f"DEBUG: After LLM adjustment - purchase_probability range: [{purchase_probability.min().item():.3f}, {purchase_probability.max().item():.3f}], mean={purchase_probability.mean().item():.3f}")
                print(f"DEBUG: Purchase probabilities for LLM households after adjustment: {[purchase_probability[i].item() for i in llm_indices]}")

            # Final decision - CRITICAL: Wrap in try-except to ensure we always return values
            try:
                print(f"DEBUG: Final purchase_probability stats: min={purchase_probability.min().item():.4f}, max={purchase_probability.max().item():.4f}, mean={purchase_probability.mean().item():.4f}")
                print(f"DEBUG: Purchase probabilities > 0.5: {(purchase_probability > 0.5).sum().item()}")
                print(f"DEBUG: Purchase probabilities > 0.3: {(purchase_probability > 0.3).sum().item()}")
                rand_val = torch.rand_like(purchase_probability)
                will_purchase = (rand_val < purchase_probability).float()
                print(f"DEBUG: Will purchase count: {will_purchase.sum().item()} out of {len(will_purchase)}")
                print(f"DEBUG: Sample will_purchase values: {will_purchase[:10].tolist()}")

                base_quantity = torch.clamp(household_size * 0.5, min=1.0)
                quantity = torch.where(
                    will_purchase > 0,
                    torch.where(
                        price_change_pct < 0,
                        base_quantity * (1.0 - price_change_pct * 0.3),
                        base_quantity * (1.0 - price_change_pct * 0.5),
                    ),
                    torch.zeros_like(base_quantity),
                )
                quantity = torch.clamp(quantity, min=0.0)
                total_spend = new_price * quantity

                # DEBUG: Print policy step return values
                print(f"DEBUG PurchaseDecisionPolicy: Returning will_purchase sum={will_purchase.sum().item()}, shape={will_purchase.shape}")
                print(f"DEBUG PurchaseDecisionPolicy: Returning quantity sum={quantity.sum().item()}, shape={quantity.shape}")
                print(f"DEBUG PurchaseDecisionPolicy: Returning total_spend sum={total_spend.sum().item()}, shape={total_spend.shape}")

                result = {
                    "will_purchase": will_purchase,
                    "quantity": quantity,
                    "total_spend": total_spend,
                    "purchase_probability": purchase_probability,  # Store actual probabilities for analysis
                }
                print(f"DEBUG PurchaseDecisionPolicy: About to return result, keys={list(result.keys())}")
                return result
            except Exception as e:
                # CRITICAL: Always return values, even if there's an error in final decision
                # Safely format exception message to avoid tensor formatting issues
                try:
                    error_msg = str(e)
                except:
                    error_msg = repr(e)
                print(f"ERROR PurchaseDecisionPolicy: Exception in final decision: {error_msg}")
                import traceback
                traceback.print_exc()
                # Return zeros as fallback
                try:
                    n_agents = income.shape[0] if torch.is_tensor(income) else len(income) if isinstance(income, list) else 100
                except:
                    n_agents = 100
                will_purchase = torch.zeros((n_agents, 1))
                quantity = torch.zeros((n_agents, 1))
                total_spend = torch.zeros((n_agents, 1))
                print(f"ERROR PurchaseDecisionPolicy: Returning zeros as fallback - will_purchase sum={will_purchase.sum().item()}")
                return {
                    "will_purchase": will_purchase,
                    "quantity": quantity,
                    "total_spend": total_spend,
                }
        except Exception as outer_e:
            # CRITICAL: Catch ANY exception in the entire forward method
            # Safely format exception message to avoid tensor formatting issues
            try:
                error_msg = str(outer_e)
            except:
                error_msg = repr(outer_e)
            print(f"ERROR PurchaseDecisionPolicy: Exception in forward() method (outer catch): {error_msg}")
            import traceback
            traceback.print_exc()
            # Return zeros as fallback
            try:
                n_agents = income.shape[0] if torch.is_tensor(income) else len(income) if isinstance(income, list) else 100
            except:
                n_agents = 100
            will_purchase = torch.zeros((n_agents, 1))
            quantity = torch.zeros((n_agents, 1))
            total_spend = torch.zeros((n_agents, 1))
            print(f"ERROR PurchaseDecisionPolicy: Returning zeros as fallback (outer exception) - will_purchase sum={will_purchase.sum().item()}")
            return {
                "will_purchase": will_purchase,
                "quantity": quantity,
                "total_spend": total_spend,
            }


@Registry.register_substep("apply_purchase_decision", "transition")
class ApplyPurchaseDecision(SubstepTransition):
    def forward(self, state: Dict[str, Any], action: Dict[str, Any]):
        # AgentTorch framework:
        # - Policy outputs are stored in action dict under agent name
        # - But action['households'] might be None if AgentTorch hasn't processed policy output yet
        # - We need to read from action, but also check state as fallback
        print(f"DEBUG ApplyPurchaseDecision: action keys = {list(action.keys()) if action else 'None'}")
        print(f"DEBUG ApplyPurchaseDecision: action type = {type(action)}")
        if action:
            print(f"DEBUG ApplyPurchaseDecision: action contents = {[(k, type(v) if v is not None else 'None') for k, v in action.items()]}")
            # Print full action structure for debugging
            for key, value in action.items():
                if value is not None:
                    if isinstance(value, dict):
                        print(f"DEBUG ApplyPurchaseDecision: action['{key}'] keys = {list(value.keys())}")
                        for subkey, subvalue in value.items():
                            if torch.is_tensor(subvalue):
                                print(f"DEBUG ApplyPurchaseDecision: action['{key}']['{subkey}'] = tensor, shape={subvalue.shape}, sum={subvalue.sum().item()}")
                            else:
                                print(f"DEBUG ApplyPurchaseDecision: action['{key}']['{subkey}'] = {type(subvalue)}")
                    elif torch.is_tensor(value):
                        print(f"DEBUG ApplyPurchaseDecision: action['{key}'] = tensor, shape={value.shape}, sum={value.sum().item()}")

        # Check state for policy outputs (AgentTorch might store them there temporarily)
        print(f"DEBUG ApplyPurchaseDecision: state agents keys = {list(state.get('agents', {}).keys())}")
        households_state = state.get('agents', {}).get('households', {})
        if isinstance(households_state, dict):
            print(f"DEBUG ApplyPurchaseDecision: state households keys = {list(households_state.keys())}")
            if 'will_purchase' in households_state:
                wp_state = households_state['will_purchase']
                if torch.is_tensor(wp_state):
                    print(f"DEBUG ApplyPurchaseDecision: state['agents']['households']['will_purchase'] = tensor, shape={wp_state.shape}, sum={wp_state.sum().item()}, values={wp_state[:5].tolist()}")

        # Extract values from action (policy output)
        will_purchase = None
        quantity = None
        total_spend = None

        # Try different action structures
        if action and isinstance(action, dict):
            # Method 1: Check if action has 'households' key (standard AgentTorch structure)
            if "households" in action:
                household_action = action["households"]
                print(f"DEBUG ApplyPurchaseDecision: Found 'households' key, type={type(household_action)}")

                if household_action is not None:
                    if isinstance(household_action, dict):
                        will_purchase = household_action.get("will_purchase")
                        quantity = household_action.get("quantity")
                        total_spend = household_action.get("total_spend")
                        purchase_probability = household_action.get("purchase_probability")  # Extract probabilities
                        print(f"DEBUG ApplyPurchaseDecision: Extracted from households dict")
                    elif torch.is_tensor(household_action):
                        will_purchase = household_action
                        print(f"DEBUG ApplyPurchaseDecision: households is tensor, using as will_purchase")

            # Method 2: Try direct keys in action (maybe AgentTorch passes policy output directly)
            if will_purchase is None:
                will_purchase = action.get("will_purchase")
                quantity = action.get("quantity")
                total_spend = action.get("total_spend")
                if will_purchase is not None:
                    print(f"DEBUG ApplyPurchaseDecision: Extracted from direct action keys")

            # Method 3: Check if action values are the outputs directly (tensors with matching names)
            if will_purchase is None and len(action) > 0:
                for key, value in action.items():
                    if value is not None and torch.is_tensor(value):
                        if "purchase" in key.lower():
                            will_purchase = value
                            print(f"DEBUG ApplyPurchaseDecision: Found will_purchase as action['{key}']")
                        elif "quantity" in key.lower():
                            quantity = value
                        elif "spend" in key.lower():
                            total_spend = value

            # Method 3b: Check if policy outputs are nested under policy name
            if will_purchase is None:
                # Maybe action structure is: action['purchase_decision'] = {'will_purchase': ...}
                for key in action.keys():
                    if key != "households" and isinstance(action.get(key), dict):
                        policy_outputs = action[key]
                        if "will_purchase" in policy_outputs:
                            will_purchase = policy_outputs.get("will_purchase")
                            quantity = policy_outputs.get("quantity")
                            total_spend = policy_outputs.get("total_spend")
                            print(f"DEBUG ApplyPurchaseDecision: Found policy outputs under action['{key}']")
                            break

        # Method 4: Try reading from state using input_variables
        # BUT: Don't use this if action['households'] is None - state has old zero values
        # Only use state if we couldn't find values in action
        if will_purchase is None and hasattr(self, 'input_variables'):
            # Check if action['households'] is None - if so, state values are old zeros, skip them
            if action.get("households") is None:
                print(f"DEBUG ApplyPurchaseDecision: Skipping state read - action['households'] is None, state has old zeros")
            else:
                try:
                    if "will_purchase" in self.input_variables:
                        will_purchase = get_var(state, self.input_variables["will_purchase"])
                        print(f"DEBUG ApplyPurchaseDecision: Read will_purchase from state via input_variables")
                    if "quantity" in self.input_variables:
                        quantity = get_var(state, self.input_variables["quantity"])
                    if "total_spend" in self.input_variables:
                        total_spend = get_var(state, self.input_variables["total_spend"])
                except Exception as e:
                    print(f"DEBUG ApplyPurchaseDecision: Failed to read from input_variables: {e}")

        # Method 5: Try to get from state directly
        # BUT: Only if action['households'] is not None (otherwise state has old zeros)
        if will_purchase is None and action.get("households") is not None:
            try:
                households = state.get("agents", {}).get("households", {})
                if isinstance(households, dict):
                    will_purchase = households.get("will_purchase")
                    quantity = households.get("quantity")
                    total_spend = households.get("total_spend")
                    if will_purchase is not None:
                        print(f"DEBUG ApplyPurchaseDecision: Found values in state (already stored?)")
            except:
                pass
        elif will_purchase is None:
            print(f"DEBUG ApplyPurchaseDecision: Skipping state direct read - action['households'] is None, state has zeros")

        # Debug output
        if torch.is_tensor(will_purchase):
            print(f"DEBUG ApplyPurchaseDecision: will_purchase type={type(will_purchase)}, shape={will_purchase.shape}, sum={will_purchase.sum().item()}, values={will_purchase[:10].tolist()}")
        else:
            print(f"DEBUG ApplyPurchaseDecision: will_purchase type={type(will_purchase)}, value={will_purchase}")

        # CRITICAL CHECK: If will_purchase is still None, check if policy outputs are in state
        # (AgentTorch might store NEW policy outputs in state, overwriting zeros)
        # Check the actual tensor sum - if > 0, these ARE the policy outputs!
        if will_purchase is None:
            households_state = state.get('agents', {}).get('households', {})
            if isinstance(households_state, dict):
                wp_state = households_state.get('will_purchase')
                if torch.is_tensor(wp_state):
                    wp_sum = wp_state.sum().item()
                    print(f"DEBUG ApplyPurchaseDecision: State will_purchase sum = {wp_sum}")
                    if wp_sum > 0:
                        # These ARE the policy outputs! Use them.
                        print(f"DEBUG ApplyPurchaseDecision: FOUND policy outputs in state (sum > 0)! Using them.")
                        will_purchase = wp_state
                        quantity = households_state.get('quantity')
                        total_spend = households_state.get('total_spend')

        # If we still don't have will_purchase, we can't proceed
        if will_purchase is None:
            print(f"ERROR ApplyPurchaseDecision: Could not extract will_purchase from action or state!")
            print(f"  Action structure: {action}")
            print(f"  Action full contents: {[(k, type(v) if v is not None else 'None', list(v.keys()) if isinstance(v, dict) else 'N/A') for k, v in action.items()]}")
            print(f"  State agents/households keys: {list(state.get('agents', {}).get('households', {}).keys()) if isinstance(state.get('agents', {}).get('households', {}), dict) else 'N/A'}")
            # Return empty values but don't crash - let AgentTorch handle it
            return {
                "will_purchase": torch.zeros((100, 1)),  # Fallback - will be overwritten if policy output exists
                "quantity": torch.zeros((100, 1)),
                "total_spend": torch.zeros((100, 1)),
            }

        # CRITICAL: Directly update state to ensure values are stored
        # AgentTorch may not automatically map return values, so we update state directly
        if "agents" not in state:
            state["agents"] = {}
        if "households" not in state["agents"]:
            state["agents"]["households"] = {}

        if will_purchase is not None:
            state["agents"]["households"]["will_purchase"] = will_purchase
            print(f"DEBUG ApplyPurchaseDecision: Stored will_purchase in state, sum={will_purchase.sum().item() if torch.is_tensor(will_purchase) else 'N/A'}")
        if quantity is not None:
            state["agents"]["households"]["quantity"] = quantity
        if total_spend is not None:
            state["agents"]["households"]["total_spend"] = total_spend
        if purchase_probability is not None:
            state["agents"]["households"]["purchase_probability"] = purchase_probability
            print(f"DEBUG ApplyPurchaseDecision: Stored purchase_probability in state, range=[{purchase_probability.min().item():.4f}, {purchase_probability.max().item():.4f}]")

        # Also return values (AgentTorch may use return values as well)
        return {
            "will_purchase": will_purchase,
            "quantity": quantity,
            "total_spend": total_spend,
        }
