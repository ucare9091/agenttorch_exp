Unified input (single Parquet or CSV)
=====================================

One long-format table used for:
  - household demographics (repeated on each event row),
  - past purchase events (product_name, quantity, timestamps, unit_price, store_location),
  - optional ground-truth label for the evaluated product (same value on every row for a household).

Required:
  - household_id (or aliases supported by runner_dbx.find_column)

Recommended columns (flexible names; see build_agent_states / transaction prompt builder):
  - income, household_size, price_sensitivity, location, emotional_state
  - product_name, quantity, purchase_timestamp (or purchase_date / timestamp aliases)
  - unit_price (or price), store_location (or store)

Optional label column (any one of these names; used for auto metrics when --unified-input):
  - ground_truth_purchased, purchased_eval_product, eval_purchased, target_purchased,
    label_purchased, purchased_target, y_purchase

Sample file: unified_panel_5k_sample.parquet (250 households x 20 rows = 5000 rows).
The scenario product new_ice_cream_flavor appears in history for households with label 1.

Run example (deterministic + LLM blend via --llm-weight, e.g. 0.5):
  python run_simulation.py --csv data/unified_panel_5k_sample.parquet --unified-input --seed 1 --llm-weight 0.5

Do not pass --transaction-history-parquet together with --unified-input.

Results JSON includes:
  - household_predictions.purchased (final decision after LLM blend and one random draw)
  - household_predictions.purchased_deterministic (same random draw vs deterministic probability)
  - evaluation_vs_ground_truth (if label column present and auto-eval not disabled): metrics for final vs deterministic vs labels.
