#!/usr/bin/env python3
"""Smoke tests: deterministic purchase probability, transaction Parquet, LLM prompt path (stubbed)."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

import pandas as pd
import torch

# Bundle root on path (same as run_simulation.py)
_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


def test_deterministic_probability_matches_reference():
    """Mirror purchase_decision.py tensor logic for one row (sanity check)."""
    income = torch.tensor([[80000.0]])
    household_size = torch.tensor([[3.0]])
    price_sensitivity = torch.tensor([[0.4]])
    new_price = torch.tensor([5.0])
    baseline_price = torch.tensor([4.0])

    price_change_pct = torch.where(
        baseline_price > 0,
        (new_price - baseline_price) / baseline_price,
        torch.zeros_like(new_price),
    )
    income_normalized = torch.clamp(income / 150000.0, max=1.0)
    base_probability = torch.full_like(income_normalized, 0.7)
    sensitivity_impact = torch.where(
        price_change_pct > 0,
        price_sensitivity * price_change_pct * 2.0,
        price_sensitivity * torch.abs(price_change_pct) * 0.5,
    )
    purchase_probability = torch.where(
        price_change_pct > 0,
        base_probability * (1.0 - torch.clamp(sensitivity_impact, max=0.8)),
        base_probability * (1.0 + torch.clamp(sensitivity_impact, max=0.5)),
    )
    income_factor = torch.clamp(income / 100000.0, max=1.0)
    purchase_probability = purchase_probability * (0.7 + 0.3 * income_factor)
    purchase_probability = torch.clamp(purchase_probability, min=0.0, max=1.0)

    p = float(purchase_probability[0, 0].item())
    assert 0.0 <= p <= 1.0, p
    # Price went up 25% with sensitivity 0.4 -> expect below naive 0.7 * 1.0
    assert p < 0.75, f"expected damped prob, got {p}"


def test_transaction_parquet_load():
    from evaluation_metrics import load_transaction_data

    p = _ROOT / "data" / "household_transactions.parquet"
    if not p.exists():
        return  # optional sample
    df = load_transaction_data(str(p))
    assert "household_id" in df.columns and "purchased" in df.columns


def test_llm_enhanced_decision_stub_prompt():
    from agenttorch_model.substeps import llm_helper as lh

    captured: dict = {}

    class StubHelper:
        def call(self, prompt, system_prompt=None, parse_json=False):
            captured["prompt"] = prompt
            captured["system"] = system_prompt or ""
            assert "Household profile" in prompt
            assert "Price sensitivity" in prompt
            assert "behavioral" in (system_prompt or "").lower()
            return {
                "decision": True,
                "reasoning": "ok",
                "confidence": 0.82,
                "quantity": 2.0,
                "emotional_influence": "neutral",
            }

    out = lh.llm_enhanced_decision(
        StubHelper(),
        {
            "income": 60000,
            "household_size": 2.0,
            "price_sensitivity": 0.5,
            "location": "midwest",
            "emotional_state": "stressed",
        },
        {
            "product_category": "new_ice_cream_flavor",
            "new_price": 4.99,
            "baseline_price": 3.99,
        },
        transaction_history_text="2024-06-01 | ice_cream_vanilla | qty=2",
    )
    assert out["decision"] is True
    assert abs(out["confidence"] - 0.82) < 1e-6
    assert "STRESSED" in captured["prompt"]
    assert "ice_cream_vanilla" in captured["prompt"]


def test_household_table_unified_panel_and_ground_truth():
    from runner_dbx import household_table_and_ground_truth_from_unified_panel

    df = pd.DataFrame(
        {
            "household_id": [1, 1, 2, 2],
            "income": [50000, 50000, 60000, 60000],
            "household_size": [2, 2, 3, 3],
            "price_sensitivity": [0.5, 0.5, 0.3, 0.3],
            "location": ["urban", "urban", "rural", "rural"],
            "emotional_state": ["happy", "happy", "stressed", "stressed"],
            "ground_truth_purchased": [1, 1, 0, 0],
            "product_name": ["new_ice_cream_flavor", "milk", "bread", "milk"],
            "quantity": [1.0, 2.0, 1.0, 3.0],
            "purchase_timestamp": pd.date_range("2024-06-01", periods=4, freq="D"),
            "unit_price": [4.99, 3.0, 2.5, 3.0],
            "store_location": ["A", "A", "B", "B"],
        }
    )
    hdf, gtm = household_table_and_ground_truth_from_unified_panel(df)
    assert len(hdf) == 2
    assert gtm is not None and gtm[1] == 1 and gtm[2] == 0
    assert "ground_truth_purchased" not in hdf.columns


def test_build_transaction_history_prompts():
    from runner_dbx import build_transaction_history_prompts_for_agents

    dfa = pd.DataFrame(
        {
            "household_id": [1, 1, 2],
            "product_name": ["sku_a", "sku_b", "sku_c"],
            "quantity": [2, 1, 3],
            "purchase_timestamp": pd.date_range("2024-01-01", periods=3, freq="D"),
        }
    )
    households = [{"household_id": 1}, {"household_id": 2}]
    prompts = build_transaction_history_prompts_for_agents(dfa, households, max_rows_per_household=10)
    assert len(prompts) == 2
    assert "sku_b" in prompts[0] or "sku_a" in prompts[0]
    assert "sku_c" in prompts[1]


def test_coerce_json_bool():
    from agenttorch_model.substeps.llm_helper import _coerce_json_bool

    assert _coerce_json_bool(True) is True
    assert _coerce_json_bool(False) is False
    assert _coerce_json_bool("true") is True
    assert _coerce_json_bool("FALSE") is False
    assert _coerce_json_bool("0") is False


def test_run_simulation_reproducible_seed():
    """Same seed in two fresh processes -> same purchase vector (avoids OmegaConf re-register in one process)."""
    py = sys.executable
    script = _ROOT / "run_simulation.py"
    csv = _ROOT / "data" / "test_5.csv"
    if not script.is_file() or not csv.is_file():
        return
    with tempfile.TemporaryDirectory() as td:
        o1 = Path(td) / "r1.json"
        o2 = Path(td) / "r2.json"
        base = [
            py,
            str(script),
            "--csv",
            str(csv),
            "--seed",
            "12345",
            "--output",
        ]
        for out in (o1, o2):
            r = subprocess.run(
                base + [str(out)],
                cwd=str(_ROOT),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if r.returncode != 0:
                raise AssertionError(
                    f"run_simulation failed ({r.returncode}): {r.stderr[-2000:]}"
                )
        j1 = json.loads(o1.read_text())
        j2 = json.loads(o2.read_text())
        assert j1["household_predictions"]["purchased"] == j2["household_predictions"]["purchased"]
        assert j1["purchasing_count"] == j2["purchasing_count"]


def main():
    test_deterministic_probability_matches_reference()
    test_transaction_parquet_load()
    test_household_table_unified_panel_and_ground_truth()
    test_build_transaction_history_prompts()
    test_llm_enhanced_decision_stub_prompt()
    test_coerce_json_bool()
    test_run_simulation_reproducible_seed()
    print("test_smoke: all passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
