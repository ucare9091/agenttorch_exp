"""
Price Impact Simulator

A focused simulator to answer:
"What would household purchase behavior be if we introduce a new product price to this population?"
"""

from .simulator import PriceImpactSimulator
from .household import Household, PurchaseDecision
from .data_loader import HouseholdDataLoader

__version__ = "1.0.0"
__all__ = ['PriceImpactSimulator', 'Household', 'PurchaseDecision', 'HouseholdDataLoader']

