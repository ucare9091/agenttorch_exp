Ice Cream Price Simulation

Simulates purchase behavior for a new ice cream flavor. See run_simulation.py --help for all flags.

Basic run:
  python run_simulation.py --csv data/households.csv --output output/results.json

Reproducible run (same seed -> same stochastic purchase draw and LLM sample indices):
  python run_simulation.py --csv data/households.csv --output output/results.json --seed 42

LLM past-purchase context (optional Parquet/CSV; deterministic formulas unchanged; with --llm-enabled, LLM runs for all households when sample size is 0):
  python run_simulation.py --csv data/households.csv --output output/results.json --seed 42 \
    --llm-enabled --llm-weight 0.3 \
    --transaction-history-parquet data/household_tx_history_1yr_sample.parquet
  See data/README_transaction_history.txt for column naming.

Unified single input (same file for agents + LLM history + optional ground truth labels):
  python run_simulation.py --csv data/unified_panel_5k_sample.parquet --unified-input --output output/results.json --seed 42
  See data/README_unified_input.txt. Do not combine --unified-input with --transaction-history-parquet.

Optional evaluation (CSV or Parquet under data/, same path rules as --csv):
  python run_simulation.py --csv data/households.csv --output output/results.json --transaction-data data/household_transactions.parquet

LLM credentials: MODEL_PROXY_API_KEY, MODEL_PROXY_API_BASE, or OPENAI_* / ANTHROPIC_*.
Blank environment values are treated as unset (Databricks-friendly).

Databricks: run jobs from the bundle root; agenttorch_model/yamls/config.yaml is regenerated each run.
Keep household and transaction inputs under data/ when using relative paths.

One-time per cluster image:
  pip install -r requirements.txt
  python apply_dataloader_fix.py
  python apply_initializer_fix.py

Smoke check: python verify_setup.py
