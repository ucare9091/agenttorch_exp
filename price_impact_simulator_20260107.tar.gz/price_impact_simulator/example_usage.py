"""
Example usage of Price Impact Simulator
Simple examples for easy replication
"""

from price_impact_simulator import PriceImpactSimulator

# Example 1: New Soft Drink Flavor
print("Example 1: New Soft Drink Flavor")
print("=" * 60)

simulator = PriceImpactSimulator(household_data="data/households.csv")

scenario = {
    'product_category': 'new_soft_drink_flavor',
    'new_price': 2.99,
    'baseline_price': 2.49
}

results = simulator.analyze_price_impact(scenario, n_trials=10)
simulator.generate_report(results, output_dir="output")

print(f"\nPurchase Rate: {results['new_price_results']['purchase_rate']*100:.1f}%")
print(f"Revenue Impact: ${results['impact']['revenue_change']:+,.2f}")


# Example 2: New Ice Cream Flavor
print("\n\nExample 2: New Ice Cream Flavor")
print("=" * 60)

scenario2 = {
    'product_category': 'new_ice_cream_flavor',
    'new_price': 4.99,
    'baseline_price': 3.99
}

results2 = simulator.analyze_price_impact(scenario2, n_trials=10)
simulator.generate_report(results2, output_dir="output")

print(f"\nPurchase Rate: {results2['new_price_results']['purchase_rate']*100:.1f}%")
print(f"Revenue Impact: ${results2['impact']['revenue_change']:+,.2f}")

