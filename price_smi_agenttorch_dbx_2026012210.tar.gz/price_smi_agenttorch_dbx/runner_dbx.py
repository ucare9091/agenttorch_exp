from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

import pandas as pd
import torch

from agent_torch.config import (
    ConfigBuilder,
    StateBuilder,
    AgentBuilder,
    PropertyBuilder,
    EnvironmentBuilder,
    SubstepBuilder,
    PolicyBuilder,
    TransitionBuilder,
)
from agent_torch.core.dataloader import LoadPopulation
from agent_torch.core.executor import Executor


def find_column(df: pd.DataFrame, possible_names: list, default_value=None):
    """Find column by multiple possible names (case-insensitive, partial match)."""
    df_cols_lower = {col.lower(): col for col in df.columns}
    for name in possible_names:
        name_lower = name.lower()
        if name_lower in df_cols_lower:
            return df_cols_lower[name_lower]
        for col_lower, col_orig in df_cols_lower.items():
            if name_lower in col_lower or col_lower in name_lower:
                return col_orig
    return None


def load_households(csv_path: str) -> pd.DataFrame:
    """Load household CSV with flexible column name matching."""
    df = pd.read_csv(csv_path)
    return df


def build_agent_states(df: pd.DataFrame) -> Dict:
    """Build agent states from DataFrame with flexible column matching.
    
    Handles any column names and any number of rows efficiently.
    Missing columns use sensible defaults.
    """
    n_rows = len(df)
    
    id_col = find_column(df, ["id", "household_id", "householdid", "hh_id", "hhid"])
    income_col = find_column(df, ["income", "household_income", "hh_income", "annual_income"])
    size_col = find_column(df, ["household_size", "hh_size", "householdsize", "people_in_hh", "num_people"])
    children_col = find_column(df, ["num_children", "children", "num_children_in_hh", "kids"])
    sensitivity_col = find_column(df, ["price_sensitivity", "price_sens", "sensitivity", "price_elasticity"])
    location_col = find_column(df, ["location", "region", "geo", "geography", "area"])
    
    if id_col:
        household_ids = df[id_col].fillna(0).astype(int).tolist()
    else:
        household_ids = list(range(1, n_rows + 1))
    
    if income_col:
        incomes = df[income_col].fillna(50000.0).astype(float).tolist()
    else:
        incomes = [50000.0] * n_rows
    
    if size_col:
        household_sizes = df[size_col].fillna(2.0).astype(float).tolist()
    else:
        household_sizes = [2.0] * n_rows
    
    if children_col:
        num_children = df[children_col].fillna(0.0).astype(float).tolist()
    else:
        num_children = [0.0] * n_rows
    
    if sensitivity_col:
        price_sensitivities = df[sensitivity_col].fillna(0.5).astype(float).tolist()
    else:
        price_sensitivities = [0.5] * n_rows
    
    if location_col:
        locations = df[location_col].fillna("unknown").astype(str).tolist()
    else:
        locations = ["unknown"] * n_rows
    
    households = [
        {
            "household_id": int(hid),
            "income": float(inc),
            "household_size": float(size),
            "num_children": float(children),
            "price_sensitivity": float(sens),
            "location": str(loc),
        }
        for hid, inc, size, children, sens, loc in zip(
            household_ids, incomes, household_sizes, num_children, price_sensitivities, locations
        )
    ]
    
    return {"households": households, "n_agents": len(households)}


def write_population_pickles(base_dir: Path, agent_states: Dict) -> Path:
    population_dir = base_dir / "agenttorch_population"
    population_dir.mkdir(parents=True, exist_ok=True)
    init_path = population_dir / "__init__.py"
    if not init_path.exists():
        init_path.write_text('"""AgentTorch population package."""\n')

    households = agent_states["households"]
    data = {
        "household_id": [h.get("household_id", 0) for h in households],
        "income": [h.get("income", 0.0) for h in households],
        "household_size": [h.get("household_size", 0.0) for h in households],
        "price_sensitivity": [h.get("price_sensitivity", 0.0) for h in households],
    }

    for key, values in data.items():
        series = pd.Series(values)
        series.to_pickle(population_dir / f"{key}.pickle")

    return population_dir


def build_model_config(
    base_dir: Path,
    agent_states: Dict,
    device: str = "cpu",
    product_category: str = "new_soft_drink_flavor",
    new_price: float = 2.99,
    baseline_price: float = 2.49,
) -> Path:
    model_dir = base_dir / "agenttorch_model"
    yamls_dir = model_dir / "yamls"
    yamls_dir.mkdir(parents=True, exist_ok=True)

    num_agents = len(agent_states["households"])
    population_dir = base_dir / "agenttorch_population"

    metadata = {
        "num_agents": num_agents,
        "population_dir": str(population_dir),
        "num_episodes": 1,
        "num_steps_per_episode": 1,
        "num_substeps_per_step": 1,
        "device": device,
        "calibration": False,
    }

    config = ConfigBuilder().set_metadata(metadata)

    state_builder = StateBuilder()
    household_builder = AgentBuilder("households", num_agents)

    def _pop_prop(name, dtype):
        file_arg = {
            "value": str(population_dir / f"{name}.pickle"),
            "shape": None,
            "learnable": False,
            "initialization_function": None,
        }
        return (
            PropertyBuilder(name)
            .set_dtype(dtype)
            .set_shape([num_agents, 1])
            .set_initialization(
                "load_population_attribute",
                {"file_path": file_arg},
            )
        )

    household_builder.add_property(_pop_prop("household_id", "int"))
    household_builder.add_property(_pop_prop("income", "float"))
    household_builder.add_property(_pop_prop("household_size", "float"))
    household_builder.add_property(_pop_prop("price_sensitivity", "float"))

    household_builder.add_property(
        PropertyBuilder("will_purchase")
        .set_dtype("float")
        .set_shape([num_agents, 1])
        .set_value(0.0)
    )
    household_builder.add_property(
        PropertyBuilder("quantity")
        .set_dtype("float")
        .set_shape([num_agents, 1])
        .set_value(0.0)
    )
    household_builder.add_property(
        PropertyBuilder("total_spend")
        .set_dtype("float")
        .set_shape([num_agents, 1])
        .set_value(0.0)
    )

    state_builder.add_agent("households", household_builder)

    env_builder = EnvironmentBuilder()
    env_builder.add_variable(
        PropertyBuilder("product_category").set_dtype("str").set_value(product_category)
    )
    env_builder.add_variable(
        PropertyBuilder("new_price").set_dtype("float").set_shape([1]).set_value(new_price)
    )
    env_builder.add_variable(
        PropertyBuilder("baseline_price")
        .set_dtype("float")
        .set_shape([1])
        .set_value(baseline_price)
    )
    state_builder.set_environment(env_builder)
    config.set_state(state_builder.to_dict())

    substep = SubstepBuilder(
        name="purchase_decision",
        description="Simulate household purchase decisions based on price",
    )
    substep.add_active_agent("households")
    substep.set_observation("households", None)

    policy_builder = PolicyBuilder()
    policy_builder.add_policy(
        "purchase_decision",
        "purchase_decision",
        {
            "income": "agents/households/income",
            "household_size": "agents/households/household_size",
            "price_sensitivity": "agents/households/price_sensitivity",
            "new_price": "environment/new_price",
            "baseline_price": "environment/baseline_price",
        },
        ["will_purchase", "quantity", "total_spend"],
        {},
    )
    substep.set_policy("households", policy_builder)

    transition_builder = TransitionBuilder()
    transition_builder.add_transition(
        "apply_purchase_decision",
        "apply_purchase_decision",
        {
            "will_purchase": "agents/households/will_purchase",
            "quantity": "agents/households/quantity",
            "total_spend": "agents/households/total_spend",
        },
        ["will_purchase", "quantity", "total_spend"],
        {},
    )
    substep.set_transition(transition_builder)

    config.add_substep("0", substep)
    config.save_yaml(str(yamls_dir / "config.yaml"))

    return yamls_dir / "config.yaml"


def run_simulation(
    csv_path: str,
    scenario: Optional[Dict] = None,
    device: str = "cpu",
) -> Dict:
    scenario = scenario or {
        "product_category": "new_soft_drink_flavor",
        "new_price": 2.99,
        "baseline_price": 2.49,
    }

    base_dir = Path(__file__).resolve().parent
    df = load_households(csv_path)
    agent_states = build_agent_states(df)
    write_population_pickles(base_dir, agent_states)
    build_model_config(
        base_dir,
        agent_states,
        device=device,
        product_category=scenario["product_category"],
        new_price=scenario["new_price"],
        baseline_price=scenario.get("baseline_price", scenario["new_price"]),
    )

    import importlib
    import sys

    if str(base_dir) not in sys.path:
        sys.path.insert(0, str(base_dir))

    model_module = importlib.import_module("agenttorch_model")
    population_module = importlib.import_module("agenttorch_population")
    population = LoadPopulation(population_module)

    executor = Executor(model_module, pop_loader=population)
    executor.init()
    executor.execute()

    state = executor.runner.state
    households = state.get("agents", {}).get("households", {})
    will_purchase = households.get("will_purchase", torch.zeros((agent_states["n_agents"], 1)))
    quantity = households.get("quantity", torch.zeros_like(will_purchase))
    total_spend = households.get("total_spend", torch.zeros_like(quantity))

    purchasing = (will_purchase > 0).float()
    purchasing_count = float(purchasing.sum().item())
    n_households = float(purchasing.numel())

    return {
        "scenario": scenario,
        "purchasing_count": purchasing_count,
        "purchase_rate": purchasing_count / max(n_households, 1.0),
        "total_revenue": float(total_spend.sum().item()),
        "total_units": float(quantity.sum().item()),
        "n_households": int(n_households),
    }
