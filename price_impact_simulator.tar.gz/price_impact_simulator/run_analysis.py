#!/usr/bin/env python3
"""
Run price impact analysis

Usage:
    python run_analysis.py --data data/households.parquet --category produce --new-price 6.50 --baseline-price 5.00
"""

import argparse
import sys
from pathlib import Path

from price_impact_simulator import PriceImpactSimulator


def main():
    parser = argparse.ArgumentParser(
        description="Analyze price impact on household purchase behavior"
    )

    parser.add_argument(
        '--data',
        type=str,
        required=True,
        help='Path to household data file (CSV or Parquet). Use relative path like "data/households.csv"'
    )

    parser.add_argument(
        '--category',
        type=str,
        required=True,
        help='Product category (e.g., new_soft_drink_flavor, new_ice_cream_flavor, produce, dairy)'
    )

    parser.add_argument(
        '--new-price',
        type=float,
        required=True,
        help='New price per unit'
    )

    parser.add_argument(
        '--baseline-price',
        type=float,
        default=None,
        help='Baseline/original price (defaults to new-price if not specified)'
    )

    parser.add_argument(
        '--trials',
        type=int,
        default=10,
        help='Number of simulation trials (default: 10)'
    )

    parser.add_argument(
        '--output-dir',
        type=str,
        default='output',
        help='Output directory for reports (default: output)'
    )

    args = parser.parse_args()

    # Validate inputs (skip for Databricks paths which may not exist locally)
    data_path = args.data
    if not (data_path.startswith('/dbfs/') or data_path.startswith('/Volumes/')):
        if not Path(data_path).exists():
            print(f"Error: Data file not found: {data_path}")
            sys.exit(1)

    baseline_price = args.baseline_price if args.baseline_price is not None else args.new_price

    print("=" * 80)
    print("PRICE IMPACT SIMULATOR")
    print("=" * 80)
    print(f"\nData: {args.data}")
    print(f"Product Category: {args.category}")
    print(f"Baseline Price: ${baseline_price:.2f}")
    print(f"New Price: ${args.new_price:.2f}")
    print(f"Simulation Trials: {args.trials}")

    # Initialize simulator
    print("\nLoading household data...")
    simulator = PriceImpactSimulator(household_data=args.data)

    # Define scenario
    scenario = {
        'product_category': args.category,
        'new_price': args.new_price,
        'baseline_price': baseline_price
    }

    # Run analysis
    print("\nRunning price impact analysis...")
    results = simulator.analyze_price_impact(scenario, n_trials=args.trials)

    # Generate report
    print("\nGenerating report...")
    report_path = simulator.generate_report(results, output_dir=args.output_dir)

    # Print summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"\nBaseline: {results['baseline']['purchasing_count']:.0f} households would purchase")
    print(f"New Price: {results['new_price_results']['purchasing_count']:.0f} households would purchase")
    print(f"\nRevenue Impact: ${results['impact']['revenue_change']:+,.2f} ({results['impact']['revenue_change_pct']:+.1f}%)")
    print(f"\nFull report: {report_path}")
    print("=" * 80)


if __name__ == "__main__":
    main()

