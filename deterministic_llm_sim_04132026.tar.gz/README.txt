Ice Cream Price Simulation

Simulates purchase behavior for a new ice cream flavor. See run_simulation.py --help for all flags.

Basic run:
  python run_simulation.py --csv data/households.csv --output output/results.json

Reproducible run (same seed -> same stochastic purchase draw and LLM sample indices):
  python run_simulation.py --csv data/households.csv --output output/results.json --seed 42

Optional evaluation (CSV or Parquet under data/, same path rules as --csv):
  python run_simulation.py --csv data/households.csv --output output/results.json --transaction-data data/household_transactions.parquet

LLM credentials: MODEL_PROXY_API_KEY, MODEL_PROXY_API_BASE, or OPENAI_* / ANTHROPIC_*.
Blank environment values are treated as unset (Databricks-friendly).

Databricks: run jobs from the bundle root; agenttorch_model/yamls/config.yaml is regenerated each run.
Keep household and transaction inputs under data/ when using relative paths.

One-time per cluster image:
  pip install -r requirements.txt
  python apply_dataloader_fix.py
  python apply_initializer_fix.py

Smoke check: python verify_setup.py
