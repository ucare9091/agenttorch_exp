#!/usr/bin/env python3
"""
Verification script to check if the setup is ready to run simulations.
Run this after extracting the archive and installing requirements.
"""

import sys
from pathlib import Path

def check_python_version():
    """Check Python version"""
    if sys.version_info < (3, 8):
        print(f"ERROR: Python {sys.version_info.major}.{sys.version_info.minor} is too old. Need Python 3.8+")
        return False
    print(f"OK: Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    return True

def check_dependencies():
    """Check if required packages are installed"""
    required = {
        "agent_torch": "agent-torch",
        "pandas": "pandas",
        "numpy": "numpy",
        "torch": "torch",
    }
    
    missing = []
    for module_name, package_name in required.items():
        try:
            __import__(module_name)
            print(f"OK: {package_name} installed")
        except ImportError:
            print(f"ERROR: {package_name} not installed")
            missing.append(package_name)
    
    return len(missing) == 0

def check_fix_scripts():
    """Check if fix scripts exist"""
    scripts = ["apply_dataloader_fix.py", "apply_initializer_fix.py"]
    missing = []
    
    for script in scripts:
        if Path(script).exists():
            print(f"OK: {script} found")
        else:
            print(f"ERROR: {script} not found")
            missing.append(script)
    
    return len(missing) == 0

def check_data_files():
    """Check if data files exist"""
    data_file = Path("data/households.csv")
    if data_file.exists():
        print(f"OK: {data_file} found")
        return True
    else:
        print(f"WARNING: {data_file} not found (simulation will fail if CSV not provided)")
        return False

def check_main_scripts():
    """Check if main scripts exist"""
    scripts = ["run_simulation.py", "runner_dbx.py"]
    missing = []
    
    for script in scripts:
        if Path(script).exists():
            print(f"OK: {script} found")
        else:
            print(f"ERROR: {script} not found")
            missing.append(script)
    
    return len(missing) == 0

def check_agent_torch_location():
    """Check if agent_torch can be found for patching"""
    try:
        import site
        import agent_torch.core.dataloader as dl_module
        dataloader_path = Path(dl_module.__file__)
        if dataloader_path.exists():
            print(f"OK: agent_torch found at {dataloader_path.parent.parent}")
            return True
        else:
            print(f"WARNING: agent_torch module found but file path invalid")
            return False
    except ImportError:
        print("ERROR: agent_torch not installed - cannot apply fixes")
        return False
    except Exception as e:
        print(f"WARNING: Could not verify agent_torch location: {e}")
        return False

def main():
    print("=" * 70)
    print("SETUP VERIFICATION")
    print("=" * 70)
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("Fix Scripts", check_fix_scripts),
        ("Main Scripts", check_main_scripts),
        ("Data Files", check_data_files),
        ("AgentTorch Location", check_agent_torch_location),
    ]
    
    results = []
    for name, check_func in checks:
        print(f"\n{name}:")
        result = check_func()
        results.append((name, result))
    
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{status}: {name}")
    
    print(f"\n{passed}/{total} checks passed")
    
    if passed == total:
        print("\nSetup is ready! You can now:")
        print("  1. Run: python3 apply_dataloader_fix.py")
        print("  2. Run: python3 apply_initializer_fix.py")
        print("  3. Run: python3 run_simulation.py --csv data/households.csv --output output/results.json")
        return 0
    else:
        print("\nSetup incomplete. Please fix the errors above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
