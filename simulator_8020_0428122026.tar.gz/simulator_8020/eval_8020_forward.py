#!/usr/bin/env python3
"""Child process: one Executor init, forward policy on eval-only population, print sklearn summary line.

Invoked by run_train_eval_8020.py so OmegaConf resolvers register in a fresh interpreter.
"""

from __future__ import annotations

import argparse
import importlib
import sys
import types
from pathlib import Path

import torch

_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from bundle_runtime_check import ensure_pyarrow_for_agent_stack

ensure_pyarrow_for_agent_stack()

from agent_torch.core.dataloader import LoadPopulation
from agent_torch.core.executor import Executor

from evaluation_metrics import evaluate_aligned_binary_labels
from runner_dbx import (
    build_agent_states,
    build_model_config,
    household_table_and_ground_truth_from_unified_panel,
    load_transaction_history_table,
    write_population_pickles,
)


def _load_executor(base_dir: Path, device: str) -> Executor:
    population_dir = base_dir / "agenttorch_population"
    sys.path.insert(0, str(base_dir.resolve()))
    model_module = importlib.import_module("agenttorch_model")
    try:
        population_module = importlib.import_module("agenttorch_population")
    except (ModuleNotFoundError, ImportError):
        population_module = types.ModuleType("agenttorch_population")
        population_module.__path__ = [str(population_dir)]
        sys.modules["agenttorch_population"] = population_module

    string_pickle_files = ["location.pickle", "emotional_state.pickle"]
    temp_files: dict = {}
    temp_dir = base_dir / "_temp_population_strings"
    temp_dir.mkdir(exist_ok=True)
    for filename in string_pickle_files:
        src = population_dir / filename
        if src.exists():
            temp_path = temp_dir / filename
            src.rename(temp_path)
            temp_files[filename] = temp_path
    try:
        population = LoadPopulation(population_module)
    finally:
        for filename, temp_path in temp_files.items():
            temp_path.rename(population_dir / filename)
        try:
            temp_dir.rmdir()
        except OSError:
            pass

    executor = Executor(model_module, pop_loader=population)
    executor.init()
    return executor


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--parquet", type=str, required=True, help="Eval-only unified-format Parquet (subset of rows)")
    p.add_argument("--bias", type=float, required=True)
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    args = p.parse_args()

    base_dir = _ROOT
    raw = load_transaction_history_table(args.parquet)
    hdf, gt_map = household_table_and_ground_truth_from_unified_panel(raw)
    if not gt_map:
        print("Error: eval parquet must include ground-truth label column.", file=sys.stderr)
        return 1

    agent_eval = build_agent_states(hdf)
    write_population_pickles(base_dir, agent_eval)
    build_model_config(
        base_dir,
        agent_eval,
        device=args.device,
        product_category="new_ice_cream_flavor",
        new_price=4.99,
        baseline_price=3.99,
        llm_config=None,
        calibration=True,
        calibration_logit_bias_initial=args.bias,
    )

    executor_eval = _load_executor(base_dir, args.device)
    pol_e = executor_eval.runner.initializer.policy_function["0"]["households"]["purchase_decision"]
    pol_e.eval()
    dev = torch.device(args.device)
    with torch.no_grad():
        state = executor_eval.runner.state
        obs = executor_eval.runner.controller.observe(
            state, executor_eval.runner.initializer.observation_function, "households"
        )
        out = pol_e(state, obs)
        probs_e = out["purchase_probability"].to(device=dev, dtype=torch.float32).flatten().tolist()

    hh_eval = agent_eval["households"]
    hh_ids = [int(h.get("household_id", 0)) for h in hh_eval]
    if len(probs_e) != len(hh_ids):
        print(
            f"Error: policy output length {len(probs_e)} != number of eval agents {len(hh_ids)}.",
            file=sys.stderr,
        )
        return 1
    y_true = [float(gt_map.get(hid, 0)) for hid in hh_ids]
    y_pred = [1.0 if p >= 0.5 else 0.0 for p in probs_e]

    ev = evaluate_aligned_binary_labels(hh_ids, y_true, y_pred, label="eval_holdout_8020")
    s = ev["summary"]
    print(
        "Eval (held-out households, threshold 0.5 on probability): "
        f"accuracy={s['accuracy']:.4f} precision={s['precision']:.4f} "
        f"recall={s['recall']:.4f} f1={s['f1_score']:.4f}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
