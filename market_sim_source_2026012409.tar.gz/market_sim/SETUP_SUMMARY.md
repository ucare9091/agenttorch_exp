# Market Simulator Setup Summary

## Overview

Created a complete market simulation system (`market_sim/`) that extends the existing price simulation with extreme winter storm weather effects, following the AgentTorch framework.

## Key Features

1. **Weather Integration**: Extreme winter storm data affects purchasing decisions
2. **AgentTorch Framework**: Consistent with original framework and paper
3. **Docker Ready**: Fully containerized for easy deployment
4. **Flexible Input**: Works with any household CSV structure

## Directory Structure

```
market_sim/
├── Dockerfile                    # Docker image definition
├── docker-compose.yml           # Docker Compose config
├── requirements.txt             # Python dependencies
├── .dockerignore               # Docker ignore patterns
├── run_simulation.py           # Main entry point
├── runner_dbx.py              # Simulation runner with weather support
├── generate_weather_data.py   # Weather data generator
├── README.md                  # Full documentation
├── QUICK_START.md            # Quick start guide
├── agenttorch_model/         # AgentTorch model package
│   ├── __init__.py
│   ├── simulator.py
│   └── substeps/
│       ├── __init__.py
│       ├── purchase_decision.py  # Purchase logic with weather effects
│       └── utils.py
├── data/                      # Input data
│   ├── households.csv        # Sample household data
│   └── weather_data.csv      # Extreme winter storm data (30 days)
├── output/                    # Output directory
└── agenttorch_population/     # Population pickle files (runtime)
```

## Weather Effects Modeled

1. **Stockpiling Effect**: 
   - Up to 40% increase in purchase probability during storms
   - Up to 60% increase in quantity purchased

2. **Mobility Reduction**:
   - Severe weather prevents shopping trips
   - Income-dependent: Higher income = better mobility (delivery, transportation)
   - Lower income households more affected

3. **Combined Effect**:
   - Net effect bounded between 30% reduction and 50% increase
   - Balances stockpiling vs. mobility constraints

## AgentTorch Framework Consistency

- Uses `Executor(model_module, pop_loader=population)` pattern  
- Follows AgentTorch model package structure  
- Uses `LoadPopulation` from `agent_torch.core.dataloader`  
- Implements `SubstepAction` and `SubstepTransition`  
- Dynamically generates `yamls/config.yaml`  
- Uses Registry for substep registration  

## Usage Examples

### Basic Run (with weather)
```bash
docker-compose up --build
```

### Custom Weather Day
```bash
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py \
    --weather-csv /app/data/weather_data.csv \
    --weather-day 0
```

### Without Weather (baseline)
```bash
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py
```

## Weather Data Format

The weather CSV includes:
- `date`: Date in YYYY-MM-DD
- `temperature_f`: Temperature (°F)
- `snowfall_inches`: Daily snowfall
- `wind_speed_mph`: Wind speed
- `visibility_miles`: Visibility
- `storm_intensity`: Storm intensity (0-1)
- `weather_impact`: Combined impact score (0-1)
- `is_storm_day`: Binary indicator (1/0)

## Output Format

```json
{
  "scenario": {...},
  "weather": {
    "weather_impact": 0.756,
    "is_storm_day": 1.0
  },
  "n_households": 3000,
  "purchasing_count": 1023.0,
  "purchase_rate": 0.341,
  "total_revenue": 3051.45,
  "total_units": 1018.5
}
```

## Next Steps

1. Build and test: `docker-compose up --build`
2. Compare storm vs. normal days
3. Adjust weather effects in `purchase_decision.py` if needed
4. Generate custom weather data using `generate_weather_data.py`
