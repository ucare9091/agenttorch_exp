#!/usr/bin/env python3
"""
Patch script to fix initializer.py to handle None shapes for string and dict types.
This script applies fixes to agent_torch/core/initializer.py
"""

import os
import sys
import site
from pathlib import Path

def find_initializer_path():
    """Find the initializer.py file in agent_torch package"""
    possible_paths = []

    # First try to import and find the module (most reliable)
    try:
        import agent_torch.core.initializer as init_module
        module_path = Path(init_module.__file__)
        if module_path.exists():
            return module_path
    except ImportError:
        pass

    # Check site-packages
    for site_dir in site.getsitepackages():
        initializer_path = Path(site_dir) / "agent_torch" / "core" / "initializer.py"
        if initializer_path.exists():
            possible_paths.append(initializer_path)

    # Also check user site-packages
    try:
        user_site = site.getusersitepackages()
        if user_site:
            initializer_path = Path(user_site) / "agent_torch" / "core" / "initializer.py"
            if initializer_path.exists():
                possible_paths.append(initializer_path)
    except:
        pass

    if possible_paths:
        return possible_paths[0]

    return None

def apply_fix(initializer_path):
    """Apply the fix to initializer.py"""
    initializer_path = Path(initializer_path)

    if not initializer_path.exists():
        print(f"Error: {initializer_path} not found")
        return False

    # Read the file
    with open(initializer_path, 'r') as f:
        content = f.read()

    # Check if fix already applied
    if 'if type(src_val) == dict:' in content and 'if processed_shape is None:' in content:
        print(f"Fix already applied to {initializer_path}")
        return True

    # Fix 1: _initialize_from_default - handle dict and None shape
    old_pattern1 = """    def _initialize_from_default(self, src_val, shape):
        processed_shape = shape
        if type(src_val) == str:
            return src_val
        if type(src_val) == list:
            init_value = torch.tensor(src_val)
        else:
            init_value = src_val * torch.ones(size=processed_shape)
        if hasattr(init_value, 'to'):
            init_value = init_value.to(self.device)
        return init_value"""

    new_pattern1 = """    def _initialize_from_default(self, src_val, shape):
        processed_shape = shape
        if type(src_val) == str:
            return src_val
        if type(src_val) == dict:
            return src_val
        if type(src_val) == list:
            init_value = torch.tensor(src_val)
        else:
            if processed_shape is None:
                return src_val
            init_value = src_val * torch.ones(size=processed_shape)
        if hasattr(init_value, 'to'):
            init_value = init_value.to(self.device)
        return init_value"""

    if old_pattern1 in content:
        content = content.replace(old_pattern1, new_pattern1)
        print("Applied fix 1: _initialize_from_default")
    else:
        # Try a more flexible pattern match
        import re
        pattern = r'(def _initialize_from_default\(self, src_val, shape\):.*?return init_value)'
        match = re.search(pattern, content, re.DOTALL)
        if match:
            old_code = match.group(1)
            if 'if type(src_val) == dict:' not in old_code:
                # Insert dict handling after str handling
                new_code = old_code.replace(
                    'if type(src_val) == str:\n            return src_val',
                    'if type(src_val) == str:\n            return src_val\n        if type(src_val) == dict:\n            return src_val'
                )
                # Insert None shape check before torch.ones
                if 'init_value = src_val * torch.ones(size=processed_shape)' in new_code:
                    new_code = new_code.replace(
                        '        else:\n            init_value = src_val * torch.ones(size=processed_shape)',
                        '        else:\n            if processed_shape is None:\n                return src_val\n            init_value = src_val * torch.ones(size=processed_shape)'
                    )
                content = content.replace(old_code, new_code)
                print("Applied fix 1: _initialize_from_default (flexible match)")

    # Fix 2: _initialize_from_generator - wrap .to() calls
    import re
    # Check if fix already applied - look for the pattern without the hasattr check
    pattern_unprotected = r'init_value = self\.registry\.initialization_helpers\[function\]\([^)]+\)\s+init_value = init_value\.to\(self\.device\)'
    if re.search(pattern_unprotected, content, re.DOTALL):
        # Find and replace the unprotected .to() call
        pattern = r'(init_value = self\.registry\.initialization_helpers\[function\]\([^)]+\))\s+(init_value = init_value\.to\(self\.device\))'
        match = re.search(pattern, content, re.DOTALL)
        if match:
            # Replace with protected version
            replacement = match.group(1) + '\n        if hasattr(init_value, \'to\'):\n                init_value = init_value.to(self.device)'
            content = content.replace(match.group(0), replacement)
            print("Applied fix 2: _initialize_from_generator")

    # Fix 3: _initialize_property - wrap .to() calls
    pattern = r'(def _initialize_property\(self,.*?)(property_value = property_value\.to\(self\.device\))'
    match = re.search(pattern, content, re.DOTALL)
    if match and 'if hasattr(property_value, \'to\'):' not in match.group(0):
        old_code = match.group(2)
        new_code = 'if hasattr(property_value, \'to\'):\n            property_value = property_value.to(self.device)'
        content = content.replace(old_code, new_code)
        print("Applied fix 3: _initialize_property")

    # Fix 4: _parse_function - handle simple dict arguments (multiple locations)
    if 'initialization_function' in content:
        # Fix all instances of direct dictionary access
        fixes_applied = []
        
        # Pattern 1: arg_object["initialization_function"] -> arg_object.get("initialization_function", None)
        pattern1 = r'arg_object\[[\'"]initialization_function[\'"]\]'
        if re.search(pattern1, content) and 'arg_object.get("initialization_function"' not in content:
            content = re.sub(pattern1, 'arg_object.get("initialization_function", None)', content)
            fixes_applied.append("4a: initialization_function")

        # Pattern 2: arg_object["learnable"] -> arg_object.get("learnable", False)
        pattern2 = r'arg_object\[[\'"]learnable[\'"]\]'
        if re.search(pattern2, content) and 'arg_object.get("learnable"' not in content:
            content = re.sub(pattern2, 'arg_object.get("learnable", False)', content)
            fixes_applied.append("4b: learnable")

        # Pattern 3: arg_object["shape"] -> arg_object.get("shape", None)
        pattern3 = r'arg_object\[[\'"]shape[\'"]\]'
        if re.search(pattern3, content) and 'arg_object.get("shape"' not in content:
            content = re.sub(pattern3, 'arg_object.get("shape", None)', content)
            fixes_applied.append("4c: shape")

        # Pattern 4: arg_object["value"] -> arg_object.get("value", arg_object)
        pattern4 = r'arg_object\[[\'"]value[\'"]\]'
        if re.search(pattern4, content):
            # Replace with .get() but be careful about context
            content = re.sub(
                r'arg_object\[[\'"]value[\'"]\]',
                'arg_object.get("value", arg_object)',
                content
            )
            fixes_applied.append("4d: value")
        
        # Pattern 5: arg_learnable, arg_shape = arg_object["learnable"], arg_object["shape"]
        pattern5 = r'arg_learnable,\s*arg_shape\s*=\s*arg_object\[[\'"]learnable[\'"]\],\s*arg_object\[[\'"]shape[\'"]\]'
        if re.search(pattern5, content):
            content = re.sub(
                pattern5,
                'arg_learnable = arg_object.get("learnable", False)\n            arg_shape = arg_object.get("shape", None)',
                content
            )
            fixes_applied.append("4e: learnable/shape tuple assignment")
        
        if fixes_applied:
            print(f"Applied fix 4: _parse_function - {', '.join(fixes_applied)}")

    # Write back
    with open(initializer_path, 'w') as f:
        f.write(content)

    print(f"Fix applied successfully to {initializer_path}")
    return True

def main():
    print("Applying initializer.py fix...")

    initializer_path = find_initializer_path()

    if not initializer_path:
        print("Error: Could not find agent_torch/core/initializer.py")
        print("Please ensure agent_torch is installed in your Python environment.")
        sys.exit(1)

    print(f"Found initializer.py at: {initializer_path}")

    if apply_fix(initializer_path):
        print("Fix applied successfully!")
        sys.exit(0)
    else:
        print("Failed to apply fix.")
        sys.exit(1)

if __name__ == "__main__":
    main()
