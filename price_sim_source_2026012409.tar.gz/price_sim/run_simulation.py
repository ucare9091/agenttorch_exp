#!/usr/bin/env python3
"""Main entry point for running the price impact simulation in Docker."""

import argparse
import json
import sys
from pathlib import Path

from runner_dbx import run_simulation


def main():
    parser = argparse.ArgumentParser(description="Run price impact simulation with household CSV data")
    parser.add_argument("--csv", type=str, default="/app/data/households.csv", help="Path to household CSV file")
    parser.add_argument("--output", type=str, default="/app/output/results.json", help="Path to output JSON file")
    parser.add_argument("--product-category", type=str, default="new_soft_drink_flavor", help="Product category name")
    parser.add_argument("--new-price", type=float, default=2.99, help="New product price")
    parser.add_argument("--baseline-price", type=float, default=2.49, help="Baseline product price")
    parser.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"], help="Device to use")

    args = parser.parse_args()
    csv_path = Path(args.csv)
    
    if not csv_path.exists():
        print(f"Error: CSV file not found: {csv_path}", file=sys.stderr)
        sys.exit(1)

    scenario = {
        "product_category": args.product_category,
        "new_price": args.new_price,
        "baseline_price": args.baseline_price,
    }

    print(f"Loading households from: {csv_path}")
    print(f"Running simulation with scenario: {scenario}")
    print(f"Using device: {args.device}")

    try:
        results = run_simulation(csv_path=str(csv_path), scenario=scenario, device=args.device)
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)
        print("\nSimulation completed successfully!")
        print(f"Results saved to: {output_path}")
        print(f"  Total households: {results['n_households']}")
        print(f"  Purchasing households: {results['purchasing_count']:.0f}")
        print(f"  Purchase rate: {results['purchase_rate']:.2%}")
        print(f"  Total revenue: ${results['total_revenue']:.2f}")
        print(f"  Total units sold: {results['total_units']:.2f}")
    except Exception as e:
        print(f"Error during simulation: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
