# Setup Guide

## Simple Setup (4 steps)

### 1. Extract Archive in Databricks

```python
import tarfile

# Extract the tar.gz file
with tarfile.open('price_impact_simulator_20260107.tar.gz', 'r:gz') as tar:
    tar.extractall('.')

# Add to Python path
import sys
sys.path.append('./price_impact_simulator')
```

Or use shell command:
```bash
%sh
tar -xzf price_impact_simulator_20260107.tar.gz
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Place Your Data

Create a `data/` directory and place your CSV file:

```
price_impact_simulator/
├── data/
│   └── households.csv  (3000 rows × 581 columns)
├── household.py
├── data_loader.py
├── simulator.py
└── ...
```

### 4. Run Analysis

```python
from price_impact_simulator import PriceImpactSimulator

simulator = PriceImpactSimulator(household_data="data/households.csv")

scenario = {
    'product_category': 'new_soft_drink_flavor',
    'new_price': 2.99,
    'baseline_price': 2.49
}

results = simulator.analyze_price_impact(scenario, n_trials=10)
simulator.generate_report(results)
```

## Data File Format

Your `households.csv` should have:
- **3000 rows** (one per household)
- **581 columns** (household attributes)
- **Required column**: `household_id` (or `id`, `householdId`, `HH_ID`)

## New Product Categories

Use these formats for new CPG products:
- `new_soft_drink_flavor`
- `new_ice_cream_flavor`
- `new_snack_product`
- Any category with `new_` prefix or containing `new`

New products have lower initial adoption (40% vs 70% for existing products).

