"""
Data loader for household data
Handles real-world data with 3000 households and 581 attributes
"""

import pandas as pd
from pathlib import Path
from typing import List, Optional, Union
import logging

logger = logging.getLogger(__name__)


class HouseholdDataLoader:
    """
    Load household data from various sources
    Supports Parquet files and DataFrames with 581 attributes
    """

    def __init__(self, data_source: Optional[Union[str, pd.DataFrame]] = None):
        """
        Initialize data loader

        Args:
            data_source: Path to Parquet file, or pandas DataFrame, or None for testing
        """
        self.data_source = data_source
        self.data: Optional[pd.DataFrame] = None

    def load(self) -> pd.DataFrame:
        """
        Load household data

        Returns:
            DataFrame with household data (3000 rows, 581 columns expected)
        """
        if self.data is not None:
            return self.data

        if self.data_source is None:
            raise ValueError("No data source provided. Set data_source to a file path or DataFrame.")

        if isinstance(self.data_source, pd.DataFrame):
            self.data = self.data_source.copy()
        elif isinstance(self.data_source, str):
            # Handle relative and absolute paths
            data_path = self.data_source
            
            # Resolve relative paths
            if not (data_path.startswith('/dbfs/') or data_path.startswith('/Volumes/')):
                path = Path(data_path).resolve()
            else:
                # Databricks paths
                path = Path(data_path)
            
            if not path.exists():
                raise FileNotFoundError(f"Data file not found: {data_path}")

            # Load based on file extension
            if path.suffix == '.parquet':
                self.data = pd.read_parquet(data_path)
            elif path.suffix in ['.csv', '.tsv']:
                self.data = pd.read_csv(data_path)
            elif path.suffix == '':
                # No extension - try CSV first, then Parquet
                csv_path = Path(str(path) + '.csv')
                parquet_path = Path(str(path) + '.parquet')
                if csv_path.exists():
                    self.data = pd.read_csv(csv_path)
                elif parquet_path.exists():
                    self.data = pd.read_parquet(parquet_path)
                else:
                    raise FileNotFoundError(f"Data file not found: {data_path} (tried .csv and .parquet)")
            elif path.is_dir():
                # Directory - look for CSV or Parquet files
                csv_files = list(path.glob('*.csv'))
                parquet_files = list(path.glob('*.parquet'))
                if csv_files:
                    self.data = pd.read_csv(csv_files[0])
                elif parquet_files:
                    self.data = pd.read_parquet(parquet_files[0])
                else:
                    raise FileNotFoundError(f"No CSV or Parquet files found in directory: {data_path}")
            else:
                raise ValueError(f"Unsupported file format: {path.suffix}")
        else:
            raise ValueError(f"Unsupported data source type: {type(self.data_source)}")

        logger.info(f"Loaded {len(self.data)} households with {len(self.data.columns)} attributes")

        # Validate expected structure
        if len(self.data) != 3000:
            logger.warning(f"Expected 3000 households, got {len(self.data)}")

        if len(self.data.columns) != 581:
            logger.warning(f"Expected 581 attributes, got {len(self.data.columns)}")

        return self.data

    def get_household_ids(self) -> List[int]:
        """Get list of household IDs"""
        data = self.load()

        # Try to find household_id column
        id_col = None
        for col in ['household_id', 'id', 'householdId', 'HH_ID']:
            if col in data.columns:
                id_col = col
                break

        if id_col is None:
            # Use index if no ID column found
            return list(data.index)

        return data[id_col].tolist()

    def get_household_attributes(self, household_id: int) -> dict:
        """
        Get all attributes for a specific household

        Args:
            household_id: Household identifier

        Returns:
            Dictionary of all attributes for the household
        """
        data = self.load()

        # Find household_id column
        id_col = None
        for col in ['household_id', 'id', 'householdId', 'HH_ID']:
            if col in data.columns:
                id_col = col
                break

        if id_col:
            household = data[data[id_col] == household_id]
        else:
            household = data.iloc[[household_id]]

        if len(household) == 0:
            raise ValueError(f"Household {household_id} not found")

        return household.iloc[0].to_dict()

    def get_all_households(self) -> pd.DataFrame:
        """Get all household data"""
        return self.load()

