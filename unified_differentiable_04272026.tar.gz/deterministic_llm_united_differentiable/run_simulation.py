#!/usr/bin/env python3
"""Main entry point for running the price impact simulation in Docker."""

import argparse
import json
import os
import sys
from pathlib import Path

# Databricks jobs/notebooks often use a cwd outside the repo; ensure imports resolve like the tarball layout.
_PROJECT_ROOT = Path(__file__).resolve().parent
_root_s = str(_PROJECT_ROOT)
if _root_s not in sys.path:
    sys.path.insert(0, _root_s)

from agenttorch_model.substeps.llm_helper import optional_llm_str

from agenttorch_model.sim_debug import dbg_print

from runner_dbx import _normalize_dbfs_path, run_simulation
from evaluation_metrics import evaluate_simulation


def _resolve_driver_data_path(raw: str) -> Path:
    """Resolve bundle-relative paths and Databricks dbfs:/... to a driver Path for exists() and pandas."""
    s = str(raw).strip()
    if s.startswith("dbfs:"):
        return Path(_normalize_dbfs_path(s))
    p = Path(s)
    if not p.is_absolute():
        p = Path.cwd() / p
    return p


def main():
    parser = argparse.ArgumentParser(description="Run price impact simulation with household CSV data")
    parser.add_argument(
        "--csv",
        type=str,
        default="data/households.csv",
        help="Household CSV or Parquet path (extra columns allowed; only matched columns are used)",
    )
    parser.add_argument("--output", type=str, default="output/results.json", help="Path to output JSON file")
    parser.add_argument("--product-category", type=str, default="new_ice_cream_flavor", help="Product category name")
    parser.add_argument("--new-price", type=float, default=4.99, help="New product price")
    parser.add_argument("--baseline-price", type=float, default=3.99, help="Baseline competitor price")
    parser.add_argument(
        "--transaction-data",
        type=str,
        default=None,
        help="Optional path to transaction CSV or Parquet for evaluation (same cwd rules as --csv, e.g. data/household_transactions.parquet)",
    )
    parser.add_argument("--simulation-months", type=int, default=2, help="Number of months to simulate")
    parser.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"], help="Device to use")
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Optional RNG seed for reproducible runs (Python random, NumPy, PyTorch before simulation)",
    )
    parser.add_argument(
        "--transaction-history-parquet",
        type=str,
        default=None,
        help="Optional Parquet/CSV of past purchases (long format); text is injected into LLM prompts only, matched by household_id",
    )
    parser.add_argument(
        "--transaction-history-max-rows",
        type=int,
        default=80,
        help="Max transaction lines per household in the LLM prompt (most recent first if time column exists)",
    )
    parser.add_argument(
        "--unified-input",
        action="store_true",
        help="Treat --csv as one long-format Parquet/CSV: demographics + events + optional ground_truth_purchased (same file for LLM history and optional auto-eval)",
    )
    parser.add_argument(
        "--no-auto-evaluate-unified",
        action="store_true",
        help="With --unified-input, do not compute evaluation_vs_ground_truth even if a label column is present",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress verbose DEBUG log lines from the simulation (WARNING/ERROR still print). Same as env PRICE_SIM_QUIET=1.",
    )

    # LLM configuration arguments
    parser.add_argument("--llm-enabled", action="store_true", help="Enable LLM integration")
    parser.add_argument(
        "--llm-provider",
        type=str,
        default="openai",
        choices=["openai", "anthropic", "ollama"],
        help="LLM provider (OpenAI-compatible proxy: use openai + --llm-api-base-url or MODEL_PROXY_*)",
    )
    parser.add_argument("--llm-model", type=str, default="gpt-3.5-turbo", help="LLM model name (e.g., 'gpt-3.5-turbo' or 'gpt-5.1' for proxy)")
    parser.add_argument("--llm-api-key", type=str, default=None, help="LLM API key (or set MODEL_PROXY_API_KEY/OPENAI_API_KEY/ANTHROPIC_API_KEY env var)")
    parser.add_argument("--llm-api-base-url", type=str, default=None, help="LLM API base URL for proxy support (or set MODEL_PROXY_API_BASE/OPENAI_API_BASE env var)")
    parser.add_argument("--llm-temperature", type=float, default=0.7, help="LLM temperature (0.0-2.0)")
    parser.add_argument("--llm-max-tokens", type=int, default=300, help="LLM max tokens (minimum 300 recommended to avoid JSON truncation)")
    parser.add_argument(
        "--llm-sample-size",
        type=int,
        default=0,
        help="If > 0, LLM only for this many random households; if 0 with --llm-enabled, LLM runs for every household",
    )
    parser.add_argument(
        "--llm-use-for-all",
        action="store_true",
        help="Redundant with default when sample size is 0; kept for backward compatibility",
    )
    parser.add_argument(
        "--llm-weight",
        type=float,
        default=0.3,
        help="Blend: final_prob = (1-w)*deterministic_prob + w*llm_term (0.0-1.0)",
    )

    args = parser.parse_args()
    if args.quiet:
        os.environ["PRICE_SIM_QUIET"] = "1"

    csv_path = _resolve_driver_data_path(args.csv)

    if not csv_path.exists():
        print(f"Error: CSV file not found: {csv_path}", file=sys.stderr)
        print(f"Current working directory: {Path.cwd()}", file=sys.stderr)
        sys.exit(1)

    tx_hist_path = None
    if args.unified_input and args.transaction_history_parquet:
        print("Error: use either --unified-input (single panel in --csv) or --transaction-history-parquet, not both.", file=sys.stderr)
        sys.exit(1)

    if args.transaction_history_parquet:
        tx_hist_path = _resolve_driver_data_path(args.transaction_history_parquet)
        if not tx_hist_path.exists():
            print(f"Error: transaction history file not found: {tx_hist_path}", file=sys.stderr)
            sys.exit(1)
        tx_hist_path = str(tx_hist_path)

    scenario = {
        "product_category": args.product_category,
        "new_price": args.new_price,
        "baseline_price": args.baseline_price,
    }

    # Build LLM config if enabled
    llm_config = None
    if args.llm_enabled:
        # Safely get llm_api_base_url attribute (argparse converts --llm-api-base-url to llm_api_base_url)
        api_base_url = optional_llm_str(getattr(args, "llm_api_base_url", None))
        api_key = optional_llm_str(getattr(args, "llm_api_key", None))

        llm_config = {
            "enabled": True,
            "provider": args.llm_provider,
            "model": args.llm_model,
            "api_key": api_key,
            "api_base_url": api_base_url,
            "temperature": args.llm_temperature,
            "max_tokens": max(args.llm_max_tokens, 300),  # Ensure at least 300 to avoid truncation
            "sample_size": args.llm_sample_size,
            "use_for_all": args.llm_use_for_all,
            "llm_weight": args.llm_weight,
        }
        # CRITICAL: Ensure max_tokens is at least 300 to prevent JSON truncation
        if llm_config.get("max_tokens", 0) < 300:
            llm_config["max_tokens"] = 300
            dbg_print(f"DEBUG: Updated max_tokens to 300 (was {args.llm_max_tokens})")
        print(f"LLM enabled: {args.llm_provider}/{args.llm_model}")
        if api_base_url:
            print(f"  Using custom API base URL: {api_base_url}")
        if args.llm_sample_size > 0:
            print(f"  Using LLM for {args.llm_sample_size} sample households")
        else:
            print("  Using LLM for all households (default when sample size is 0)")
    else:
        print("LLM disabled (use --llm-enabled to enable)")

    print(f"Loading households from: {csv_path}")
    print(f"Running simulation with scenario: {scenario}")
    print(f"Using device: {args.device}")
    if args.seed is not None:
        print(f"Using seed: {args.seed}")

    try:
        results = run_simulation(
            csv_path=str(csv_path),
            scenario=scenario,
            device=args.device,
            llm_config=llm_config,
            seed=args.seed,
            transaction_history_parquet=tx_hist_path,
            transaction_history_max_rows=args.transaction_history_max_rows,
            unified_input=args.unified_input,
            auto_evaluate_unified=not args.no_auto_evaluate_unified,
            quiet=args.quiet,
        )
        output_path = Path(args.output)

        # Handle relative paths - resolve relative to current working directory
        if not output_path.is_absolute():
            output_path = Path.cwd() / output_path

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)
        print("\nSimulation completed successfully!")
        print(f"Results saved to: {output_path}")
        print(f"  Total households: {results['n_households']}")
        print(f"  Purchasing households: {results['purchasing_count']:.0f}")
        print(f"  Purchase rate: {results['purchase_rate']:.2%}")
        print(f"  Total revenue: ${results['total_revenue']:.2f}")
        print(f"  Total units sold: {results['total_units']:.2f}")
        ev = results.get("evaluation_vs_ground_truth")
        if ev:
            print("\nUnified ground-truth evaluation (same household order as predictions):")
            for key in ("final_will_purchase", "deterministic_will_purchase"):
                if key not in ev:
                    continue
                m = ev[key].get("summary", {})
                print(f"  {key}: accuracy={m.get('accuracy', 0):.4f}  F1={m.get('f1_score', 0):.4f}")

        # Evaluate against transaction data if provided
        if args.transaction_data:
            transaction_path = Path(args.transaction_data)
            if not transaction_path.is_absolute():
                transaction_path = Path.cwd() / transaction_path
            if transaction_path.exists():
                print("\nEvaluating against transaction data...")
                eval_output = output_path.parent / f"{output_path.stem}_evaluation.json"
                eval_results = evaluate_simulation(
                    str(output_path),
                    str(transaction_path),
                    str(eval_output),
                )
                print("\nEvaluation Metrics:")
                print(f"  Precision: {eval_results['metrics']['precision']:.4f}")
                print(f"  Recall: {eval_results['metrics']['recall']:.4f}")
                print(f"  F1-Score: {eval_results['metrics']['f1_score']:.4f}")
                print(f"  Accuracy: {eval_results['metrics']['accuracy']:.4f}")
                print("\nConfusion Matrix:")
                cm = eval_results['metrics']['confusion_matrix']
                print(f"  True Positive: {cm['true_positive']}")
                print(f"  False Positive: {cm['false_positive']}")
                print(f"  False Negative: {cm['false_negative']}")
                print(f"  True Negative: {cm['true_negative']}")
                print(f"\nEvaluation results saved to: {eval_output}")
            else:
                print(f"\nWarning: Transaction data file not found: {transaction_path}")
    except Exception as e:
        print(f"Error during simulation: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
