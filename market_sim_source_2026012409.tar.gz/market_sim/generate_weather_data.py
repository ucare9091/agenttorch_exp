#!/usr/bin/env python3
"""Generate extreme winter storm weather data for market simulation."""

import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta


def generate_extreme_winter_storm_data(
    n_days: int = 30,
    start_date: str = "2024-01-01",
    severity_level: str = "extreme",
    output_path: str = "weather_data.csv"
):
    """
    Generate extreme winter storm weather data.
    
    Parameters:
    -----------
    n_days : int
        Number of days to generate data for
    start_date : str
        Start date in YYYY-MM-DD format
    severity_level : str
        Severity level: "moderate", "severe", "extreme"
    output_path : str
        Path to save the CSV file
    """
    # Define severity parameters
    severity_params = {
        "moderate": {
            "temp_base": 25.0,  # Base temperature in Fahrenheit
            "temp_variance": 10.0,
            "snowfall_base": 2.0,  # inches per day
            "snowfall_variance": 3.0,
            "wind_speed_base": 15.0,  # mph
            "wind_speed_variance": 10.0,
            "storm_probability": 0.3,
        },
        "severe": {
            "temp_base": 15.0,
            "temp_variance": 15.0,
            "snowfall_base": 6.0,
            "snowfall_variance": 8.0,
            "wind_speed_base": 25.0,
            "wind_speed_variance": 15.0,
            "storm_probability": 0.5,
        },
        "extreme": {
            "temp_base": 5.0,
            "temp_variance": 20.0,
            "snowfall_base": 12.0,
            "snowfall_variance": 15.0,
            "wind_speed_base": 40.0,
            "wind_speed_variance": 25.0,
            "storm_probability": 0.7,
        }
    }
    
    params = severity_params.get(severity_level, severity_params["extreme"])
    
    # Generate dates
    start = datetime.strptime(start_date, "%Y-%m-%d")
    dates = [start + timedelta(days=i) for i in range(n_days)]
    
    # Generate weather data
    data = []
    for i, date in enumerate(dates):
        # Create storm events (more likely in extreme scenarios)
        is_storm_day = np.random.random() < params["storm_probability"]
        
        if is_storm_day:
            # Storm day: extreme conditions
            temp = np.random.normal(params["temp_base"] - 10, params["temp_variance"])
            snowfall = np.random.gamma(2, params["snowfall_base"] / 2)
            snowfall = max(0, snowfall)  # Ensure non-negative
            wind_speed = np.random.gamma(2, params["wind_speed_base"] / 2)
            wind_speed = max(0, wind_speed)
            visibility = np.random.uniform(0.1, 0.5)  # Very low visibility in miles
            storm_intensity = np.random.uniform(0.7, 1.0)  # High intensity
        else:
            # Normal winter day
            temp = np.random.normal(params["temp_base"], params["temp_variance"])
            snowfall = np.random.exponential(params["snowfall_base"] / 5)
            snowfall = max(0, snowfall)
            wind_speed = np.random.exponential(params["wind_speed_base"] / 3)
            wind_speed = max(0, wind_speed)
            visibility = np.random.uniform(2.0, 10.0)
            storm_intensity = np.random.uniform(0.0, 0.3)
        
        # Calculate weather impact score (0-1 scale, higher = more severe)
        # Factors: temperature, snowfall, wind, visibility
        temp_factor = max(0, (32 - temp) / 50)  # Colder = higher impact
        snow_factor = min(1.0, snowfall / 20.0)  # More snow = higher impact
        wind_factor = min(1.0, wind_speed / 60.0)  # Higher wind = higher impact
        visibility_factor = max(0, (10 - visibility) / 10)  # Lower visibility = higher impact
        
        weather_impact = (temp_factor * 0.3 + snow_factor * 0.3 + 
                         wind_factor * 0.2 + visibility_factor * 0.2)
        weather_impact = min(1.0, weather_impact)
        
        data.append({
            "date": date.strftime("%Y-%m-%d"),
            "day_of_year": date.timetuple().tm_yday,
            "temperature_f": round(temp, 1),
            "snowfall_inches": round(snowfall, 2),
            "wind_speed_mph": round(wind_speed, 1),
            "visibility_miles": round(visibility, 2),
            "storm_intensity": round(storm_intensity, 3),
            "weather_impact": round(weather_impact, 3),
            "is_storm_day": 1 if is_storm_day else 0,
        })
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Save to CSV
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    
    print(f"Generated {len(df)} days of {severity_level} winter storm weather data")
    print(f"Saved to: {output_path}")
    print(f"\nSummary statistics:")
    print(f"  Average temperature: {df['temperature_f'].mean():.1f}°F")
    print(f"  Total snowfall: {df['snowfall_inches'].sum():.1f} inches")
    print(f"  Average wind speed: {df['wind_speed_mph'].mean():.1f} mph")
    print(f"  Storm days: {df['is_storm_day'].sum()} ({df['is_storm_day'].mean()*100:.1f}%)")
    print(f"  Average weather impact: {df['weather_impact'].mean():.3f}")
    
    return df


def main():
    parser = argparse.ArgumentParser(description="Generate extreme winter storm weather data")
    parser.add_argument("--days", type=int, default=30, help="Number of days to generate")
    parser.add_argument("--start-date", type=str, default="2024-01-01", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--severity", type=str, default="extreme", 
                       choices=["moderate", "severe", "extreme"],
                       help="Severity level")
    parser.add_argument("--output", type=str, default="weather_data.csv", 
                       help="Output CSV file path")
    
    args = parser.parse_args()
    
    generate_extreme_winter_storm_data(
        n_days=args.days,
        start_date=args.start_date,
        severity_level=args.severity,
        output_path=args.output
    )


if __name__ == "__main__":
    main()
