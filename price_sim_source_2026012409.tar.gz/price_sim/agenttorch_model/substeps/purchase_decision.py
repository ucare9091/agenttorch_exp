from __future__ import annotations

from typing import Any, Dict
import torch
import re

from agent_torch.core.helpers.general import get_by_path
from agent_torch.core.registry import Registry
from agent_torch.core.substep import SubstepAction, SubstepTransition


def get_var(state: Dict[str, Any], var: str):
    """
    Retrieves a value from the current state of the model.
    Follows AgentTorch framework pattern.
    """
    return get_by_path(state, re.split("/", var))


@Registry.register_substep("purchase_decision", "policy")
class PurchaseDecisionPolicyAT(SubstepAction):
    def forward(self, state: Dict[str, Any], observation: Dict[str, Any]):
        # Extract input variables using AgentTorch framework pattern
        income = get_var(state, self.input_variables["income"])
        household_size = get_var(state, self.input_variables["household_size"])
        price_sensitivity = get_var(state, self.input_variables["price_sensitivity"])
        new_price = get_var(state, self.input_variables["new_price"])
        baseline_price = get_var(state, self.input_variables["baseline_price"])

        # Normalize to tensors for computation
        if not torch.is_tensor(new_price):
            new_price = torch.tensor(new_price)
        if not torch.is_tensor(baseline_price):
            baseline_price = torch.tensor(baseline_price)

        # Ensure compatible shapes and dtypes for broadcasting
        if torch.is_tensor(income):
            if new_price.dim() == 0:
                new_price = new_price.unsqueeze(0)
            if baseline_price.dim() == 0:
                baseline_price = baseline_price.unsqueeze(0)
            new_price = new_price.to(dtype=income.dtype, device=income.device)
            baseline_price = baseline_price.to(dtype=income.dtype, device=income.device)

        price_change_pct = torch.where(
            baseline_price > 0,
            (new_price - baseline_price) / baseline_price,
            torch.zeros_like(new_price),
        )

        income_normalized = torch.clamp(income / 150000.0, max=1.0)
        price_sensitivity_factor = 1.0 - (income_normalized * 0.5)

        base_probability = torch.full_like(price_sensitivity_factor, 0.7)

        sensitivity_impact = torch.where(
            price_change_pct > 0,
            price_sensitivity * price_change_pct * 2.0,
            price_sensitivity * torch.abs(price_change_pct) * 0.5,
        )
        purchase_probability = torch.where(
            price_change_pct > 0,
            base_probability * (1.0 - torch.clamp(sensitivity_impact, max=0.8)),
            base_probability * (1.0 + torch.clamp(sensitivity_impact, max=0.5)),
        )

        income_factor = torch.clamp(income / 100000.0, max=1.0)
        purchase_probability = purchase_probability * (0.7 + 0.3 * income_factor)
        purchase_probability = torch.clamp(purchase_probability, min=0.0, max=1.0)

        rand_val = torch.rand_like(purchase_probability)
        will_purchase = (rand_val < purchase_probability).float()

        base_quantity = torch.clamp(household_size * 0.5, min=1.0)
        quantity = torch.where(
            will_purchase > 0,
            torch.where(
                price_change_pct < 0,
                base_quantity * (1.0 - price_change_pct * 0.3),
                base_quantity * (1.0 - price_change_pct * 0.5),
            ),
            torch.zeros_like(base_quantity),
        )
        quantity = torch.clamp(quantity, min=0.0)
        total_spend = new_price * quantity

        return {
            "will_purchase": will_purchase,
            "quantity": quantity,
            "total_spend": total_spend,
        }


@Registry.register_substep("apply_purchase_decision", "transition")
class ApplyPurchaseDecision(SubstepTransition):
    def forward(self, state: Dict[str, Any], action: Dict[str, Any]):
        # AgentTorch framework: action contains policy outputs nested under agent name
        # Structure: action['households'] = {'will_purchase': ..., 'quantity': ..., 'total_spend': ...}
        if action and isinstance(action, dict) and "households" in action:
            household_action = action["households"]
            if isinstance(household_action, dict):
                return {
                    "will_purchase": household_action.get("will_purchase"),
                    "quantity": household_action.get("quantity"),
                    "total_spend": household_action.get("total_spend"),
                }

        # Fallback for direct keys (should not happen in standard AgentTorch flow)
        return {
            "will_purchase": action.get("will_purchase") if action else None,
            "quantity": action.get("quantity") if action else None,
            "total_spend": action.get("total_spend") if action else None,
        }
