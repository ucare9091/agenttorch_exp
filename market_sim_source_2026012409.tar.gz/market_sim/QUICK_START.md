# Quick Start Guide

## 1. Generate Weather Data (Optional)

If you want to generate new weather data:

```bash
docker run --rm -v $(pwd)/data:/app/data market-sim:latest \
  python generate_weather_data.py \
    --days 30 \
    --severity extreme \
    --output /app/data/weather_data.csv
```

## 2. Run Simulation with Weather

```bash
docker-compose up --build
```

Or manually:

```bash
docker build -t market-sim:latest .
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py \
    --csv /app/data/households.csv \
    --weather-csv /app/data/weather_data.csv \
    --weather-day 0
```

## 3. Compare Storm Day vs Normal Day

**Storm Day (day 0):**
```bash
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py \
    --weather-day 0 \
    --output /app/output/results_storm.json
```

**Normal Day (day 13 - no storm):**
```bash
docker run --rm \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/output:/app/output \
  market-sim:latest \
  python run_simulation.py \
    --weather-day 13 \
    --output /app/output/results_normal.json
```

## 4. View Results

Results are saved to `output/results.json` (or your specified output path).

Key metrics:
- `purchase_rate`: Percentage of households making purchases
- `total_revenue`: Total revenue from sales
- `total_units`: Total units sold
- `weather.weather_impact`: Weather impact score (0-1)
- `weather.is_storm_day`: 1 = storm day, 0 = normal day

## Expected Behavior

During extreme winter storms:
- **Stockpiling**: Purchase probability and quantity increase
- **Mobility Reduction**: Lower-income households are more affected
- **Net Effect**: Higher overall sales due to stockpiling, but with income-dependent access
