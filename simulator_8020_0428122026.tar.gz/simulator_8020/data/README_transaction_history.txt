Optional long-format transaction history for LLM prompts (--transaction-history-parquet).

Required column (flexible name via column matching): household key, e.g. household_id, hh_id, customer_id.

Optional columns (flexible names): product_name / product / sku / item_name; quantity / qty / units; purchase_timestamp / purchase_time / transaction_time / timestamp / purchase_date / etc.

Extra columns are ignored. Row counts and names can change anytime.

Rows are matched to simulation agents by household_id from the household input file. Text shown to the LLM is capped per household (--transaction-history-max-rows), most recent first when a time column parses.

This file does not affect the deterministic probability formulas; it only enriches the LLM user prompt.
