"""Random 80/20 (configurable) split of household ids for train vs held-out evaluation."""

from __future__ import annotations

import random
from typing import List, Optional, Sequence, Tuple


def train_eval_household_ids(
    household_ids: Sequence[int],
    train_fraction: float = 0.8,
    seed: Optional[int] = None,
) -> Tuple[List[int], List[int]]:
    """
    Shuffle ``household_ids`` with ``seed`` and return (train_ids, eval_ids).

    The two returned id lists partition ``household_ids`` (disjoint, exhaustive).
    Uses floor(n * train_fraction) for train count, remainder for eval.
    Requires at least two households so both splits are non-empty.
    """
    f = float(train_fraction)
    if not (0.0 < f < 1.0):
        raise ValueError(f"train_fraction must be strictly between 0 and 1, got {train_fraction!r}.")
    ids = sorted({int(h) for h in household_ids})
    if len(ids) < 2:
        raise ValueError("Need at least two households with labels to form an 80/20 split.")
    rng = random.Random(seed)
    shuffled = list(ids)
    rng.shuffle(shuffled)
    n = len(shuffled)
    n_train = int(n * f)
    if n_train < 1:
        n_train = 1
    if n_train >= n:
        n_train = n - 1
    return shuffled[:n_train], shuffled[n_train:]
