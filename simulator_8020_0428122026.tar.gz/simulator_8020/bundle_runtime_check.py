"""Fail fast before agent_torch imports if PyArrow is too old for bundled Dask.

agent-torch depends on Dask; recent Dask requires PyArrow >= 16. Clusters with
PyArrow 15 otherwise raise an obscure ImportError during agent_torch import.
This module uses only the standard library plus an optional pyarrow import.
"""

from __future__ import annotations

_MIN_PYARROW = (16, 0, 0)


def _parse_version_tuple(version_string: str) -> tuple[int, int, int]:
    parts = version_string.strip().split(".")
    nums: list[int] = []
    for part in parts[:3]:
        digits = "".join(ch for ch in part if ch.isdigit())
        nums.append(int(digits) if digits else 0)
    while len(nums) < 3:
        nums.append(0)
    return nums[0], nums[1], nums[2]


def ensure_pyarrow_for_agent_stack() -> None:
    """Raise RuntimeError with an actionable message if PyArrow is below the Dask floor."""
    try:
        import pyarrow as pa  # type: ignore[import-not-found]
    except ImportError:
        return
    installed = _parse_version_tuple(pa.__version__)
    if installed < _MIN_PYARROW:
        need = ".".join(str(x) for x in _MIN_PYARROW)
        raise RuntimeError(
            f"PyArrow {pa.__version__} is too old for the agent-torch dependency stack "
            f"(Dask needs PyArrow >= {need}). Install from this bundle's requirements.txt "
            f"(pip install -r requirements.txt) or at minimum: pip install 'pyarrow>={need},<21' "
            "then restart the Python process or Databricks cluster. "
            "This check runs before importing agent_torch to avoid a confusing ImportError."
        )
